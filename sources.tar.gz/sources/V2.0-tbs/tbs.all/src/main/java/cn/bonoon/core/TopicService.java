package cn.bonoon.core;

import java.util.List;

import cn.bonoon.core.infos.TopicCommentInfo;
import cn.bonoon.core.infos.TopicContentInfo;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.support.services.GenericService;

public interface TopicService extends GenericService<TopicEntity>{

	List<TopicCommentInfo> getComments(String key, Long lastId);

	TopicCommentInfo commentSave(LogonUser user, String key, String content, int score);

//	TopicContentInfo getStudyMedia(String key, Long pre, Long loadId, Long next);
//
//	TopicContentInfo getStudyContent(String key, Long pre, Long loadId, Long next);

	TopicContentInfo getStudyMedia(String key, Long id);

	TopicContentInfo getStudyContent(String key, Long id);
	
}
