package cn.bonoon.core;

import cn.bonoon.entities.PagerComment;
import cn.bonoon.kernel.support.services.SearchService;

public interface PagerCommentService extends SearchService<PagerComment>{

}
