package cn.bonoon.core.configs;

import cn.bonoon.kernel.annotations.OptionArray;
import cn.bonoon.kernel.web.annotations.components.AsNumberBox;
import cn.bonoon.kernel.web.annotations.components.AsSelector;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

//个人能力评估的相关的参数设置
@FormEditor(value = 2, headWidth = 140, width = 280)
public class EvaluationConfig {

	@AsNumberBox
	@PropertyEditor(name = "评估费用", value = 0)
	@PropertyHelper(value = "用户每进行一次个人能力的评估所需要花费的积分", type = HelperType.WRAP)
	private int evaluateCost;//进行一次评估需要花费的积分

	@PropertyEditor(name = "首次免费", value = 1)
	@PropertyHelper(value = "用户第一次进行个人能力评估是否免费", type = HelperType.WRAP)
	private boolean firstFree;

	@AsNumberBox
	@PropertyEditor(name = "安全线", value = 20)
	@PropertyHelper(value = "达到安全线的，表示在正常发挥的情况下能通过", type = HelperType.WRAP)
	private int secureLine = 75;//及格的分数，如：80分，也就是说某一个知识点达到80分以上的算及格，可以在提高练习的时候不出现

	@AsNumberBox
	@PropertyEditor(name = "警戒线", value = 21)
	@PropertyHelper(value = "警戒线以下的，建议多练习，不建议去考试", type = HelperType.WRAP)
	private int picketLine = 50;//警戒线，警戒线以下的，不管限制了maxTimes是多少，都要全部让用户进行练习

	@AsNumberBox
	@PropertyEditor(name = "建议线", value = 22)
	@PropertyHelper(value = "建议线以上的，可以尝试去考试", type = HelperType.WRAP)
	private int suggestLine = 65;//建议可以去考试的分数线

	@AsSelector
	@OptionArray({"基础", "简单", "正常", "较难", "高难", "超难"})
	@PropertyEditor(name = "难度级别", value = 23)
	@PropertyHelper(value = "某一难度级别及以上的题目才会进行个人能力的评估", type = HelperType.WRAP)
	private int difficultyLevel;//难度级别

	@AsNumberBox
	@PropertyEditor(name = "提高练习题目", value = 31)
	@PropertyHelper(value = "一个知识点提高练习所出的练习题目数", type = HelperType.WRAP)
	private int improveCount = 10;//每次进行提高练习所出的题目数量，默认为10个题目

	@AsNumberBox
	@PropertyEditor(name = "知识点数", value = 30)
	@PropertyHelper(value = "一次提高练习所出的知识点的最大数量", type = HelperType.WRAP)
	private int maxTimes;//进行一次提高练习的出现最多的知识点的次数

	@AsNumberBox
	@PropertyEditor(name = "评估有效期", value = 10, unit = "月")
	@PropertyHelper(value = "对一定时间段内的练习题目进行评估，0表示无限制", type = HelperType.WRAP)
	private int validPeriod;//有效期，单位为月，如：即对该用户半年前做过的题目进行统计处理

	@AsNumberBox
	@PropertyEditor(name = "有效题目数", value = 11)
	@PropertyHelper(value = "每次进行评估需要的最少题目数", type = HelperType.WRAP)
	private int validEntry;//有效的条目，必须达到这个条目以上的，才能进行个人能力的评估

	public int getEvaluateCost() {
		return evaluateCost;
	}

	public void setEvaluateCost(int evaluateCost) {
		this.evaluateCost = evaluateCost;
	}

	public boolean isFirstFree() {
		return firstFree;
	}

	public void setFirstFree(boolean firstFree) {
		this.firstFree = firstFree;
	}

	public int getPicketLine() {
		return picketLine;
	}

	public void setPicketLine(int picketLine) {
		this.picketLine = picketLine;
	}

	public int getImproveCount() {
		return improveCount;
	}

	public void setImproveCount(int improveCount) {
		this.improveCount = improveCount;
	}

	public int getMaxTimes() {
		return maxTimes;
	}

	public void setMaxTimes(int maxTimes) {
		this.maxTimes = maxTimes;
	}

	public int getValidPeriod() {
		return validPeriod;
	}

	public void setValidPeriod(int validPeriod) {
		this.validPeriod = validPeriod;
	}

	public int getValidEntry() {
		return validEntry;
	}

	public void setValidEntry(int validEntry) {
		this.validEntry = validEntry;
	}

	public int getSecureLine() {
		return secureLine;
	}

	public void setSecureLine(int secureLine) {
		this.secureLine = secureLine;
	}

	public int getSuggestLine() {
		return suggestLine;
	}

	public void setSuggestLine(int suggestLine) {
		this.suggestLine = suggestLine;
	}

	public int getDifficultyLevel() {
		return difficultyLevel;
	}

	public void setDifficultyLevel(int difficultyLevel) {
		this.difficultyLevel = difficultyLevel;
	}
}
