package cn.bonoon.entities;

public enum AnswerStatisticsType {
	AREA("AREA"),KNOWLEDGE("KNOWLEDGE"),PROCESS("PROCESS"),GROUP("GROUP");
	private final String title;
	private AnswerStatisticsType(String title){
		this.title = title;
	}
	public String toKey(Long id){
		return title + '-' + id;
	}
}
