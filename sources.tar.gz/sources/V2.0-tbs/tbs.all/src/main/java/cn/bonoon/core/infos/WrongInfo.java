package cn.bonoon.core.infos;

import cn.bonoon.entities.TopicEntity;
import cn.bonoon.entities.WrongAnswerEntity;
import cn.bonoon.kernel.util.StringHelper;

public class WrongInfo {
	private final String content;
	private final String remark;
	private final String practiceAt;
	
	private String ans;
	private final String aopt, bopt, copt, dopt;
	private final String res;//会员的答案
	
	public WrongInfo(WrongAnswerEntity entity, Boolean en){
		TopicEntity topic = entity.getTopic();
		if(null != topic){
			ans = topic.getAnswer();
			if(null != en && en.booleanValue()){
				content = topic.getEnContent();
				aopt = topic.getEnOptionA();
				bopt = topic.getEnOptionB();
				copt = topic.getEnOptionC();
				dopt = topic.getEnOptionD();
			}else{
				content = topic.getCnContent();
				aopt = topic.getCnOptionA();
				bopt = topic.getCnOptionB();
				copt = topic.getCnOptionC();
				dopt = topic.getCnOptionD();
			}
		}else{
			content = "";
			aopt = "";
			bopt = "";
			copt = "";
			dopt = "";
		}
		if(null != ans){
			ans = ans.trim().toUpperCase();
		}else{
			ans = "";
		}
		if(StringHelper.isEmpty(entity.getAnswer())){
			res = "<font color='red'>无</font>";
		}else{
			res = entity.getAnswer();
		}
		remark = entity.getRemark();
		practiceAt = StringHelper.date2String(entity.getPracticeAt());
	}
	
	public String getContent() {
		return content;
	}
	
	public String getRemark() {
		return remark;
	}
	
	public String getPracticeAt() {
		return practiceAt;
	}

	public String getAns() {
		return ans;
	}

	public String getAopt() {
		return aopt;
	}

	public String getBopt() {
		return bopt;
	}

	public String getCopt() {
		return copt;
	}

	public String getDopt() {
		return dopt;
	}

	public String getRes() {
		return res;
	}
}
