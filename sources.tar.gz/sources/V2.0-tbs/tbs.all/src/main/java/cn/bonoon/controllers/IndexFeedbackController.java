package cn.bonoon.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.bonoon.core.FeedbackService;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.util.StringHelper;
import cn.bonoon.kernel.web.controllers.AbstractController;
import cn.bonoon.kernel.web.models.JsonResult;
import cn.bonoon.util.VerifyCodeHelper;

@Controller
public class IndexFeedbackController extends AbstractController{

	@Autowired
	private FeedbackService feedbackService;
	
	@ResponseBody
	@RequestMapping(value = "pmp/feedback.do", method = RequestMethod.POST)
	public JsonResult feedback(HttpServletRequest request, String fbname, String fbemail, String fbphone, String fbcontent, String fbvcode){
		try{
			if(StringHelper.isEmpty(fbcontent)){
				throw new Exception("请输入反馈的内容！");
			}
			fbcontent = fbcontent.trim();
			if(fbcontent.length() > 200){
				throw new Exception("反馈的内容超过200个字，请简单描述您的问题，谢谢！");
			}
			VerifyCodeHelper.verify(request, 3, fbvcode);
			feedbackService.save(getUser(), fbname, fbphone, fbemail, fbcontent);
			return JsonResult.result();
		}catch (Exception e) {
			return JsonResult.error(e);
		}
	}
	
	@RequestMapping(value = "pmp/feedback.do", method = RequestMethod.GET)
	public String feedback(Model model){
		//二维码
		LogonUser user = getUser();
		if(null != user){
			model.addAttribute("fbname", user.getDisplayName());
		}
		model.addAttribute("limitChar", 200);
		model.addAttribute("layout", "layout-empty.vm");
		model.addAttribute("rd", System.currentTimeMillis());
		return "mgr/feedback";
	}

}
