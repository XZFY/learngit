package cn.bonoon.controllers;

import cn.bonoon.core.infos.EvaluationItemInfo;
import cn.bonoon.entities.CapabilityEvaluationEntity;

public class EvaluationStatisticsInfo {
	
	public EvaluationStatisticsInfo(CapabilityEvaluationEntity cee, int size) {
		int width = 600 / size;
		if(width <= 20){
			preWidth = width / 2;
			contentWidth = width - preWidth;
		}else if(width > 40){
			contentWidth = 30;
			preWidth = width - contentWidth;
		}else{
			preWidth = 10;
			contentWidth = width - preWidth;
		}
		this.secureLine = cee.getSecureLine();
		this.picketLine = cee.getPicketLine();
		this.suggestLine = cee.getSuggestLine();
		this.capability = cee.getCapability();
		
		this.secureHeight = secureLine * 3;
		this.secureTop = 300 - secureHeight;
		
		this.picketHeight = picketLine * 3;
		this.picketTop = 300 - picketHeight;
		
		this.secureWidth = secureLine * 6;
		this.picketWidth = picketLine * 6;
	}
	
	private final double capability;
	
	private final int secureLine;
	
	private final int picketLine;
	
	private final int suggestLine;
	
	private final int preWidth;
	
	private final int contentWidth;
	
	private final int secureHeight;
	
	private final int secureTop;
	
	private final int picketHeight;
	
	private final int picketTop;
	
	private final int secureWidth;
	
	private final int picketWidth;
	//width:30px;height:150px;top:150px;left:40px;border:none;background:#F00;opacity:0.6;filter:alpha(Opacity=60);text-align:center;padding-top:4px;
	public StringBuilder style(EvaluationItemInfo eii){
		double cp = eii.getCapability();
		double ch = cp * 3;
		double ct = 300 - ch;
		
		StringBuilder sb = new StringBuilder("width:");
		sb.append(contentWidth).append("px;height:").append(ch).append("px;top:").append(ct).append("px;left:").append(preWidth).append("px;background:");

		sb.append(color(cp));
		return sb.append(";padding-top:4px;");
	}
	
	private String color(double cp){
		if(cp > secureLine){
			//安全，可考
			return "#00F";
		}else if(cp > suggestLine){
			//建议，可考
			return "#FF0";
		}else if(cp > picketLine){
			//不建议考
			return "#FF0";
		}else{
			//建议不考
			return "#F00";
		}
	}
	
	//width:600px;height:225px;top:75px;border:2px solid #00F;
	public String getSecureStyle(){
		return "width:600px;height:" + secureHeight + "px;top:" + secureTop + "px;border:2px solid #00F;";
	}
	
	public String getPicketStyle(){
		return "width:600px;height:" + picketHeight + "px;top:" + picketTop + "px;border:2px solid #F00;";
	}

	//width:400px;background:#00F;
	public String getCapabilityStyle() {
		return "width:" + (capability * 6) + "px;background:" + color(capability) + ";height:25px;";
	}

//	public int getPreWidth() {
//		return preWidth;
//	}
//
//	public int getContentWidth() {
//		return contentWidth;
//	}
	
	public double getCapability() {
		return capability;
	}

	public int getSecureLine() {
		return secureLine;
	}

	public int getPicketLine() {
		return picketLine;
	}

	public int getSuggestLine() {
		return suggestLine;
	}

//	public int getSecureHeight() {
//		return secureHeight;
//	}
//
//	public int getSecureTop() {
//		return secureTop;
//	}
//
//	public int getPicketHeight() {
//		return picketHeight;
//	}
//
//	public int getPicketTop() {
//		return picketTop;
//	}
//
	public int getSecureWidth() {
		return secureWidth;
	}

	public int getPicketWidth() {
		return picketWidth;
	}
	
}
