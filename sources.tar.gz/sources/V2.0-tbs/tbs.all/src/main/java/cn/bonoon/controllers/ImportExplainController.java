package cn.bonoon.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.bonoon.core.ImportService;
import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.entities.KnowledgePointEntity;
import cn.bonoon.entities.ProcessEntity;
import cn.bonoon.entities.ProcessGroupEntity;

@Controller
public class ImportExplainController {
	
	@Autowired
	private ImportService importService;
	
	@RequestMapping(value = "u/import/explain/index.do", method = RequestMethod.GET)
	public String get(Model model){
		List<ProcessGroupEntity> groups = importService.groups();
		List<ProcessEntity> processes = importService.processes();
		List<KnowledgeAreaEntity> areas = importService.areas();
		List<KnowledgePointEntity> points = importService.points();
		model.addAttribute("groups", groups);
		model.addAttribute("processes", processes);
		model.addAttribute("areas", areas);
		model.addAttribute("points", points);
		model.addAttribute("layout", "layout-empty.vm");
		return "import-explain";
	}
	
}
