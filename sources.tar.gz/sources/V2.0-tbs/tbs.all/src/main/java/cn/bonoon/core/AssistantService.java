package cn.bonoon.core;

import java.util.Collection;

import cn.bonoon.core.configs.TpiConfig;
import cn.bonoon.core.infos.ForcetorInfo;
import cn.bonoon.core.infos.KnowledgeInfo;
import cn.bonoon.core.infos.SisterInfo;
import cn.bonoon.core.infos.TpiInfo;
import cn.bonoon.kernel.support.IOperator;

public interface AssistantService {

	ForcetorInfo forcetor(IOperator user, String[] paths);

	TpiInfo tpi(IOperator user, TpiConfig config);

	SisterInfo sister(IOperator user);

	SisterInfo sister(IOperator user, Long id);

	boolean sister(IOperator user, Long id, Collection<KnowledgeInfo> values);
}
