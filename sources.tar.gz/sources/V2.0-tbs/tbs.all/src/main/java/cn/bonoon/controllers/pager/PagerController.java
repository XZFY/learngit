package cn.bonoon.controllers.pager;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.bonoon.controllers.comment.CommentDialog;
import cn.bonoon.core.PagerCommentService;
import cn.bonoon.core.PagerService;
import cn.bonoon.core.TopicPagerService;
import cn.bonoon.core.TopicService;
import cn.bonoon.entities.PagerEntity;
import cn.bonoon.kernel.web.ButtonEventType;
import cn.bonoon.kernel.web.annotations.grid.GridStandardDefinition;
import cn.bonoon.kernel.web.controllers.AbstractGridController;
import cn.bonoon.kernel.web.models.JsonResult;

@Controller
@RequestMapping("s/tms/pager")
public class PagerController extends AbstractGridController<PagerEntity, PagerItem>{
	
	private final PagerService service;
	private final TopicService topicService;
	private final PagerCommentService commentService;
	private final TopicPagerService topicPagerService;
	
	@Autowired
	public PagerController(PagerService service, PagerCommentService commentService, TopicService topicService, TopicPagerService topicPagerService) {
		super(service);
		this.service = service;
		this.topicService = topicService;
		this.commentService = commentService;
		this.topicPagerService = topicPagerService;
	}
	
	@Override
	protected Class<PagerItem> itemClass() {
		return PagerItem.class;
	}

	@Override
	@GridStandardDefinition(
			insertClass = PagerEditor.class, 
			updateClass = PagerEditor.class, 
			detailClass = PagerDetail.class)
	protected PagerService initLayoutGrid(LayoutGridRegister register) throws Exception {

//		DialogInsertHandler.toolbar(register, service, PagerEditor.class);
//		OperateIdsHandler.resume(register, service);
//		OperateIdsHandler.forbid(register, service);
//		OperateIdsHandler.delete(register, service);
//		
//		DialogDetailHandler.button(register, service, PagerDetail.class);
//		DialogUpdateHandler.button(register, service, PagerEditor.class);
		
		new PagerTopicDialog(register, topicPagerService, /*service, */topicService).register(register.button()).ordinal(21);
		
//		OperateIdHandler.resume(register, service);
//		OperateIdHandler.forbid(register, service);
//		OperateIdHandler.delete(register, service);
		
		//对试卷整体的进行评论评分
		CommentDialog.button(register, commentService).ordinal(70);
		register.button("导入试题", "import.do", ButtonEventType.DIALOG).ordinal(71);
		return service;
	}

	@ResponseBody
	@RequestMapping(value = "!{key}/exe.save", method = RequestMethod.POST)
	public JsonResult save(HttpServletRequest request, @PathVariable("key") String key, Long pagerId, Long[] ids){
		try{
			service.save(pagerId, ids);
		}catch(Exception ex){
			return JsonResult.error(ex);
		}
		return JsonResult.result();
	}

	@ResponseBody
	@RequestMapping(value = "!{key}/exe.ordinal", method = RequestMethod.POST)
	public JsonResult ordinal(HttpServletRequest request, @PathVariable("key") String key, Long[] ids){
		try{
			service.ordinal(ids, request.getParameterMap());
		}catch(Exception ex){
			return JsonResult.error(ex);
		}
		return JsonResult.result();
	}

	@ResponseBody
	@RequestMapping(value = "!{key}/exe.optimize", method = RequestMethod.POST)
	public JsonResult optimize(HttpServletRequest request, @PathVariable("key") String key, Long id){
		try{
			service.optimize(id);
		}catch(Exception ex){
			return JsonResult.error(ex);
		}
		return JsonResult.result();
	}
}
