package cn.bonoon.controllers.pager;

import cn.bonoon.controllers.topic.TopicDetail;
import cn.bonoon.controllers.topic.TopicItem;
import cn.bonoon.core.TopicService;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.support.OperandSupport;
import cn.bonoon.kernel.web.ButtonEventType;
import cn.bonoon.kernel.web.ButtonRefreshType;
import cn.bonoon.kernel.web.controllers.BaseButtonResolver;
import cn.bonoon.kernel.web.controllers.FormButtonResolver;
import cn.bonoon.kernel.web.handlers.DialogDetailHandler;
import cn.bonoon.kernel.web.handlers.DialogGridHandler;
import cn.bonoon.kernel.web.handlers.HandlerRegister;
import cn.bonoon.kernel.web.html.grid.StandardGridBuilder;

public class PagerTopicSearchDialog extends DialogGridHandler<TopicEntity>{

	public PagerTopicSearchDialog(HandlerRegister register, TopicService service) throws Exception {
		super(register, service, TopicItem.class);
	}

	@Override
	protected void register(BaseButtonResolver resolver, StandardGridBuilder builder) throws Exception {
		set("选择试卷题目", true);
		size(660, 480);
		resolver.setName("选择题目");
		resolver.setIconCls("icon-search");
		
		FormButtonResolver dbrjs = new FormButtonResolver();
		dbrjs.setName("保存");
		dbrjs.setKey(OperandSupport.OPERAND_NOT);
		dbrjs.setEventType(ButtonEventType.POST);
		dbrjs.setRefreshType(ButtonRefreshType.FINISH);
		dbrjs.setUrl("exe.save");
		//这里刷新的应该是父对话框的列表
		dbrjs.setAfterOperate(parentRegister.refreshParentComponenet() + closeDialog);
		StringBuilder before = new StringBuilder();
		builder.multipleSelect(before, dbrjs, null);
		before.append("__data['pagerId']=").append(relatedValue).append(';');
		dbrjs.setBeforeOperate(before.toString());
		addButton(dbrjs);

		DialogDetailHandler.button(currentRegister, service, TopicDetail.class);
		super.register(resolver, builder);
	}
}
