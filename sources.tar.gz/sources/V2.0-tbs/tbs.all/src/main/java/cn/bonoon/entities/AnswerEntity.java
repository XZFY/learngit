package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

@Entity
@Table(name = "T_ANSWER")

public class AnswerEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4034886435944458216L;

	@Column(name = "C_CREATORID")
	private Long creatorId;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CREATEAT")
	private Date createAt;
	
	/**
	 * 如果类型为试卷，则表示是试卷的ID或者为空，如果是练习，则表示为章节的ID
	 */
	@Column(name = "C_FROMID")
	private Long fromId;
	
	@Column(name = "C_NAME")
	private String name;
	
	@Enumerated
	@Column(name = "C_TYPE")
	private AnswerType type;
	
	/**
	 * 总的累计的已用时间
	 */
	@Column(name = "C_TIMESPENT")
	private long timeSpent;
	
	/**
	 * 刷新的时间，刷新后会自动更新currentTimeSpent字段
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_REFRESHAT")
	private Date refreshAt;
	
	/**
	 * 启动或重新启动的开始时间
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_RESETAT")
	private Date resetAt;
	
	/**
	 * 当前正在进行的已用时间的累计
	 */
	@Column(name = "C_CURRENTTIMESPENT")
	private long currentTimeSpent;
	
	@Column(name = "C_CONTENT", columnDefinition="TEXT")
	@Basic(fetch = FetchType.LAZY)
	private String content;
	
	@Column(name = "C_TOTAL")
	private int total;
	
	@Column(name = "C_RIGHTCOUNT")
	private int rightCount;
	
	@Column(name = "C_WRONGCOUNT")
	private int wrongCount;
	
	@Column(name = "C_GIVEUPCOUNT")
	private int giveupCount;
	
	/**
	 * <pre>
	 * 0-未开始
	 * 1-正在进行
	 * 2-结束
	 * 3-放弃
	 * </pre>
	 */
	@Column(name = "C_STATUS")
	private int status;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_FINISHAT")
	private Date finishAt;
	
	public Date getCreateAt() {
		return createAt;
	}
	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}
	public long getTimeSpent() {
		return timeSpent;
	}
	public void setTimeSpent(long timeSpent) {
		this.timeSpent = timeSpent;
	}
	public Date getRefreshAt() {
		return refreshAt;
	}
	public void setRefreshAt(Date refreshAt) {
		this.refreshAt = refreshAt;
	}
	public Date getResetAt() {
		return resetAt;
	}
	public void setResetAt(Date resetAt) {
		this.resetAt = resetAt;
	}
	public long getCurrentTimeSpent() {
		return currentTimeSpent;
	}
	public void setCurrentTimeSpent(long currentTimeSpent) {
		this.currentTimeSpent = currentTimeSpent;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getRightCount() {
		return rightCount;
	}
	public void setRightCount(int rightCount) {
		this.rightCount = rightCount;
	}
	public int getWrongCount() {
		return wrongCount;
	}
	public void setWrongCount(int wrongCount) {
		this.wrongCount = wrongCount;
	}
	public int getGiveupCount() {
		return giveupCount;
	}
	public void setGiveupCount(int giveupCount) {
		this.giveupCount = giveupCount;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Date getFinishAt() {
		return finishAt;
	}
	public void setFinishAt(Date finishAt) {
		this.finishAt = finishAt;
	}
	public AnswerType getType() {
		return type;
	}
	public void setType(AnswerType type) {
		this.type = type;
	}
	public Long getFromId() {
		return fromId;
	}
	public void setFromId(Long fromId) {
		this.fromId = fromId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getCreatorId() {
		return creatorId;
	}
	public void setCreatorId(Long creatorId) {
		this.creatorId = creatorId;
	}
//	public String getCreatorName() {
//		return creatorName;
//	}
//	public void setCreatorName(String creatorName) {
//		this.creatorName = creatorName;
//	}
//	public String getAreaKeys() {
//		return areaKeys;
//	}
//	public void setAreaKeys(String areaKeys) {
//		this.areaKeys = areaKeys;
//	}
//	public String getAreaValues() {
//		return areaValues;
//	}
//	public void setAreaValues(String areaValues) {
//		this.areaValues = areaValues;
//	}
//	public String getGroupKeys() {
//		return groupKeys;
//	}
//	public void setGroupKeys(String groupKeys) {
//		this.groupKeys = groupKeys;
//	}
//	public String getGroupValues() {
//		return groupValues;
//	}
//	public void setGroupValues(String groupValues) {
//		this.groupValues = groupValues;
//	}
//	public String getKnowledgeKeys() {
//		return knowledgeKeys;
//	}
//	public void setKnowledgeKeys(String knowledgeKeys) {
//		this.knowledgeKeys = knowledgeKeys;
//	}
//	public String getKnowledgeValues() {
//		return knowledgeValues;
//	}
//	public void setKnowledgeValues(String knowledgeValues) {
//		this.knowledgeValues = knowledgeValues;
//	}
//	public String getPointKeys() {
//		return pointKeys;
//	}
//	public void setPointKeys(String pointKeys) {
//		this.pointKeys = pointKeys;
//	}
//	public String getPointValues() {
//		return pointValues;
//	}
//	public void setPointValues(String pointValues) {
//		this.pointValues = pointValues;
//	}
}
