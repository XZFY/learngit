package cn.bonoon.core.infos;

import java.util.List;

import org.springframework.ui.Model;

import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.entities.ImprovePracticeEntity;

public class SisterInfo {
	
	private final String result;
	private final boolean onlyMessage;
	private List<String> topics;
	private ImprovePracticeEntity improve;
	
	public SisterInfo(String result){
		this.result = result;
		this.onlyMessage = true;
	}
	
	public SisterInfo(AnswerEntity answer, ImprovePracticeEntity improve, List<String> topics) {
		this.onlyMessage = false;
		this.result = answer.getName();
		
		this.topics = topics;
		this.improve = improve;
	}

	public boolean isOnlyMessage() {
		return onlyMessage;
	}
	
	@Override
	public String toString() {
		return result;
	}
	
	public void render(Model model){
		model.addAttribute("render", this);
		if(!onlyMessage){
			model.addAttribute("id", improve.getId());
			model.addAttribute("topics", topics);
			//-------------------------------------------------
	//		model.addAttribute("topic", topics);
			model.addAttribute("topicNumber", 1);
			model.addAttribute("importantMark", false);
		}
	}
}
