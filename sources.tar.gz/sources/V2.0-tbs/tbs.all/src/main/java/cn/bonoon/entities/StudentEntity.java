package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;
import cn.bonoon.kernel.support.entities.EntityDeletable;
import cn.bonoon.kernel.support.entities.EntityScopable;

//学员
@Entity
@Table(name = "T_STUDENT")
public class StudentEntity extends AbstractPersistable implements EntityDeletable, EntityScopable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6429385568923360085L;

	//学号，在一个培训机构里是唯一的，也可能是教育档案的学号
	@Column(name = "C_SID", length = 50)
	private String sid;
	
//	@ManyToOne
//	@JoinColumn(name = "R_INSTITUTION_ID")
//	private TrainingInstitutionEntity institution;

	@ManyToOne
	@JoinColumn(name = "R_MEMBER_ID")
	private MemberEntity member;
	
	@Column(name = "C_CREATORID")
	private Long creatorId;

	@Column(name = "C_OWNERID")
	private long ownerId;
	
	@Column(name = "C_DELETED")
	private boolean deleted;
	
	@Column(name = "C_REMARK", length = 600)
	private String remark;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CREATEAT")
	private Date createAt;

	//报名、注册时间
	@Temporal(TemporalType.DATE)
	@Column(name = "C_REGISTERAT")
	private Date registerAt;
	
	/**
	 * 该学生来源的类型，是：自己报名、介绍、机构自己登记等
	 */
	@Column(name = "C_SOURCETYPE", length = 50)
	private String sourceType;

	//状态：报名、正常、已毕业、肄业
	@Column(name = "C_STATUS")
	private int status;

	public Long getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(Long creatorId) {
		this.creatorId = creatorId;
	}

	public long getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(long ownerId) {
		this.ownerId = ownerId;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

//	public TrainingInstitutionEntity getInstitution() {
//		return institution;
//	}
//
//	public void setInstitution(TrainingInstitutionEntity institution) {
//		this.institution = institution;
//	}

	public MemberEntity getMember() {
		return member;
	}

	public void setMember(MemberEntity member) {
		this.member = member;
	}

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Date getRegisterAt() {
		return registerAt;
	}

	public void setRegisterAt(Date registerAt) {
		this.registerAt = registerAt;
	}
	
}
