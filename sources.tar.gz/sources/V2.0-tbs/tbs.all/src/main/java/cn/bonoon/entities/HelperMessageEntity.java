package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

@Entity
@Table(name = "T_HELPERMESSAGE")
public class HelperMessageEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8422086968689223808L;

	@Column(name = "C_CONTENT")
	private String content;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CREATEAT")
	private Date createAt;
	
	@ManyToOne
	@JoinColumn(name = "R_MEMBER_ID")
	private MemberEntity member;

	@Column(name = "C_READ")
	private boolean read;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	public MemberEntity getMember() {
		return member;
	}

	public void setMember(MemberEntity member) {
		this.member = member;
	}

	public boolean isRead() {
		return read;
	}

	public void setRead(boolean read) {
		this.read = read;
	}
}
