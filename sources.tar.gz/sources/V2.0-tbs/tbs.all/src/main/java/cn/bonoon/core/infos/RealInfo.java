package cn.bonoon.core.infos;

public class RealInfo extends AbstractRecord{
	private Long id;
	private String name;
	/**
	 * 是否已经购买
	 */
	private boolean purchased;
//	/**
//	 * 如果还没购买，则需要多少积分才能购买
//	 */
//	private int points;
	
	/**
	 * 积分是否足够，如果足够则可以直接使用积分来购买
	 */
//	private boolean canPurchase;//不需要
	
	private String status;
	
//	private long myPoints;
	
	private long amount;
	//可用的
//	private long available;
	//是需要使用钻石购买还是使用金币购买
	private boolean diamond;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isPurchased() {
		return purchased;
	}

	public void setPurchased(boolean purchased) {
		this.purchased = purchased;
	}

//	public int getPoints() {
//		return points;
//	}
//
//	public void setPoints(int points) {
//		this.points = points;
//	}
//
//	public boolean isCanPurchase() {
//		return canPurchase;
//	}
//
//	public void setCanPurchase(boolean canPurchase) {
//		this.canPurchase = canPurchase;
//	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

//	public long getMyPoints() {
//		return myPoints;
//	}
//
//	public void setMyPoints(long myPoints) {
//		this.myPoints = myPoints;
//	}
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

//	public long getAvailable() {
//		return available;
//	}
//
//	public void setAvailable(long available) {
//		this.available = available;
//	}

	public boolean isDiamond() {
		return diamond;
	}

	public void setDiamond(boolean diamond) {
		this.diamond = diamond;
	}
	
}
