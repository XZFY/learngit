package cn.bonoon.controllers.pager;

import cn.bonoon.kernel.annotations.OptionArray;
import cn.bonoon.kernel.annotations.ResetProperties;
import cn.bonoon.kernel.annotations.ResetProperty;

@ResetProperties({
	@ResetProperty(value = "name", name = "标题"),
	@ResetProperty(value = "trial", name = "允许试用"),
	@ResetProperty(value = "diamond", name = "钻石"),
	@ResetProperty(value = "type", name = "类型", 
		options = @OptionArray({"试卷", "真题试卷", "竞赛试卷", "临时试卷"})),
	@ResetProperty(value = "amount", name = "积分/钻石"),
//	@ResetProperty(value = "cash", name = "现金"),
	@ResetProperty(value = "status", name = "状态", 
		options = @OptionArray({"草稿", "正常", "不可用"})),
	@ResetProperty(value = "count", name = "题目数"),
	@ResetProperty(value = "createAt", name = "创建时间"),
	@ResetProperty(value = "remark", name = "备注")
})
public interface PagerDefine {

}
