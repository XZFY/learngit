package cn.bonoon.services;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.PagerService;
import cn.bonoon.entities.PagerEntity;
import cn.bonoon.entities.PagerTopicEntity;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.support.services.AbstractService;

@Service
@Transactional(readOnly = true)
public class PagerServiceImpl extends AbstractService<PagerEntity> implements PagerService {

	@Override
	@Transactional
	public PagerTopicEntity save(Long id, TopicEntity topic) {
		PagerEntity pager = entityManager.find(PagerEntity.class, id);
		int count = pager.getCount() + 1;
		
		PagerTopicEntity tpe = new PagerTopicEntity();
		tpe.setPager(pager);
		tpe.setTopic(topic);
		tpe.setOrdinal(count);
		entityManager.persist(tpe);
		
		int dif = topic.getDifficulty();
		if(dif > 0){
			double total = pager.getTotalDifficulty() + dif;
			double max = pager.getMaxDifficulty();
			double min = pager.getMinDifficulty();
			if(dif > max){
				max = dif;
			}else if(min > dif){
				min = dif;
			}
			
			pager.setAvgDifficulty(total / count);
			pager.setTotalDifficulty(total);
			pager.setMaxDifficulty(max);
			pager.setMinDifficulty(min);
		}
		
		pager.setCount(count);
		entityManager.merge(pager);
		return tpe;
	}
	
	@Override
	@Transactional
	public void save(Long id, Long[] ids) {
		List<Long> exsits = __list(Long.class, "select x.topic.id from PagerEntity x where x.pager.id=?", id);
		PagerEntity pager = entityManager.find(PagerEntity.class, id);
		int count = pager.getCount();
		double total = pager.getTotalDifficulty();
		double max = pager.getMaxDifficulty();
		double min = pager.getMinDifficulty();
		for(Long tid : ids){
			if(exsits.contains(tid)){
				//过滤掉那些已经添加的
				continue;
			}
			count++;
			TopicEntity topic = entityManager.find(TopicEntity.class, tid);
			PagerTopicEntity tpe = new PagerTopicEntity();
			tpe.setPager(pager);
			tpe.setTopic(topic);
			tpe.setOrdinal(count);
			entityManager.persist(tpe);
			
			int dif = topic.getDifficulty();
			if(dif > 0){
				total += dif;
				if(dif > max){
					max = dif;
				}else if(min > dif){
					min = dif;
				}
			}
		}
		pager.setCount(count);
		pager.setAvgDifficulty(total / count);
		pager.setTotalDifficulty(total);
		pager.setMaxDifficulty(max);
		pager.setMinDifficulty(min);
		entityManager.merge(pager);
	}

	@Override
	@Transactional
	public void ordinal(Long[] ids, Map<?, ?> parameterMap) {
		for(Long ptid : ids){
			Object val = parameterMap.get(ptid);
			if(null != val){
				__exec("update PagerEntity set ordinal=" + val + " where id=" + ptid);
			}
		}
		//要刷新一下，不然在处理结束后重新加载列表，可能值还没更新过来
		entityManager.flush();
	}

	@Override
	@Transactional
	public void optimize(Long id) {
		List<Long> ids = __list(Long.class, "select x.id from PagerEntity x where x.pager.id=? order by x.ordinal asc", id);
		int ordinal = 1;
		for(Long ptid : ids){
			__exec("update PagerEntity set ordinal=" + ordinal + " where id=" + ptid);
			ordinal++;
		}
		entityManager.flush();
	}

}
