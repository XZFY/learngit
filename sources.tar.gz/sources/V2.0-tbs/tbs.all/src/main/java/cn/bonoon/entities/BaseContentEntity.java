package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractEntity;

@MappedSuperclass
public class BaseContentEntity extends AbstractEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2795081091868836688L;
	//是否共享
	@Column(name = "C_SHARE")
	private boolean share;

	@Column(name = "C_SUBJECT", length = 1024)
	private String subject;
	
	//来源
	@Column(name = "C_SOURCE")
	private String source;

	@Column(name = "C_BROWSECOUNT")
	private int browseCount;
	
	//对该知识的收录时间
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_EMPLOYAT")
	private Date employAt;

	/**
	 * 章节
	 */
	@ManyToOne
	@JoinColumn(name = "R_CHAPTER_ID")
	private ChapterEntity chapter;
	/**
	 * 领域
	 */
	@ManyToOne
	@JoinColumn(name = "R_AREA_ID")
	private KnowledgeAreaEntity area;
	/**
	 * 知识点
	 */
	@ManyToOne
	@JoinColumn(name = "R_KNOWLEDGE_ID")
	private KnowledgePointEntity knowledge;
	/**
	 * 过程
	 */
	@ManyToOne
	@JoinColumn(name = "R_PROCESS_ID")
	private ProcessEntity process;
	/**
	 * 过程组
	 */
	@ManyToOne
	@JoinColumn(name = "R_GROUP_ID")
	private ProcessGroupEntity group;

	@Column(name = "C_PATH")
	private String path;
	
	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public ChapterEntity getChapter() {
		return chapter;
	}
	public void setChapter(ChapterEntity chapter) {
		this.chapter = chapter;
	}
	public KnowledgeAreaEntity getArea() {
		return area;
	}
	public void setArea(KnowledgeAreaEntity area) {
		this.area = area;
	}
	public KnowledgePointEntity getKnowledge() {
		return knowledge;
	}
	public void setKnowledge(KnowledgePointEntity knowledge) {
		this.knowledge = knowledge;
	}
	public ProcessEntity getProcess() {
		return process;
	}
	public void setProcess(ProcessEntity process) {
		this.process = process;
	}
	public ProcessGroupEntity getGroup() {
		return group;
	}
	public void setGroup(ProcessGroupEntity group) {
		this.group = group;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public Date getEmployAt() {
		return employAt;
	}
	public void setEmployAt(Date employAt) {
		this.employAt = employAt;
	}
	public boolean isShare() {
		return share;
	}
	public void setShare(boolean share) {
		this.share = share;
	}

	public int getBrowseCount() {
		return browseCount;
	}

	public void setBrowseCount(int browseCount) {
		this.browseCount = browseCount;
	}
	
}
