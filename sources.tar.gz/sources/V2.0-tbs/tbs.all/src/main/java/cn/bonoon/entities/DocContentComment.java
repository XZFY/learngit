package cn.bonoon.entities;

import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name = "CT_DOCCONTENT")
public class DocContentComment extends AbstractComment<DocContentEntity>{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1165331959706562405L;
}
