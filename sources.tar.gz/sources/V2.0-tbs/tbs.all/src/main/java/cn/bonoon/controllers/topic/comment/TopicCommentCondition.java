package cn.bonoon.controllers.topic.comment;

import cn.bonoon.kernel.query.PageCondition;
import cn.bonoon.kernel.web.annotations.condition.ConditionContent;

public class TopicCommentCondition extends PageCondition implements TopicCommentDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4786101197264360635L;

	@ConditionContent(value = "内容", ordinal = 0)
	private String searchContent;

	public String getSearchContent() {
		return searchContent;
	}

	public void setSearchContent(String searchContent) {
		this.searchContent = searchContent;
	}
}
