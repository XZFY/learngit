package cn.bonoon.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.IStudentInsert;
import cn.bonoon.core.IStudentRecommend;
import cn.bonoon.core.StudentService;
import cn.bonoon.entities.ClassesEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.StudentEntity;
import cn.bonoon.entities.StudyingEntity;
import cn.bonoon.entities.plugins.FlagType;
import cn.bonoon.kernel.events.OperateEvent;
import cn.bonoon.kernel.support.PasswordVerifier;
import cn.bonoon.kernel.support.services.AbstractService;
import cn.bonoon.kernel.util.MD5Util;

@Service
@Transactional(readOnly = true)
public class StudentServiceImpl extends AbstractService<StudentEntity> implements StudentService {

	@Autowired
	private PasswordVerifier passwordVerifier;
	
	@Override
	protected StudentEntity __update(OperateEvent event, StudentEntity entity) {
		StudentEntity be = super.__update(event, entity);

		Object sou = event.getSource();
		if(sou instanceof IStudentRecommend){
			return __editor(event, (IStudentRecommend)sou, be);
		}
		
		return be;
	}
	
	@Override
	protected StudentEntity __save(OperateEvent event, StudentEntity entity) {
		IStudentInsert pe = (IStudentInsert)event.getSource();
		MemberEntity me = new MemberEntity();
		me.setName(pe.getName());
		me.setLoginName(pe.getLoginName());
		me.setCreateAt(event.now());
		me.setKey(MD5Util.randomMD5String());
		me.setOwnerId(event.toOwnerId());
		me.setCreatorId(event.getId());
		me.setCreatorName(event.getUsername());
		me.setFlag(FlagType.CUSTOM);
		me.setStatus(STATUS_NORMAL);
		me.setAvailablePoints(pe.getPoints());
		me.setTotalPoints(pe.getPoints());
		me.setLevelPoints(pe.getPoints());
		me.setPhone(pe.getPhone());
		
		passwordVerifier.setPassword(me, pe.getLoginPwd(), pe.getConfimPwd());

		entityManager.persist(me);
		entity.setMember(me);
		return __editor(event, pe, super.__save(event, entity));
	}

	private StudentEntity __editor(OperateEvent event, IStudentRecommend pe, StudentEntity be) {
		Long cid = pe.getClasses();
		ClassesEntity ce = null;
		if(null != cid){
			ce = entityManager.find(ClassesEntity.class, cid);
		}
		if(null != ce){
			StudyingEntity se = new StudyingEntity();
			se.setClasses(ce);
			se.setCreateAt(event.now());
			se.setSeatNumber(pe.getSeatNumber());
			se.setStatus(STATUS_NORMAL);
			se.setStudent(be);
			entityManager.persist(se);
		}
		return be;
	}
}
