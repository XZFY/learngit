package cn.bonoon.controllers.topic.comment;

import cn.bonoon.kernel.annotations.Cutoff;
import cn.bonoon.kernel.annotations.Transform;
import cn.bonoon.kernel.support.models.AbstractItem;
import cn.bonoon.kernel.web.annotations.grid.AsColumn;
import cn.bonoon.kernel.web.annotations.grid.AsDataGrid;

@AsDataGrid(condition = TopicCommentCondition.class)
@Transform
public class TopicCommentItem extends AbstractItem implements TopicCommentDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5426700379847454180L;

	@AsColumn(width = 300, ordinal = 0)
	@Cutoff(40)
	private String content;

	@AsColumn(width = 100, ordinal = 10)
	private String creatorName;

	@AsColumn(width = 120, ordinal = 11)
	private String createAt;
	
	@AsColumn(width = 300, ordinal = 20)
	@Cutoff(40)
	private String cnContent;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getCreateAt() {
		return createAt;
	}

	public void setCreateAt(String createAt) {
		this.createAt = createAt;
	}

	public String getCnContent() {
		return cnContent;
	}

	public void setCnContent(String cnContent) {
		this.cnContent = cnContent;
	}

}
