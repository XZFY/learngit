package cn.bonoon.core.infos;

import cn.bonoon.entities.MediaContentEntity;
import cn.bonoon.kernel.util.StringHelper;

public class VideoInfo {
	
	private Long id;
	private String subject;
	private String path;
	private String ext;
	private String name;
	private String employAt;
	private String attrs = "";
	private String userName;
	private boolean outterLink;
	
	public VideoInfo(MediaContentEntity vdo) {
		id = vdo.getId();
		name = vdo.getName();
		userName = vdo.getCreatorName();
		outterLink = vdo.isOutterLink();
		subject = vdo.getSubject();
		employAt = StringHelper.date2String(vdo.getEmployAt());
		path = vdo.getPath();
		ext = vdo.getFilesuffix();
		if(null != vdo.getArea()){
			attrs = "<span title='知识领域'>" + vdo.getArea().getName() + "</span>";
		}
		if(null != vdo.getGroup()){
			if(!attrs.isEmpty()){
				attrs += "/";
			}
			attrs += "<span title='过程组'>" + vdo.getGroup().getName() + "</span>";
		}
		if(null != vdo.getProcess()){
			if(!attrs.isEmpty()){
				attrs += "/";
			}
			attrs += "<span title='过程'>" + vdo.getProcess().getName() + "</span>";
		}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getExt() {
		return ext;
	}

	public void setExt(String ext) {
		this.ext = ext;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmployAt() {
		return employAt;
	}

	public void setEmployAt(String employAt) {
		this.employAt = employAt;
	}

	public String getAttrs() {
		return attrs;
	}

	public void setAttrs(String attrs) {
		this.attrs = attrs;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public boolean isOutterLink() {
		return outterLink;
	}

	public void setOutterLink(boolean outterLink) {
		this.outterLink = outterLink;
	}

}
