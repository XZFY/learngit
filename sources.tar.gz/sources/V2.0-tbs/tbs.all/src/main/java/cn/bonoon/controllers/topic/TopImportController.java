package cn.bonoon.controllers.topic;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import cn.bonoon.controllers.AbstractImportController;
import cn.bonoon.core.infos.TopicTypeSetting;
import cn.bonoon.kernel.web.models.DialogModel;
import cn.bonoon.kernel.web.models.JsonResult;

/**
 * 用于导入题目
 * @author jackson
 *
 */
@Controller
@RequestMapping("s/pmp/topic")
public class TopImportController extends AbstractImportController{

	@RequestMapping(value = "!{mid}/import.dlg", method = GET)
	public ModelAndView excel(HttpServletRequest request, @PathVariable("mid") String mid, String gridid){
		DialogModel model = new DialogModel(mid, request);
		model.addObject("gridid", gridid);
		return model.execute("mgr/import-topic");
	}

	@ResponseBody
	@RequestMapping(value = "!{mid}/parse.do", method = POST)
	public JsonResult parse(@PathVariable("mid") String mid, TopicTypeSetting tts, MultipartFile excelFile, MultipartFile annexFile){
		try{
			if(null != excelFile && !excelFile.isEmpty()){
				String fn = excelFile.getOriginalFilename();
				if(fn.endsWith(".xls") || fn.endsWith(".xlsx")){
					importService.importExcel(getUser(), __parse(excelFile, false), tts);
				}
			}
			unzip(annexFile);
			return JsonResult.result();
		}catch(Exception ex){
			ex.printStackTrace();
			return JsonResult.error(ex);
		}
	}
}
