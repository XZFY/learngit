package cn.bonoon.core.infos;


public class ResultItem extends AbstractResult implements Comparable<ResultItem>{
	private Long id;
	private String name;
	private int ordinal;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getOrdinal() {
		return ordinal;
	}
	public void setOrdinal(int ordinal) {
		this.ordinal = ordinal;
	}
	@Override
	public int compareTo(ResultItem o) {
		return ordinal - o.ordinal;
	}
}
