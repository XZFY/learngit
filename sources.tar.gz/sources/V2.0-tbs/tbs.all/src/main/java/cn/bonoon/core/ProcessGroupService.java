package cn.bonoon.core;

import cn.bonoon.entities.ProcessGroupEntity;
import cn.bonoon.kernel.support.services.GenericService;

public interface ProcessGroupService extends GenericService<ProcessGroupEntity>{

	String getName(Long id);

}
