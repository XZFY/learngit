package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

@Entity
@Table(name = "T_TRANSACTION")
public class TransactionEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6003541599917524418L;
	
	@Column(name = "R_USERID")
	private Long userId;
	
	@Column(name = "C_REMARK")
	private String remark;
	
	@Column(name = "C_AMOUNT")
	private int amount;
	//总积分，增加或扣除后的积分

	@Column(name = "C_TOTAL")
	private long total;
	
	@Column(name = "C_AVAILABLE")
	private long available;
	
	//等级积分的增加，有些情况下不需要增加
	//这里不等于member里的levelPoints
	@Column(name = "C_LEVELPOINTS")
	private int levelPoints;

	@Column(name = "C_CREATORID")
	private Long creatorId;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CREATEAT", nullable = false)
	private Date createAt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_TRANSACTIONAT")
	private Date transactionAt;
	
	@Enumerated
	@Column(name = "C_TRANSACTIONTYPE")
	private TransactionType transactionType;

	@Enumerated
	@Column(name = "C_CURRENCYTYPE")
	private CurrencyType currencyType;
	
	/**
	 * 这个表示应该是增加或减少相应的积分
	 */
	@Column(name = "C_DEDUCT")
	private boolean deduct;
	
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
//	public int getPoints() {
//		return points;
//	}
//	public void setPoints(int points) {
//		this.points = points;
//	}
	public Date getCreateAt() {
		return createAt;
	}
	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}
//	public TransactionType getType() {
//		return type;
//	}
//	public void setType(TransactionType type) {
//		this.type = type;
//	}
	public boolean isDeduct() {
		return deduct;
	}
	public void setDeduct(boolean deduct) {
		this.deduct = deduct;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
//	public long getTotalPoints() {
//		return totalPoints;
//	}
//	public void setTotalPoints(long totalPoints) {
//		this.totalPoints = totalPoints;
//	}
//	public long getAvailablePoints() {
//		return availablePoints;
//	}
//	public void setAvailablePoints(long availablePoints) {
//		this.availablePoints = availablePoints;
//	}
	public Long getCreatorId() {
		return creatorId;
	}
	public void setCreatorId(Long creatorId) {
		this.creatorId = creatorId;
	}
	public Date getTransactionAt() {
		return transactionAt;
	}
	public void setTransactionAt(Date transactionAt) {
		this.transactionAt = transactionAt;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public long getTotal() {
		return total;
	}
	public void setTotal(long total) {
		this.total = total;
	}
	public long getAvailable() {
		return available;
	}
	public void setAvailable(long available) {
		this.available = available;
	}
	public int getLevelPoints() {
		return levelPoints;
	}
	public void setLevelPoints(int levelPoints) {
		this.levelPoints = levelPoints;
	}
	public TransactionType getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}
	public CurrencyType getCurrencyType() {
		return currencyType;
	}
	public void setCurrencyType(CurrencyType currencyType) {
		this.currencyType = currencyType;
	}
	
}
