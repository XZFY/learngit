package cn.bonoon.controllers.topic.comment;

import cn.bonoon.kernel.annotations.Transform;
import cn.bonoon.kernel.web.annotations.form.FormDetail;
import cn.bonoon.kernel.web.annotations.form.PropertyDetail;

@FormDetail(width = 400)
@Transform
public class TopicCommentDetail implements TopicCommentDefine{

	@PropertyDetail(10)
	private String enContent;
	
	@PropertyDetail(11)
	private String cnContent;
	
	@PropertyDetail(1)
	private String content;
	
	@PropertyDetail(2)
	private String creatorName;
	
	@PropertyDetail(3)
	private String createAt;

	public String getEnContent() {
		return enContent;
	}

	public void setEnContent(String enContent) {
		this.enContent = enContent;
	}

	public String getCnContent() {
		return cnContent;
	}

	public void setCnContent(String cnContent) {
		this.cnContent = cnContent;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getCreateAt() {
		return createAt;
	}

	public void setCreateAt(String createAt) {
		this.createAt = createAt;
	}
}
