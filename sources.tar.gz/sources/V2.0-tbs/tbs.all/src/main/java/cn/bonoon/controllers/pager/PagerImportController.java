package cn.bonoon.controllers.pager;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import cn.bonoon.controllers.AbstractImportController;
import cn.bonoon.kernel.web.models.DialogModel;
import cn.bonoon.kernel.web.models.JsonResult;

/**
 * 用于导入试卷的题目
 * @author jackson
 *
 */
@Controller
@RequestMapping("s/tms/pager")
public class PagerImportController extends AbstractImportController{
	
	@RequestMapping(value = "!{mid}/import.do", method = GET)
	public ModelAndView excel(HttpServletRequest request, @PathVariable("mid") String mid, Long id, String gridid){
		DialogModel model = new DialogModel(mid, request);
		model.addForm(id);
		model.addObject("gridid", gridid);
		return model.execute("mgr/import-pager");
	}

	@ResponseBody
	@RequestMapping(value = "!{mid}/{id}!parse.do", method = POST)
	public JsonResult parse(@PathVariable("mid") String mid, @PathVariable("id") Long id, MultipartFile excelFile, MultipartFile annexFile, boolean cbcleanold){
		try{
			if(null != excelFile && !excelFile.isEmpty()){
				String fn = excelFile.getOriginalFilename();
				if(fn.endsWith(".xls") || fn.endsWith(".xlsx")){
					importService.importExcel(getUser(), id, __parse(excelFile, true), cbcleanold);
				}
			}
			unzip(annexFile);
			return JsonResult.result();
		}catch(Exception ex){
			ex.printStackTrace();
			return JsonResult.error(ex);
		}
	}
}
