package cn.bonoon.controllers;

import javax.servlet.http.HttpServletRequest;

import cn.bonoon.kernel.security.LogonUser;

public class JiathisInfo {

	public JiathisInfo(HttpServletRequest request, LogonUser user){
		//已经登录
		StringBuilder sbUrl = new StringBuilder();
		sbUrl.append(request.getScheme()).append("://");
		sbUrl.append(request.getServerName()).append(':').append(request.getServerPort());
		sbUrl.append(request.getContextPath());
		
//		LogonUser user = getUser();
		if(null != user){
			sbUrl.append("/pmp/").append(user.get("user-key")).append("!introduce");
		}
		
		setUrl(sbUrl.toString());
	}
	
	private String url;
	
	private String summary;
	
	private String title;
	
	private String topical;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTopical() {
		return topical;
	}

	public void setTopical(String topical) {
		this.topical = topical;
	}
	
}
