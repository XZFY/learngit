package cn.bonoon.entities;

import javax.persistence.Entity;
import javax.persistence.Table;

import cn.bonoon.kernel.support.entities.AbstractEntity;

/**
 * 题目所处的章节
 * @author jackson
 *
 */
@Entity
@Table(name = "T_CHAPTER")
public class ChapterEntity extends AbstractEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3022936096316285496L;

}
