package cn.bonoon.controllers.topic;

import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.entities.KnowledgePointEntity;
import cn.bonoon.entities.ProcessEntity;
import cn.bonoon.entities.ProcessGroupEntity;
import cn.bonoon.kernel.annotations.Transform;
import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.annotations.Unique;
import cn.bonoon.kernel.support.models.ObjectEditor;
import cn.bonoon.kernel.web.annotations.AutoDataLoader;
import cn.bonoon.kernel.web.annotations.WithDialog;
import cn.bonoon.kernel.web.annotations.components.AsCheckbox;
import cn.bonoon.kernel.web.annotations.components.AsComboBox;
import cn.bonoon.kernel.web.annotations.components.AsSelector;
import cn.bonoon.kernel.web.annotations.components.AsTextArea;
import cn.bonoon.kernel.web.annotations.components.SelectorOption;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

@WithDialog(height = 480)
@Transform
@FormEditor(value = 2, headWidth = 120, width = 250)
//@FormGroup(value = {
//		@FormGroupItem(name = "基本信息", length = 8),
//		@FormGroupItem(name = "题目(中)", length = 7),
//		@FormGroupItem(name = "题目(英)", length = 7)
//})
public class TopicEditor extends ObjectEditor implements TopicDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2828604631524051033L;
	
	@TransformField
	@PropertyEditor(colspan = 1, value = 40)
//	@AsEditor(toolbar = EditorToolbar.SIMPLE, height = 80)
	@AsTextArea
	private String cnContent;

	@TransformField
	@PropertyEditor(colspan = 1, value = 41)
//	@AsEditor(toolbar = EditorToolbar.SIMPLE, height = 55)
	@AsTextArea
	private String cnOptionA;
	
	@TransformField
	@PropertyEditor(colspan = 1, value = 42)
//	@AsEditor(toolbar = EditorToolbar.SIMPLE, height = 55)
	@AsTextArea
	private String cnOptionB;
	
	@TransformField
	@PropertyEditor(colspan = 1, value = 43)
//	@AsEditor(toolbar = EditorToolbar.SIMPLE, height = 55)
	@AsTextArea
	private String cnOptionC;
	
	@TransformField
	@PropertyEditor(colspan = 1, value = 44)
//	@AsEditor(toolbar = EditorToolbar.SIMPLE, height = 55)
	@AsTextArea
	private String cnOptionD;
	
	@TransformField
	@PropertyEditor(colspan = 1, value = 45)
//	@AsEditor(toolbar = EditorToolbar.SIMPLE, height = 80)
	@AsTextArea
	private String cnExplanation;

	@TransformField
	@PropertyEditor(colspan = 1, value = 46, width = 300)
	@PropertyHelper(value = "题目的中文图片", type = HelperType.DIRECT)
	private String cnPicture;

	@TransformField
	@PropertyEditor(colspan = 1, value = 50)
//	@AsEditor(toolbar = EditorToolbar.SIMPLE, height = 80)
	@AsTextArea
	private String enContent;

	@TransformField
	@PropertyEditor(colspan = 1, value = 51)
//	@AsEditor(toolbar = EditorToolbar.SIMPLE, height = 55)
	@AsTextArea
	private String enOptionA;
	
	@TransformField
	@PropertyEditor(colspan = 1, value = 52)
//	@AsEditor(toolbar = EditorToolbar.SIMPLE, height = 55)
	@AsTextArea
	private String enOptionB;
	
	@TransformField
	@PropertyEditor(colspan = 1, value = 53)
//	@AsEditor(toolbar = EditorToolbar.SIMPLE, height = 55)
	@AsTextArea
	private String enOptionC;
	
	@TransformField
	@PropertyEditor(colspan = 1, value = 54)
//	@AsEditor(toolbar = EditorToolbar.SIMPLE, height = 55)
	@AsTextArea
	private String enOptionD;
	
	@TransformField
	@PropertyEditor(colspan = 1, value = 55)
//	@AsEditor(toolbar = EditorToolbar.SIMPLE, height = 80)
	@AsTextArea
	private String enExplanation;

	@TransformField
	@PropertyEditor(colspan = 1, value = 56, width = 300)
	@PropertyHelper(value = "如果中英文图片相同，请设置相同", type = HelperType.DIRECT)
	private String enPicture;
	
	@TransformField
	@PropertyEditor(0)
	private String name;
	
	@TransformField
	@PropertyEditor(1)
	@Unique
	private String code;

	@TransformField
	@PropertyEditor(2)
	@AsComboBox
	@AutoDataLoader(ProcessEntity.class)
	private Long process;
	
	@TransformField
	@PropertyEditor(3)
	@AsComboBox
	@AutoDataLoader(ProcessGroupEntity.class)
	private Long group;
	
	@TransformField
	@PropertyEditor(4)
	@AsComboBox
	@AutoDataLoader(KnowledgeAreaEntity.class)
	private Long area;
	
	@TransformField
	@PropertyEditor(5)
	@AsComboBox
	@AutoDataLoader(KnowledgePointEntity.class)
	private Long knowledge;
	
	@TransformField
	@PropertyEditor(11)
	@AsCheckbox("是")
	private boolean freeFast;
	@TransformField
	@PropertyEditor(12)
	@AsCheckbox("是")
	private boolean freeCombat;
	
	@TransformField
	@PropertyEditor(13)
	@AsCheckbox("是")
	private boolean praxis;
	@TransformField
	@PropertyEditor(14)
	@AsCheckbox("是")
	private boolean improve;
	
	@TransformField
	@PropertyEditor(15)
	@AsCheckbox("是")
	private boolean exam;
	
	@TransformField
	@PropertyEditor(16)
	@AsCheckbox("是")
	private boolean real;

	@TransformField
	@PropertyEditor(20)
	@AsSelector({
		@SelectorOption("A"), 
		@SelectorOption("B"), 
		@SelectorOption("C"), 
		@SelectorOption("D")
	})
	private String answer;
	
	@TransformField
	@PropertyEditor(21)
	private int difficulty;

	@TransformField
	@PropertyEditor(22)
	private String videoPath;

	@TransformField
	@PropertyEditor(value = 23, width = 50)
	@PropertyHelper(value = "一般为文件的后缀，可不填写", type = HelperType.DIRECT)
	private String videoExt;
	
	public boolean isPraxis() {
		return praxis;
	}
	public void setPraxis(boolean praxis) {
		this.praxis = praxis;
	}
	public boolean isExam() {
		return exam;
	}
	public void setExam(boolean exam) {
		this.exam = exam;
	}
	public boolean isReal() {
		return real;
	}
	public void setReal(boolean real) {
		this.real = real;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public int getDifficulty() {
		return difficulty;
	}
	public void setDifficulty(int difficulty) {
		this.difficulty = difficulty;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getProcess() {
		return process;
	}
	public void setProcess(Long process) {
		this.process = process;
	}
	public Long getGroup() {
		return group;
	}
	public void setGroup(Long group) {
		this.group = group;
	}
	public Long getArea() {
		return area;
	}
	public void setArea(Long area) {
		this.area = area;
	}
	public Long getKnowledge() {
		return knowledge;
	}
	public void setKnowledge(Long knowledge) {
		this.knowledge = knowledge;
	}
	public String getCnContent() {
		return cnContent;
	}
	public void setCnContent(String cnContent) {
		this.cnContent = cnContent;
	}
	public String getCnOptionA() {
		return cnOptionA;
	}
	public void setCnOptionA(String cnOptionA) {
		this.cnOptionA = cnOptionA;
	}
	public String getCnOptionB() {
		return cnOptionB;
	}
	public void setCnOptionB(String cnOptionB) {
		this.cnOptionB = cnOptionB;
	}
	public String getCnOptionC() {
		return cnOptionC;
	}
	public void setCnOptionC(String cnOptionC) {
		this.cnOptionC = cnOptionC;
	}
	public String getCnOptionD() {
		return cnOptionD;
	}
	public void setCnOptionD(String cnOptionD) {
		this.cnOptionD = cnOptionD;
	}
	public String getCnExplanation() {
		return cnExplanation;
	}
	public void setCnExplanation(String cnExplanation) {
		this.cnExplanation = cnExplanation;
	}
	public String getEnContent() {
		return enContent;
	}
	public void setEnContent(String enContent) {
		this.enContent = enContent;
	}
	public String getEnOptionA() {
		return enOptionA;
	}
	public void setEnOptionA(String enOptionA) {
		this.enOptionA = enOptionA;
	}
	public String getEnOptionB() {
		return enOptionB;
	}
	public void setEnOptionB(String enOptionB) {
		this.enOptionB = enOptionB;
	}
	public String getEnOptionC() {
		return enOptionC;
	}
	public void setEnOptionC(String enOptionC) {
		this.enOptionC = enOptionC;
	}
	public String getEnOptionD() {
		return enOptionD;
	}
	public void setEnOptionD(String enOptionD) {
		this.enOptionD = enOptionD;
	}
	public String getEnExplanation() {
		return enExplanation;
	}
	public void setEnExplanation(String enExplanation) {
		this.enExplanation = enExplanation;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public boolean isFreeFast() {
		return freeFast;
	}
	public void setFreeFast(boolean freeFast) {
		this.freeFast = freeFast;
	}
	public boolean isFreeCombat() {
		return freeCombat;
	}
	public void setFreeCombat(boolean freeCombat) {
		this.freeCombat = freeCombat;
	}
	public boolean isImprove() {
		return improve;
	}
	public void setImprove(boolean improve) {
		this.improve = improve;
	}
	public String getCnPicture() {
		return cnPicture;
	}
	public void setCnPicture(String cnPicture) {
		this.cnPicture = cnPicture;
	}
	public String getEnPicture() {
		return enPicture;
	}
	public void setEnPicture(String enPicture) {
		this.enPicture = enPicture;
	}
	public String getVideoPath() {
		return videoPath;
	}
	public void setVideoPath(String videoPath) {
		this.videoPath = videoPath;
	}
	public String getVideoExt() {
		return videoExt;
	}
	public void setVideoExt(String videoExt) {
		this.videoExt = videoExt;
	}
	
}
