package cn.bonoon.controllers;

import cn.bonoon.kernel.annotations.OptionArray;
import cn.bonoon.kernel.annotations.ResetProperties;
import cn.bonoon.kernel.annotations.ResetProperty;

@ResetProperties({
	@ResetProperty(value = "amount", name = "数量"),
	@ResetProperty(value = "levelPoints", name = "成长分"),
	@ResetProperty(value = "createAt", name = "交易时间"),
	@ResetProperty(value = "transactionType", name = "类型", 
			options = @OptionArray({"消费", "赚取", "购买", "调整", "赠送出去", "接收赠送", "奖励", "其他"})),
	@ResetProperty(value = "currencyType", name = "货币",  options = @OptionArray({"积分", "钻石", "现金"})),
	@ResetProperty(value = "deduct", name = "类别",  options = @OptionArray({"增加积分", "扣除积分"})),
	@ResetProperty(value = "remark", name = "备注")
})
public interface PointsDefine {

}
