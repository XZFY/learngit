package cn.bonoon.core.infos;

import java.util.ArrayList;
import java.util.List;

import cn.bonoon.Util;
import cn.bonoon.core.PracticeService;
import cn.bonoon.entities.AnswerEntity;

public class TopicCollection {
	private int startIndex;
	private boolean reset;
	private final Long id;
	private long spentTime;
	/**
	 * 累计已经使用的时间
	 */
	private String cumulativeTime;
	private final List<TopicItem> items;
	private final int size;
	private final String startDate;
	
	public TopicCollection(AnswerEntity entity){
		String content = entity.getContent();
		String[] cs = content.split(";");
		if(cs.length == 0){
			throw new RuntimeException("没有题目！");
		}
		items = new ArrayList<TopicItem>();
		int i = 1;
		for(String it : cs){
			TopicItem pi = new TopicItem(i++, it);
			items.add(pi);
		}
		size = items.size();
		id = entity.getId();
		reset = entity.getStatus() == PracticeService.ANSWER_STATUS_DOING;
		if(reset){
			spentTime = entity.getCurrentTimeSpent() + entity.getTimeSpent();
			if(spentTime > 0){
				cumulativeTime = Util.timeSpent(spentTime);
			}else{
				reset = false;
			}
		}
		startDate = Util.toString(entity.getCreateAt());
	}
	public int getStartIndex() {
		return startIndex;
	}
	public boolean isReset() {
		return reset;
	}
	public Long getId() {
		return id;
	}
	public long getSpentTime() {
		return spentTime;
	}
	public String getCumulativeTime() {
		return cumulativeTime;
	}
	public List<TopicItem> getItems() {
		return items;
	}
	public int getSize() {
		return size;
	}
	public String getStartDate() {
		return startDate;
	}
}
