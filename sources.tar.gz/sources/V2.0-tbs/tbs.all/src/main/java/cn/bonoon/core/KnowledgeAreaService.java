package cn.bonoon.core;

import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.kernel.support.services.GenericService;

public interface KnowledgeAreaService extends GenericService<KnowledgeAreaEntity>{

	String getName(Long id);

}
