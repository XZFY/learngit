package cn.bonoon.core.infos;

import cn.bonoon.Util;
import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.entities.AnswerType;

public class ProgressInfo {
	
	private final String start, spentTime, type;
	
	private final int rightCount;
	
	private final String continueUrl, giveupUrl;
	
	public ProgressInfo(AnswerEntity entity) {
		start = Util.toString(entity.getCreateAt()); 
		spentTime = Util.timeSpent(entity.getTimeSpent());
		rightCount = entity.getRightCount();
		AnswerType at = entity.getType();
		type = at.getDisplay();
		String url;
		switch (at) {
		case REAL:
			url = "/pmp/real/";
			break;
		case PAGER:
			url = "/pmp/pager/";
			break;
		case AREA:
			url = "/pmp/improve/area!";
			break;
		case GROUP:
			url = "/pmp/improve/group!";
			break;
		case PROCESS:
			url = "/pmp/improve/process!";
			break;
		default:
			url = "/pmp/praxis/";
			break;
		}
		continueUrl = url + entity.getFromId() + "/" + entity.getId() + "!start.do?in=p";
		
		giveupUrl = "/pmp/topic/giveup.do?id=" + entity.getId();
	}

	public String getStart() {
		return start;
	}

	public String getSpentTime() {
		return spentTime;
	}

	public String getType() {
		return type;
	}

	public int getRightCount() {
		return rightCount;
	}

	public String getContinueUrl() {
		return continueUrl;
	}

	public String getGiveupUrl() {
		return giveupUrl;
	}

}
