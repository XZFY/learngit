package cn.bonoon.entities;

public enum MediaContentType {
	/**
	 * 视频；在线视频播放
	 */
	VIDEO,
	/**
	 * 音频；在线音频播放
	 */
	AUDIO,
	/**
	 * 文字、文档之类的附件；在线文件打开或下载
	 */
	WORD,
	/**
	 * 图片类的附件；在线图片打开或下载
	 */
	PICTURE
}
