package cn.bonoon.services;

import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.ClassesService;
import cn.bonoon.core.infos.InstitutionClassesInfo;
import cn.bonoon.entities.ClassesEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.StudentEntity;
import cn.bonoon.entities.StudyingEntity;
import cn.bonoon.entities.TrainingInstitutionEntity;
import cn.bonoon.entities.plugins.PlaceEntity;
import cn.bonoon.kernel.events.OperateEvent;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.services.AbstractService;

@Service
@Transactional(readOnly = true)
public class ClassesServiceImpl extends AbstractService<ClassesEntity> implements ClassesService {

	@Override
	protected ClassesEntity __save(OperateEvent event, ClassesEntity entity) {
		ClassesEntity ce = super.__save(event, entity);
		StudentEntity mnt = ce.getMonitor();
		if(null != mnt){
			//自动添加个班级的同学
			StudyingEntity se = new StudyingEntity();
			se.setClasses(ce);
			se.setCreateAt(event.now());
			se.setStatus(1);
			se.setStudent(mnt);
			entityManager.persist(se);
		}
		return ce;
	}
	
	@Override
	public List<ClassesEntity> myClasses(MemberEntity member) {
		String ql = "select x.classes from StudyingEntity x where x.student.member.id=?";
		TypedQuery<ClassesEntity> qt = entityManager.createQuery(ql, ClassesEntity.class);
		qt.setParameter(1, member.getId());
		return qt.getResultList();
	}
	
	@Override
	public TrainingInstitutionEntity institution(ClassesEntity classes) {
		return entityManager.find(TrainingInstitutionEntity.class, classes.getOwnerId());
	}

	@Override
	public InstitutionClassesInfo institutionClasses(MemberEntity member) {
		String ql = "select x from StudentEntity x where x.member.id=?";
		TypedQuery<StudentEntity> qt = entityManager.createQuery(ql, StudentEntity.class);
		qt.setParameter(1, member.getId());
		List<StudentEntity> tis = qt.getResultList();
		StringBuilder ids = new StringBuilder();
		InstitutionClassesInfo ic = new InstitutionClassesInfo();
		for(StudentEntity ti : tis){
			int status = ti.getStatus();
			if(0 == status){
				ic.addApply(ti.getOwnerId());
			}else if(status > 0){
				Long iid = ti.getOwnerId();
				ic.addJoin(iid);
				ids.append(',').append(iid);
			}
		}
		//可以加入的班级
		if(ids.length() > 0){
			String cql = "select x from ClassesEntity x where x.ownerId in(" + ids.substring(1) + ") and x.status=1";
			ic.setClasses(entityManager.createQuery(cql, ClassesEntity.class).getResultList());
		}
		List<TrainingInstitutionEntity> institutions = null;
		PlaceEntity pe = member.getPlace();
		if(null != pe){
			//介绍这个地区下的所有机构
			String tql = "select x from TrainingInstitutionEntity x where x.place.id=? and x.level>0 and x.level<100 order by x.level asc";
			institutions = entityManager.createQuery(tql, TrainingInstitutionEntity.class).setParameter(1, pe.getId()).getResultList();
		}
		
		if(null == institutions || institutions.isEmpty()){
			String tql = "select x from TrainingInstitutionEntity x where x.level>0 and x.level<50 order by x.level asc";
			institutions = entityManager.createQuery(tql, TrainingInstitutionEntity.class).getResultList();
		}
		ic.setInstitutions(institutions);
		return ic;
	}

	@Override
	@Transactional
	public String applyInstitution(IOperator user, Long id) {
		MemberEntity member = entityManager.find(MemberEntity.class, user.getId());
		StudentEntity se = new StudentEntity();
		se.setCreateAt(new Date());
		se.setOwnerId(id);
		se.setMember(member);
		se.setSourceType("个人申请");
		entityManager.persist(se);
		return __first(String.class, "select x.name from TrainingInstitutionEntity x where x.id=?", id);
	}

	@Override
	@Transactional
	public String abandonInstitution(IOperator user, Long id) {
		StudentEntity se = __student(user.getId(), id);
		se.setStatus(-1);
		entityManager.merge(se);
		return __first(String.class, "select x.name from TrainingInstitutionEntity x where x.id=?", se.getOwnerId());
	}

	private StudentEntity __student(Long mid, Long id) {
		String ql = "select x from StudentEntity x where x.member.id=? and x.ownerId=? and x.status=1";
		StudentEntity se = __first(StudentEntity.class, ql, mid, id);
		if(null == se){
			throw new RuntimeException("没有对象，没有对象！");
		}
		return se;
	}

	@Override
	public void joinClasses(MemberEntity member, Long id) {
		ClassesEntity ce = entityManager.find(ClassesEntity.class, id);
		StudentEntity se = __student(member.getId(), ce.getOwnerId());
		StudyingEntity si = new StudyingEntity();
		si.setClasses(ce);
		si.setCreateAt(new Date());
		si.setStudent(se);
		entityManager.persist(si);
	}

	@Override
	public List<StudyingEntity> classmate(ClassesEntity classes) {
		String ql = "select x from StudyingEntity x where x.classes.id=? order by x.seatNumber asc";
		return entityManager.createQuery(ql, StudyingEntity.class).setParameter(1, classes.getId()).getResultList();
	}

}
