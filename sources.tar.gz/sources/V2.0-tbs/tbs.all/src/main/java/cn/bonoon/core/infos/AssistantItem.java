package cn.bonoon.core.infos;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.entities.AnswerStatisticsItem;
import cn.bonoon.entities.AnswerStatisticsType;

public class AssistantItem {

	private final Map<String, AssistantCell> cells;
	private final String name;
	private final String date;
	private final static SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
	private boolean canTpi;
	
	public AssistantItem(AnswerEntity ae, List<AnswerStatisticsItem> asis, boolean percent) {
		
		cells = new HashMap<>();
		name = ae.getName();
		date = sdf.format(ae.getFinishAt());
		
		for(AnswerStatisticsItem asi : asis){
			AssistantCell it = new AssistantCell(asi, percent);
			cells.put(it.getKey(), it);
			canTpi = canTpi || asi.getType() == AnswerStatisticsType.GROUP;
		}
	}
	
	public boolean isCanTpi() {
		return canTpi;
	}

	public void render(StringBuilder html, List<String> mapped){
		html.append("<td>").append(name).append("</td><td>").append(date).append("</td>");
		for(String key : mapped){
			AssistantCell cell = cells.get(key);
			html.append("<td>");
			if(null != cell){
				cell.render(html);
			}
			html.append("</td>");
		}
	}

}
