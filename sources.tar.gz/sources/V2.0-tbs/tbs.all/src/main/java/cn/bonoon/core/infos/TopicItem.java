package cn.bonoon.core.infos;

public class TopicItem {
	
	private final int index;
	private final String key;
	private char imptMark;
	private char answer;
	
	public TopicItem(int index, String item){
		this.index = index;
		this.answer = item.charAt(0);
		this.imptMark = item.charAt(1);
		this.key = item.substring(2);
	}
	
	public char getImptMark() {
		return imptMark;
	}
	
	public void setImptMark(char imptMark) {
		this.imptMark = imptMark;
	}
	
	public char getAnswer() {
		return answer;
	}
	
	public void setAnswer(char answer) {
		this.answer = answer;
	}
	
	public int getIndex() {
		return index;
	}
	
	public String getKey() {
		return key;
	}
}
