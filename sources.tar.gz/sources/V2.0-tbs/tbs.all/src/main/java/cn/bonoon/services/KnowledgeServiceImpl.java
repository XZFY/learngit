package cn.bonoon.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.KnowledgeService;
import cn.bonoon.entities.KnowledgePointEntity;
import cn.bonoon.kernel.support.services.AbstractService;

@Service
@Transactional(readOnly = true)
public class KnowledgeServiceImpl extends AbstractService<KnowledgePointEntity> implements KnowledgeService{

}
