package cn.bonoon.controllers.topic;

import cn.bonoon.kernel.annotations.Transform;
import cn.bonoon.kernel.annotations.WriteModel;
import cn.bonoon.kernel.web.annotations.WithDialog;
import cn.bonoon.kernel.web.annotations.form.FormDetail;
import cn.bonoon.kernel.web.annotations.form.PropertyDetail;

@WithDialog(height = 480)
@FormDetail(2)
@Transform(write = WriteModel.NONE)
public class TopicDetail implements TopicDefine{
	
	@PropertyDetail(colspan = 1, value = 10)
	private String enContent;
	@PropertyDetail(colspan = 1, value = 11)
	private String cnContent;
	@PropertyDetail(0)
	private String name;
	@PropertyDetail(1)
	private String code;
	@PropertyDetail(20)
	private String process;
	@PropertyDetail(21)
	private String group;
	@PropertyDetail(22)
	private String area;
	@PropertyDetail(23)
	private String knowledge;
	@PropertyDetail(30)
	private String freeFast;
	@PropertyDetail(31)
	private String freeCombat;
	@PropertyDetail(32)
	private String praxis;
	@PropertyDetail(33)
	private String improve;
	@PropertyDetail(34)
	private String exam;
	@PropertyDetail(35)
	private String real;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getKnowledge() {
		return knowledge;
	}
	public void setKnowledge(String knowledge) {
		this.knowledge = knowledge;
	}
	
	public String getPraxis() {
		return praxis;
	}
	public void setPraxis(String praxis) {
		this.praxis = praxis;
	}
	public String getExam() {
		return exam;
	}
	public void setExam(String exam) {
		this.exam = exam;
	}
	public String getReal() {
		return real;
	}
	public void setReal(String real) {
		this.real = real;
	}
	public String getEnContent() {
		return enContent;
	}
	public void setEnContent(String enContent) {
		this.enContent = enContent;
	}
	public String getCnContent() {
		return cnContent;
	}
	public void setCnContent(String cnContent) {
		this.cnContent = cnContent;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getFreeFast() {
		return freeFast;
	}
	public void setFreeFast(String freeFast) {
		this.freeFast = freeFast;
	}
	public String getFreeCombat() {
		return freeCombat;
	}
	public void setFreeCombat(String freeCombat) {
		this.freeCombat = freeCombat;
	}
	public String getImprove() {
		return improve;
	}
	public void setImprove(String improve) {
		this.improve = improve;
	}

}
