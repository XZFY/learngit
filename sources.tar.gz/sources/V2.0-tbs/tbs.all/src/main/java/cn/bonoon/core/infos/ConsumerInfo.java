package cn.bonoon.core.infos;

import cn.bonoon.entities.TransactionEntity;
import cn.bonoon.kernel.util.StringHelper;

public class ConsumerInfo {
	
	private final int amount; 
	private final String transactionAt;
	private final String deduct;
	private final String transactionType;
	private final String currencyType;
	private final String remark;
	
	public ConsumerInfo(TransactionEntity te) {
		this.amount = te.getAmount();
		this.transactionAt = StringHelper.datetime2String(te.getTransactionAt());
		this.deduct = te.isDeduct() ? "<font color='red'>扣除</font>" : "<font color='blue'>收入</font>";
		this.transactionType = te.getTransactionType().getTitle();
		this.currencyType = te.getCurrencyType().getTitle();
		this.remark = te.getRemark();
	}

	public int getAmount() {
		return amount;
	}

	public String getTransactionAt() {
		return transactionAt;
	}

	public String getDeduct() {
		return deduct;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public String getRemark() {
		return remark;
	}

}
