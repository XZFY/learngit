package cn.bonoon.core;

import cn.bonoon.entities.StudentEntity;
import cn.bonoon.kernel.support.services.GenericService;

public interface StudentService extends GenericService<StudentEntity>{
	//报名
	int STATUS_ENROLL = 0;
	
	//正在学习
	int STATUS_NORMAL = 1;
	
	//毕业
	int STATUS_GRADUATED = 2;
	
	//肄业
	int STATUS_DROPOUT = 3;
}
