package cn.bonoon.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.AnswerStatus;
import cn.bonoon.core.AssistantService;
import cn.bonoon.core.configs.TpiConfig;
import cn.bonoon.core.infos.ForcetorInfo;
import cn.bonoon.core.infos.KnowledgeInfo;
import cn.bonoon.core.infos.SisterInfo;
import cn.bonoon.core.infos.TpiInfo;
import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.entities.AnswerStatisticsItem;
import cn.bonoon.entities.AnswerStatisticsType;
import cn.bonoon.entities.AnswerType;
import cn.bonoon.entities.ImprovePracticeEntity;
import cn.bonoon.entities.ImprovePracticeItem;
import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.entities.KnowledgePointEntity;
import cn.bonoon.entities.ProcessGroupEntity;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.services.ServiceSupport;

@Service
@Transactional(readOnly = true)
public class AssistantServiceImpl extends ServiceSupport implements AssistantService {

	private final String hql_0 = "select x from AnswerEntity x where x.status=? and x.creatorId=? order by x.finishAt desc";
	private final String hql_2 = "select x from AnswerEntity x where (x.status=? and x.creatorId=?) and (x.type=? or x.type=?) order by x.finishAt desc";

//	private final String hql_1 = "select x from AnswerStatisticsItem x where x.answer.id=? and x.type<>?";
//	private final String hql_3 = "select x from AnswerStatisticsItem x where x.answer.id=?";
	private final String hql_4 = "select x from AnswerStatisticsItem x where x.answer.id=? and x.type=?";
//	private final String hql_10 = "select x from AnswerStatisticsItem x where x.answer.id=? and x.type=? or x.type=?";
	
	private final String hql_5 = "select x from ImprovePracticeEntity x where x.answer.id=?";
	private final String hql_6 = "select x from ImprovePracticeItem x where x.improve.id=? and x.finish=false order by x.priority asc";
	
//		List<AnswerEntity> as = __top(10, AnswerEntity.class, hql_0, AnswerStatus.ANSWER_STATUS_FINISH, user.getId());
//		
//		AssistantInfo ai = __assistant(as, false);
//	
//		for(AnswerEntity ae : as){
//			ai.add(ae, __list(AnswerStatisticsItem.class, hql_1, ae.getId(), AnswerStatisticsType.KNOWLEDGE));
//		}
//		return ai;
	@Override
	public ForcetorInfo forcetor(IOperator user, String[] paths) {
		//只取出最近一次完成的练习，包括：课后练习、提高、考试、真题
		AnswerEntity anr = __first(AnswerEntity.class, hql_0, AnswerStatus.ANSWER_STATUS_FINISH, user.getId());
		//只取出两种：过程、过程组
		List<AnswerStatisticsItem> pas = __list(AnswerStatisticsItem.class, hql_4, anr.getId(), AnswerStatisticsType.AREA);
		List<AnswerStatisticsItem> gas = __list(AnswerStatisticsItem.class, hql_4, anr.getId(), AnswerStatisticsType.GROUP);
		List<KnowledgeAreaEntity> pes = __list(KnowledgeAreaEntity.class, "select x from KnowledgeAreaEntity x where x.deleted=false order by x.ordinal asc");
		List<ProcessGroupEntity> ges = __list(ProcessGroupEntity.class, "select x from ProcessGroupEntity x where x.deleted=false order by x.ordinal asc");
		
		return new ForcetorInfo(pas, pes, gas, ges, paths);
	}
	
	@Override
	public TpiInfo tpi(IOperator user, TpiConfig config) {
		String ql = "select x from AnswerEntity x where x.status=? and x.creatorId=? and x.type<>? and x.type<>? order by x.finishAt desc";
		AnswerEntity anr = __first(AnswerEntity.class, ql, AnswerStatus.ANSWER_STATUS_FINISH, user.getId(), AnswerType.OTHER, AnswerType.PRAXIS);
		//取出最近一次的练习
		List<AnswerStatisticsItem> aas = __list(AnswerStatisticsItem.class, hql_4, anr.getId(), AnswerStatisticsType.AREA);
		List<AnswerStatisticsItem> gas = __list(AnswerStatisticsItem.class, hql_4, anr.getId(), AnswerStatisticsType.GROUP);
		List<KnowledgeAreaEntity> aes = __list(KnowledgeAreaEntity.class, "select x from KnowledgeAreaEntity x where x.deleted=false order by x.ordinal asc");
		List<ProcessGroupEntity> ges = __list(ProcessGroupEntity.class, "select x from ProcessGroupEntity x where x.deleted=false order by x.ordinal asc");

		String sql = "select x.C_TID,sum(x.C_RIGHT),sum(x.C_TOTAL) from T_ANSWERITEM x where x.C_CREATORID=? and x.R_ANSWER_ID<>? and x.C_TYPE=? group by x.C_TID";
		List<?> saa = entityManager.createNativeQuery(sql).setParameter(1, user.getId()).setParameter(2, anr.getId()).setParameter(3, AnswerStatisticsType.AREA.ordinal()).getResultList();
		List<?> sga = entityManager.createNativeQuery(sql).setParameter(1, user.getId()).setParameter(2, anr.getId()).setParameter(3, AnswerStatisticsType.GROUP.ordinal()).getResultList();
		
		return new TpiInfo(config, aas, aes, gas, ges, saa, sga);
	}

	private final String 
					situation_1 = "您没有进行过一次试卷或真题的练习，无法针对您的薄弱环节进行提高练习！",
					situation_2 = "您于%s最后一次完成的试卷或真题的练习，超过了有效的分析时间的范围，请重新完成试卷或真题的练习！",
					situation_3 = "出现未知的状况，请先重新完成一次试卷或真题的练习再来试一下吧！",
					situation_4 = "恭喜您！根据%s试卷或真题的练习结果来看，您暂时不需要进行提高练习！<p>注意：本次提高练习只针对您最后一次试卷或真题的做题情况给出的练习建议；多做试卷或真题的练习可以查找出更多的薄弱环节！</p>",
					situation_5 = "您已经完成了最近一次的试卷或真题考试的提高练习，请重新做试卷或真题！";
	
	private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
	private final static int IMPROVE_FINISH = 1;//通过提高练习达到了对知识点的掌握
	private final static int IMPROVE_PASSED = 2;//该考试练习各知识点都掌握
	private final String hql_8 = "select x from ImprovePracticeItem x where x.improve.id=? and x.knowledge.id=?";
	private final String hql_9 = "select count(x) from ImprovePracticeItem x where x.improve.id=? and x.finish=false";
	
	@Override
	@Transactional
	public boolean sister(IOperator user, Long id, Collection<KnowledgeInfo> values) {
		ImprovePracticeEntity ipe = entityManager.find(ImprovePracticeEntity.class, id);
		if(null != ipe){
			Date now = new Date();
			for(KnowledgeInfo ki : values){
				ImprovePracticeItem ip = __first(ImprovePracticeItem.class, hql_8, id, ki.getId());
				if(null != ip){
					ip.setPracticeAt(now);
					ip.setTimes(ip.getTimes() + 1);
					ki.set(ip);
					entityManager.merge(ip);
				}
			}
			if(__exsit(hql_9, id)){
				ipe.setStatus(IMPROVE_FINISH);
				entityManager.merge(ipe);
				return true;
			}
		}
		return false;
	}
	
	@Override
	@Transactional
	public SisterInfo sister(IOperator user, Long id) {
		ImprovePracticeEntity ipe = entityManager.find(ImprovePracticeEntity.class, id);
		if(null != ipe){
			return __sister(ipe.getAnswer(), ipe);
		}
		return __sister(user);
	}
	
	@Override
	@Transactional
	public SisterInfo sister(IOperator user) {
		return __sister(user);
	}
	
	private SisterInfo __sister(IOperator user) {
		/*
		 * 1.没有完成过一次试卷的练习
		 * 2.完成过试卷，但后一次完成的试卷距离现在的时间太长的情况，无法及时分析(如：3个月以上)
		 * 3.完成过试卷，但没有任何可以分析的知识点的情况
		 * 4.已经进行过提高练习，这里将继续完成提高练习
		 * 5.已经完成试卷练习，但最后一次试卷练习所有知识点都达标，所以暂时不需要进行提高练习
		 * 6.完成过试卷练习，最后一次席卷练习有知识点不达标的，需要进行提示练习
		 * 7.已经进行过提高练习，并且本次提高练习所有的知识点都已经达标
		 */
		AnswerEntity answer = __first(AnswerEntity.class, hql_2, AnswerStatus.ANSWER_STATUS_FINISH, user.getId(), AnswerType.PAGER, AnswerType.REAL);
		if(null == answer){
			//第1点
			return new SisterInfo(situation_1);
		}
		
		//需要设置的参数
		//即只分析多长时间内做过的练习
		int month = 3;
		
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -month);//N个月前
		Date fat = answer.getFinishAt();
		if(cal.after(fat)){
			//第2点
			return new SisterInfo(String.format(situation_2, sdf.format(fat)));
		}
		
		//是否已经进行过提高练习
		ImprovePracticeEntity ipe = __first(ImprovePracticeEntity.class, hql_5, answer.getId());
		if(null != ipe){
			return __sister(answer, ipe);
		}
		List<AnswerStatisticsItem> items = __list(AnswerStatisticsItem.class, hql_4, answer.getId(), AnswerStatisticsType.KNOWLEDGE);
		if(items.isEmpty()){
			//第3点
			return new SisterInfo(situation_3);
		}
		
		ipe = new ImprovePracticeEntity();
		ipe.setAnswer(answer);
		ipe.setCreateAt(new Date());
		List<ImprovePracticeItem> ipItems = new ArrayList<>();
		for(AnswerStatisticsItem asi : items){
			KnowledgePointEntity kp = entityManager.find(KnowledgePointEntity.class, asi.getTid());
			if(kp == null){
				continue;
			}
			//需要进行提高练习的上限和下限
			//如：某个知识点低于下限，即<lowerLimit，则需要对该知识点进行提高练习，
			//当该知识点练习的结果>upperLimit时，表示该知识点掌握已经过关
			int lowerLimit = kp.getLowerLimit();
			lowerLimit = Math.max(0, lowerLimit);
			lowerLimit = Math.min(100, lowerLimit);
			int s = asi.getRight() * 100 / asi.getTotal();
			if(s < lowerLimit){
				//需要进行提高练习
				ImprovePracticeItem ipi = new ImprovePracticeItem();
				ipi.setKnowledge(kp);
				ipi.setImprove(ipe);
				ipi.setOriginalScore(s);
				ipi.setPriority(s);
				ipi.setUpperLimit(kp.getUpperLimit());
				ipItems.add(ipi);
			}
		}//8986 0110 8510 0829 778G
		
		if(ipItems.isEmpty()){
			//该试卷的各个知识点都已经掌握
			ipe.setStatus(IMPROVE_PASSED);
			entityManager.persist(ipe);
			return new SisterInfo(String.format(situation_4, sdf.format(fat)));
		}
		
		entityManager.persist(ipe);
		for(ImprovePracticeItem ipi : ipItems){
			entityManager.persist(ipi);
		}
		
		//重新排序，拿出两个需要提高的知识点出来
		Collections.sort(ipItems, new Comparator<ImprovePracticeItem>(){

			@Override
			public int compare(ImprovePracticeItem o1, ImprovePracticeItem o2) {
				return o1.getPriority() - o2.getPriority();
			}
			
		});
		
		return __sister(answer, ipe, ipItems);
	}

	private SisterInfo __sister(AnswerEntity answer, ImprovePracticeEntity ipe) {
		if(ipe.getStatus() == IMPROVE_FINISH){
			//已完成，不需要进行提高练习
			return new SisterInfo(situation_5);
		}else if(ipe.getStatus() == IMPROVE_PASSED){
			return new SisterInfo(String.format(situation_4, sdf.format(answer.getFinishAt())));
		}
		//继续之前的提高练习
		List<ImprovePracticeItem> ipItems = __top(2, ImprovePracticeItem.class, hql_6, ipe.getId());
		if(ipItems.isEmpty()){
			//已经完成了，没有知识点需要进行提高练习的了
			ipe.setStatus(IMPROVE_FINISH);
			entityManager.merge(ipe);
			return new SisterInfo(situation_5);
		}
		return __sister(answer, ipe, ipItems);
	}
	
	//TODO 这里的条件需要调整
	private final String hql_7 = "select x.key from TopicEntity x where x.improve=true and x.deleted=false and x.key is not null and x.knowledge.id=?";
	
	private SisterInfo __sister(AnswerEntity answer, ImprovePracticeEntity ipe, List<ImprovePracticeItem> ipItems){
		//还要根据知识点来随机抽取题目
		List<String> keys = new ArrayList<>();
		if(ipItems.size() > 1){
			//各自抽取5道题目
			ImprovePracticeItem ip_0 = ipItems.get(0), ip_1 = ipItems.get(1);
			keys.addAll(RandomHelper.random(__list(String.class, hql_7, ip_0.getId()), 5));
			keys.addAll(RandomHelper.random(__list(String.class, hql_7, ip_1.getId()), 5));
		}else{
			//只有一个知识点需要提高的情况，该知识点抽取10道题目
			ImprovePracticeItem ip = ipItems.get(0);
			keys.addAll(RandomHelper.random(__list(String.class, hql_7, ip.getId()), 10));
		}
		return new SisterInfo(answer, ipe, keys);
	}
	
//	private final String hql_8 = "select x from TopicEntity x where x.key=?";
//	@Override
//	public TopicInfo topic(String key, Boolean isen) {
//		return new TopicInfo(__first(TopicEntity.class, hql_8, key), isen);
//	}
}
