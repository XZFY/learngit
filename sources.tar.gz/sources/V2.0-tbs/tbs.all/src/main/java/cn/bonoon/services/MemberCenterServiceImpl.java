package cn.bonoon.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.AnswerStatus;
import cn.bonoon.core.MemberCenterService;
import cn.bonoon.core.configs.AccountSettingConfig;
import cn.bonoon.core.infos.ConsumerInfo;
import cn.bonoon.core.infos.DocumentInfo;
import cn.bonoon.core.infos.ProgressInfo;
import cn.bonoon.core.infos.VideoInfo;
import cn.bonoon.core.infos.WrongInfo;
import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.entities.CurrencyType;
import cn.bonoon.entities.DocContentEntity;
import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.entities.MediaContentEntity;
import cn.bonoon.entities.MediaContentType;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.ProcessEntity;
import cn.bonoon.entities.ProcessGroupEntity;
import cn.bonoon.entities.TransactionEntity;
import cn.bonoon.entities.TransactionType;
import cn.bonoon.entities.WrongAnswerEntity;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.models.Page;
import cn.bonoon.kernel.support.services.ServiceSupport;
import cn.bonoon.kernel.util.StringHelper;
import cn.bonoon.kernel.web.ConfigManager;

@Service
@Transactional(readOnly = true)
public class MemberCenterServiceImpl extends ServiceSupport implements MemberCenterService, AnswerStatus{

	private ConfigManager configManager;
	@Override
	public void afterPropertiesSet() throws Exception {
		super.afterPropertiesSet();
		configManager = ConfigManager.getManager();
	}
	
	private AccountSettingConfig __setting(){
		AccountSettingConfig asc = new AccountSettingConfig();
		try{
			configManager.read(applicationContext, entityManager, asc);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return asc;
	}
	
	private final String w_0 = "select x from WrongAnswerEntity x where x.key=? order by x.id desc";
	private final String w_1 = "select count(x) from WrongAnswerEntity x where x.key=?";
	@Override
	public Page wrongs(IOperator user, int page, int size, Boolean en) {
		MemberEntity member = entityManager.find(MemberEntity.class, user.getId());
		if(null == member){
			return null;
		}
		TypedQuery<WrongAnswerEntity> query = entityManager.createQuery(w_0, WrongAnswerEntity.class);
		query.setParameter(1, member.getKey());
		if(size > 0){
			__page(query, page, size);
			
			//分页
			TypedQuery<Long> tqco = entityManager.createQuery(w_1, Long.class);
			tqco.setParameter(1, member.getKey());
			return new Page(tqco.getSingleResult().longValue(), __wrongs(query, en));
		}
		//不分页
		return new Page(__wrongs(query, en));
	}
	
	private final String p_0 = "select x from AnswerEntity x where x.creatorId=? and x.status=? order by x.id desc";
	private final String p_1 = "select count(x) from AnswerEntity x where x.creatorId=? and x.status=?";
	@Override
	public Page progresses(IOperator user, int page, int size) {
		TypedQuery<AnswerEntity> query = entityManager.createQuery(p_0, AnswerEntity.class);
		query.setParameter(1, user.getId()).setParameter(2, ANSWER_STATUS_DOING);
		if(size > 0){
			__page(query, page, size);
			
			TypedQuery<Long> tqco = entityManager.createQuery(p_1, Long.class);
			tqco.setParameter(1, user.getId()).setParameter(2, ANSWER_STATUS_DOING);

			return new Page(tqco.getSingleResult().longValue(), __progresses(query));
		}
		return new Page(__progresses(query));
	}

	private final String v_0 = "select x from MediaContentEntity x where x.creatorId=? and x.deleted=false order by x.id desc";
	private final String v_1 = "select count(x) from MediaContentEntity x where x.creatorId=? and x.deleted=false";
	@Override
	public Page videos(IOperator user, int page, int size, String name) {
		if(StringHelper.isNotEmpty(name)){
			name = "%" + name + "%";
			String qls = v_0 + " and x.name like ? order by x.id desc";
			TypedQuery<MediaContentEntity> query = entityManager.createQuery(qls, MediaContentEntity.class);
			query.setParameter(1, user.getId()).setParameter(2, name);
			if(size > 0){
				String qlc = v_1 + " and x.name like ?";
				__page(query, page, size);
				
				TypedQuery<Long> tqco = entityManager.createQuery(qlc, Long.class);
				tqco.setParameter(1, user.getId()).setParameter(2, name);
	
				return new Page(tqco.getSingleResult().longValue(), __videos(query));
			}
			return new Page(__videos(query));
		}else{
			TypedQuery<MediaContentEntity> query = entityManager.createQuery(v_0 + " order by x.id desc", MediaContentEntity.class);
			query.setParameter(1, user.getId());
			if(size > 0){
				__page(query, page, size);
				
				TypedQuery<Long> tqco = entityManager.createQuery(v_1, Long.class);
				tqco.setParameter(1, user.getId());
	
				return new Page(tqco.getSingleResult().longValue(), __videos(query));
			}
			return new Page(__videos(query));
		}
	}

	private final String d_0 = "select x from DocContentEntity x where x.creatorId=? and x.deleted=false";
	private final String d_1 = "select count(x) from DocContentEntity x where x.creatorId=? and x.deleted=false";
	@Override
	public Page documents(IOperator user, int page, int size, String name) {
		if(StringHelper.isNotEmpty(name)){
			name = "%" + name + "%";
			String qls = d_0 + " and x.name like ? order by x.id desc";
			
			TypedQuery<DocContentEntity> query = entityManager.createQuery(qls, DocContentEntity.class);
			query.setParameter(1, user.getId()).setParameter(2, name);
			if(size > 0){
				String qlc = d_1 + " and x.name like ?";
				__page(query, page, size);
				
				TypedQuery<Long> tqco = entityManager.createQuery(qlc, Long.class);
				tqco.setParameter(1, user.getId()).setParameter(2, name);
	
				return new Page(tqco.getSingleResult().longValue(), __documents(query));
			}
			return new Page(__documents(query));
		}else{
			TypedQuery<DocContentEntity> query = entityManager.createQuery(d_0 + " order by x.id desc", DocContentEntity.class);
			query.setParameter(1, user.getId());
			if(size > 0){
				__page(query, page, size);
				
				TypedQuery<Long> tqco = entityManager.createQuery(d_1, Long.class);
				tqco.setParameter(1, user.getId());
	
				return new Page(tqco.getSingleResult().longValue(), __documents(query));
			}
			return new Page(__documents(query));
		}
	}
	
	@Override
	public DocContentEntity document(IOperator user, Long id) {
		DocContentEntity doc = entityManager.find(DocContentEntity.class, id);
		if(null == doc){
			throw new RuntimeException("找不到对象！");
		}
		if(doc.isDeleted()){
			throw new RuntimeException("该文档已经被删除，无法加载！");
		}
		if(!user.getId().equals(doc.getCreatorId())){
			throw new RuntimeException("无法加载您的文档！");
		}
		return doc;
	}
	
	@Override
	public MediaContentEntity video(IOperator user, Long id) {
		MediaContentEntity vdo = entityManager.find(MediaContentEntity.class, id);
		if(null == vdo){
			throw new RuntimeException("找不到对象！");
		}
		if(vdo.isDeleted()){
			throw new RuntimeException("该视频已经被删除，无法加载！");
		}
		if(!user.getId().equals(vdo.getCreatorId())){
			throw new RuntimeException("无法加载您的视频！");
		}
		return vdo;
	}
	
	private final String c_0 = "select x from TransactionEntity x where x.userId=? order by x.id desc";
	private final String c_1 = "select count(x) from TransactionEntity x where x.userId=?";
	@Override
	public Page consumers(IOperator user, int page, int size) {
		TypedQuery<TransactionEntity> query = entityManager.createQuery(c_0, TransactionEntity.class);
		query.setParameter(1, user.getId());
		if(size > 0){
			__page(query, page, size);
			
			TypedQuery<Long> tqco = entityManager.createQuery(c_1, Long.class);
			tqco.setParameter(1, user.getId());

			return new Page(tqco.getSingleResult().longValue(), __consumers(query));
		}
		return new Page(__consumers(query));
	}
	
	private void __page(Query query, int page, int size){
		query.setFirstResult(page * size).setMaxResults(size);
	}
	
	private List<Object> __consumers(TypedQuery<TransactionEntity> query){
		List<Object> rows = new ArrayList<Object>();
		for(TransactionEntity te : query.getResultList()){
			rows.add(new ConsumerInfo(te));
		}
		return rows;
	}
	
	private List<Object> __progresses(TypedQuery<AnswerEntity> query){
		List<Object> rows = new ArrayList<Object>();
		for(AnswerEntity ae : query.getResultList()){
			rows.add(new ProgressInfo(ae));
		}
		return rows;
	}

	private List<Object> __videos(TypedQuery<MediaContentEntity> query) {
		List<Object> rows = new ArrayList<Object>();
		for(MediaContentEntity wae : query.getResultList()){
			rows.add(new VideoInfo(wae));
		}
		return rows;
	}

	private List<Object> __documents(TypedQuery<DocContentEntity> query) {
		List<Object> rows = new ArrayList<Object>();
		for(DocContentEntity wae : query.getResultList()){
			rows.add(new DocumentInfo(wae));
		}
		return rows;
	}

	private List<Object> __wrongs(TypedQuery<WrongAnswerEntity> query, Boolean en){
		List<Object> rows = new ArrayList<Object>();
		for(WrongAnswerEntity wae : query.getResultList()){
			rows.add(new WrongInfo(wae, en));
		}
		return rows;
	}

	@Override
	public List<KnowledgeAreaEntity> areas() {
		String ql = "select x from KnowledgeAreaEntity x where x.deleted=false";
		return __list(KnowledgeAreaEntity.class, ql);
	}

	@Override
	public List<ProcessEntity> processes() {
		String ql = "select x from ProcessEntity x where x.deleted=false";
		return __list(ProcessEntity.class, ql);
	}

	@Override
	public List<ProcessGroupEntity> groups() {
		String ql = "select x from ProcessGroupEntity x where x.deleted=false";
		return __list(ProcessGroupEntity.class, ql);
	}

	@Override
	@Transactional
	public void deleteDocument(IOperator user, Long id) {
		DocContentEntity doc = entityManager.find(DocContentEntity.class, id);
		if(null == doc){
			throw new RuntimeException("找不到对象！");
		}
		if(!user.getId().equals(doc.getCreatorId())){
			throw new RuntimeException("无法删除文档！");
		}
		entityManager.remove(doc);
	}
	
	@Override
	@Transactional
	public void deleteVideo(IOperator user, Long id) {
		MediaContentEntity vdo = entityManager.find(MediaContentEntity.class, id);
		if(null == vdo){
			throw new RuntimeException("找不到对象！");
		}
		if(!user.getId().equals(vdo.getCreatorId())){
			throw new RuntimeException("无法删除视频！");
		}
		entityManager.remove(vdo);
	}
	
	@Override
	@Transactional
	public void saveDocument(IOperator user, Long id, String title, String content, String path, Long area, Long group, Long process, boolean share) {
		DocContentEntity doc = null;
		Date now = new Date();
		if(null != id){
			doc = entityManager.find(DocContentEntity.class, id);
			if(null != doc){
				//修改
				__document(title, content, path, area, group, process, share, doc);
				doc.setUpdateAt(now);
				doc.setUpdaterId(user.getId());
				doc.setUpdaterName(user.getUsername());
				entityManager.merge(doc);
				return;
			}
		}
		//添加的情况
		doc = new DocContentEntity();
		__document(title, content, path, area, group, process, share, doc);
		doc.setCreateAt(now);
		doc.setEmployAt(now);
		doc.setCreatorId(user.getId());
		doc.setCreatorName(user.getUsername());
		entityManager.persist(doc);
		
		//计算积分
		AccountSettingConfig asc = __setting();
		int points = asc.getDocumentPoints();
		bonusPoints(points, now, user, "分享文档奖励积分");
	}
	
	@Override
	@Transactional
	public void saveVideo(IOperator user, Long id, String title,
			String content, String path, Long area, Long group, Long process,
			boolean share, String ext) {
		MediaContentEntity vdo = null;
		Date now = new Date();
		if(null != id){
			vdo = entityManager.find(MediaContentEntity.class, id);
			if(null != vdo){
				//修改
				__video(title, content, path, ext, area, group, process, share, vdo);
				vdo.setUpdateAt(now);
				vdo.setUpdaterId(user.getId());
				vdo.setUpdaterName(user.getUsername());
				entityManager.merge(vdo);
				return;
			}
		}
		//添加的情况
		vdo = new MediaContentEntity();
		__video(title, content, path, ext, area, group, process, share, vdo);
		vdo.setType(MediaContentType.AUDIO);
		vdo.setCreateAt(now);
		vdo.setEmployAt(now);
		vdo.setCreatorId(user.getId());
		vdo.setCreatorName(user.getUsername());
		entityManager.persist(vdo);
		
		//计算积分
		AccountSettingConfig asc = __setting();
		int points = asc.getVideoPoints();
		bonusPoints(points, now, user, "分享视频奖励积分");
	}
	
	private void bonusPoints(int points, Date now, IOperator user, String msg){
		if(points > 0){
			MemberEntity member = entityManager.find(MemberEntity.class, user.getId());
			if(null != member){
				TransactionEntity tpe = new TransactionEntity();
				tpe.setCreateAt(now);
				tpe.setDeduct(false);
				tpe.setCurrencyType(CurrencyType.POINTS);
				tpe.setTransactionType(TransactionType.INCREASE);
				tpe.setRemark(msg);
				tpe.setUserId(member.getId());
				
				tpe.setAmount(points);
				member.setAvailablePoints(member.getAvailablePoints() + points);
				member.setTotalPoints(member.getTotalPoints() + points);
				member.setLevelPoints(member.getLevelPoints() + points);
				tpe.setAvailable(member.getAvailablePoints());
				tpe.setTotal(member.getTotalPoints());
				tpe.setLevelPoints(points);
				
				entityManager.persist(tpe);
				entityManager.merge(member);
			}
		}
	}

	private void __document(String title, String content, String path,
			Long area, Long group, Long process, boolean share, DocContentEntity doc) {
		if(null != area){
			doc.setArea(entityManager.find(KnowledgeAreaEntity.class, area));
		}
		if(null != group){
			doc.setGroup(entityManager.find(ProcessGroupEntity.class, group));
		}
		if(null != process){
			doc.setProcess(entityManager.find(ProcessEntity.class, process));
		}
		if(StringHelper.isNotEmpty(path)){
			doc.setPath(path);
		}
		doc.setName(title);
		doc.setContent(content);
		doc.setShare(share);
	}

	private void __video(String title, String content, String path, String ext,
			Long area, Long group, Long process, boolean share, MediaContentEntity vdo) {
		if(null != area){
			vdo.setArea(entityManager.find(KnowledgeAreaEntity.class, area));
		}
		if(null != group){
			vdo.setGroup(entityManager.find(ProcessGroupEntity.class, group));
		}
		if(null != process){
			vdo.setProcess(entityManager.find(ProcessEntity.class, process));
		}
		if(StringHelper.isNotEmpty(path)){
			vdo.setPath(path);
			vdo.setFilesuffix(ext);
		}
		vdo.setName(title);
		//doc.setContent(content);
		vdo.setSubject(content);
		vdo.setShare(share);
	}
}
