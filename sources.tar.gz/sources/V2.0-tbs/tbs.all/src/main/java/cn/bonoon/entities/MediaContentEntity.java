package cn.bonoon.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.Table;

@Entity
@Table(name = "T_MEDIACONTENT")
public class MediaContentEntity extends BaseContentEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4887170450120517828L;


	@Enumerated
	@Column(name = "C_TYPE")
	private MediaContentType type;

	@Column(name = "C_FILESUFFIX")
	private String filesuffix;
	
	//外部连接
	@Column(name = "C_OUTTERLINK")
	private boolean outterLink;

	public MediaContentType getType() {
		return type;
	}

	public void setType(MediaContentType type) {
		this.type = type;
	}

	public String getFilesuffix() {
		return filesuffix;
	}

	public void setFilesuffix(String filesuffix) {
		this.filesuffix = filesuffix;
	}

	public boolean isOutterLink() {
		return outterLink;
	}

	public void setOutterLink(boolean outterLink) {
		this.outterLink = outterLink;
	}
	
}
