package cn.bonoon.core;

import java.util.Map;

import cn.bonoon.entities.PagerEntity;
import cn.bonoon.entities.PagerTopicEntity;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.support.services.GenericService;

public interface PagerService extends GenericService<PagerEntity>{
	
	int NORMAL = 1;

	PagerTopicEntity save(/*OperateEvent event, */Long id, TopicEntity topic);

	void save(Long id, Long[] ids);

	void ordinal(Long[] ids, Map<?, ?> parameterMap);

	void optimize(Long id);
}
