package cn.bonoon.core.configs;

import cn.bonoon.kernel.web.annotations.components.AsCheckbox;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

//练习相关的一些配置
@FormEditor(value = 3, headWidth = 90, width = 200)
public class PracticeConfig {

	@AsCheckbox("是")
	@PropertyEditor(name = "练习题评论", value = 20)
	@PropertyHelper(value = "做题时是否允许对本题进行评论", type = HelperType.WRAP)
	private boolean praxisComment;

	@AsCheckbox("是")
	@PropertyEditor(name = "练习题学习", value = 10)
	@PropertyHelper(value = "做题时是否允许查看本题相关知识", type = HelperType.WRAP)
	private boolean praxisStudy;

	@AsCheckbox("是")
	@PropertyEditor(name = "练习题答案", value = 0)
	@PropertyHelper(value = "做题时是否允许查看本题的答案", type = HelperType.WRAP)
	private boolean praxisAnswer;


	@AsCheckbox("是")
	@PropertyEditor(name = "试卷题评论", value = 21)
	@PropertyHelper(value = "做题时是否允许对本题进行评论", type = HelperType.WRAP)
	private boolean examComment;

	@AsCheckbox("是")
	@PropertyEditor(name = "试卷题学习", value = 11)
	@PropertyHelper(value = "做题时是否允许查看本题相关知识", type = HelperType.WRAP)
	private boolean examStudy;

	@AsCheckbox("是")
	@PropertyEditor(name = "试卷题答案", value = 1)
	@PropertyHelper(value = "做题时是否允许查看本题的答案", type = HelperType.WRAP)
	private boolean examAnswer;

	@AsCheckbox("是")
	@PropertyEditor(name = "真题评论", value = 22)
	@PropertyHelper(value = "做题时是否允许对本题进行评论", type = HelperType.WRAP)
	private boolean realComment;

	@AsCheckbox("是")
	@PropertyEditor(name = "真题学习", value = 12)
	@PropertyHelper(value = "做题时是否允许查看本题相关知识", type = HelperType.WRAP)
	private boolean realStudy;

	@AsCheckbox("是")
	@PropertyEditor(name = "真题答案", value = 2)
	@PropertyHelper(value = "做题时是否允许查看本题的答案", type = HelperType.WRAP)
	private boolean realAnswer;

	public boolean isPraxisComment() {
		return praxisComment;
	}

	public void setPraxisComment(boolean praxisComment) {
		this.praxisComment = praxisComment;
	}

	public boolean isPraxisStudy() {
		return praxisStudy;
	}

	public void setPraxisStudy(boolean praxisStudy) {
		this.praxisStudy = praxisStudy;
	}

	public boolean isExamComment() {
		return examComment;
	}

	public void setExamComment(boolean examComment) {
		this.examComment = examComment;
	}

	public boolean isExamStudy() {
		return examStudy;
	}

	public void setExamStudy(boolean examStudy) {
		this.examStudy = examStudy;
	}

	public boolean isRealComment() {
		return realComment;
	}

	public void setRealComment(boolean realComment) {
		this.realComment = realComment;
	}

	public boolean isRealStudy() {
		return realStudy;
	}

	public void setRealStudy(boolean realStudy) {
		this.realStudy = realStudy;
	}

	public boolean isPraxisAnswer() {
		return praxisAnswer;
	}

	public void setPraxisAnswer(boolean praxisAnswer) {
		this.praxisAnswer = praxisAnswer;
	}

	public boolean isExamAnswer() {
		return examAnswer;
	}

	public void setExamAnswer(boolean examAnswer) {
		this.examAnswer = examAnswer;
	}

	public boolean isRealAnswer() {
		return realAnswer;
	}

	public void setRealAnswer(boolean realAnswer) {
		this.realAnswer = realAnswer;
	}
}
