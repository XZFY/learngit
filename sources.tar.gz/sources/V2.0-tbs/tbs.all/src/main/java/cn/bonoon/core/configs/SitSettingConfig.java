package cn.bonoon.core.configs;

import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

@FormEditor(value = 2, headWidth = 120, width = 250)
public class SitSettingConfig {

	@PropertyEditor(name = "QQ客服一", value = 0, width = 100)
	@PropertyHelper(value = "客服一的QQ号码", type = HelperType.DIRECT)
	private String csOnline1;
	@PropertyEditor(name = "客服一提示", value = 1)
	private String csoTitle1;

	@PropertyEditor(name = "QQ客服二", value = 10, width = 100)
	@PropertyHelper(value = "客服二的QQ号码", type = HelperType.DIRECT)
	private String csOnline2;
	@PropertyEditor(name = "客服二提示", value = 11)
	private String csoTitle2;

	@PropertyEditor(name = "QQ客服三", value = 20, width = 100)
	@PropertyHelper(value = "客服三的QQ号码", type = HelperType.DIRECT)
	private String csOnline3;
	@PropertyEditor(name = "客服三提示", value = 21)
	private String csoTitle3;

	@PropertyEditor(name = "电话客服一", value = 30, width = 100)
	@PropertyHelper(value = "客服一的电话号码", type = HelperType.DIRECT)
	private String csPhone1;
	@PropertyEditor(name = "电话客服一提示", value = 31)
	private String cspTitle1;

	@PropertyEditor(name = "电话客服二", value = 40, width = 100)
	@PropertyHelper(value = "客服二的电话号码", type = HelperType.DIRECT)
	private String csPhone2;
	@PropertyEditor(name = "电话客服二提示", value = 41)
	private String cspTitle2;
	
	//是否开放注册
	@PropertyEditor(name = "是否开放注册", value = 50, colspan = 1)
	@PropertyHelper(value = "如果不开放注册，则只有通过后台或邀请的才允许进行注册", type = HelperType.DIRECT)
	private boolean openEnrollment;
	
	public String getCsOnline1() {
		return csOnline1;
	}
	public void setCsOnline1(String csOnline1) {
		this.csOnline1 = csOnline1;
	}
	public String getCsoTitle1() {
		return csoTitle1;
	}
	public void setCsoTitle1(String csoTitle1) {
		this.csoTitle1 = csoTitle1;
	}
	public String getCsOnline2() {
		return csOnline2;
	}
	public void setCsOnline2(String csOnline2) {
		this.csOnline2 = csOnline2;
	}
	public String getCsoTitle2() {
		return csoTitle2;
	}
	public void setCsoTitle2(String csoTitle2) {
		this.csoTitle2 = csoTitle2;
	}
	public String getCsOnline3() {
		return csOnline3;
	}
	public void setCsOnline3(String csOnline3) {
		this.csOnline3 = csOnline3;
	}
	public String getCsoTitle3() {
		return csoTitle3;
	}
	public void setCsoTitle3(String csoTitle3) {
		this.csoTitle3 = csoTitle3;
	}
	public String getCsPhone1() {
		return csPhone1;
	}
	public void setCsPhone1(String csPhone1) {
		this.csPhone1 = csPhone1;
	}
	public String getCspTitle1() {
		return cspTitle1;
	}
	public void setCspTitle1(String cspTitle1) {
		this.cspTitle1 = cspTitle1;
	}
	public String getCsPhone2() {
		return csPhone2;
	}
	public void setCsPhone2(String csPhone2) {
		this.csPhone2 = csPhone2;
	}
	public String getCspTitle2() {
		return cspTitle2;
	}
	public void setCspTitle2(String cspTitle2) {
		this.cspTitle2 = cspTitle2;
	}
	public boolean isOpenEnrollment() {
		return openEnrollment;
	}
	public void setOpenEnrollment(boolean openEnrollment) {
		this.openEnrollment = openEnrollment;
	}
	
}
