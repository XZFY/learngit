package cn.bonoon.controllers.pager;

import cn.bonoon.kernel.web.annotations.form.FormDetail;
import cn.bonoon.kernel.web.annotations.form.PropertyDetail;

@FormDetail
public class PagerDetail implements PagerDefine{
	
	@PropertyDetail(0)
	private String name;
	
	@PropertyDetail(10)
	private String type;
	
	@PropertyDetail(20)
	private int amount;
	@PropertyDetail(21)
	private boolean diamond;
	
	@PropertyDetail(30)
	private int count;
	
	@PropertyDetail(40)
	private String status;

	@PropertyDetail(41)
	private String trial;
	
	@PropertyDetail(50)
	private String remark;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

//	public int getPoints() {
//		return points;
//	}
//
//	public void setPoints(int points) {
//		this.points = points;
//	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getTrial() {
		return trial;
	}

	public void setTrial(String trial) {
		this.trial = trial;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public boolean isDiamond() {
		return diamond;
	}

	public void setDiamond(boolean diamond) {
		this.diamond = diamond;
	}
	
}
