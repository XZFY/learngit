package cn.bonoon.controllers.student;

import cn.bonoon.kernel.query.PageCondition;

public class StudentCondition extends PageCondition implements StudentDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3058649045631229868L;

}
