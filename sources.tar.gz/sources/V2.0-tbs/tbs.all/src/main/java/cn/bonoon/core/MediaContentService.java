package cn.bonoon.core;

import java.util.List;

import cn.bonoon.entities.BrowseRecordEntity;
import cn.bonoon.entities.MediaContentEntity;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.services.GenericService;

public interface MediaContentService extends GenericService<MediaContentEntity>{

	MediaContentEntity browse(IOperator user, Long id);

	List<BrowseRecordEntity> browseRecords(IOperator user, Long id);

}
