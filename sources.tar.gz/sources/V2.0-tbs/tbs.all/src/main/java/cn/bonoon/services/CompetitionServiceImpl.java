package cn.bonoon.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.CompetitionService;
import cn.bonoon.entities.CompetitionEntity;
import cn.bonoon.kernel.support.services.AbstractService;

@Service
@Transactional(readOnly = true)
public class CompetitionServiceImpl extends AbstractService<CompetitionEntity> implements CompetitionService {

}
