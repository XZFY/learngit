package cn.bonoon.core.infos;

import cn.bonoon.entities.CapabilityEvaluationItem;
import cn.bonoon.entities.KnowledgePointEntity;

public class EvaluationItemInfo {
	private final String name;
	
	private final int totalCount;
	
	private final int rightCount;
	
	private final double capability;
	
	public EvaluationItemInfo(KnowledgePointEntity kpe, CapabilityEvaluationItem cei) {
		this.name = kpe.getName();
		this.totalCount = cei.getTotalCount();
		this.rightCount = cei.getRightCount();
		this.capability = cei.getCapability();
	}

	public String getName() {
		return name;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public int getRightCount() {
		return rightCount;
	}

	public double getCapability() {
		return capability;
	}

}
