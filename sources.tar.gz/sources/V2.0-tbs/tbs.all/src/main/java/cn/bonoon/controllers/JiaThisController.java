//package cn.bonoon.controllers;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//import cn.bonoon.kernel.web.controllers.AbstractController;
//
//@Controller
//@RequestMapping("pmp/jiathis")
//public class JiaThisController extends AbstractController{
//	@RequestMapping("share.do")
//	public String share(Model model){
//		return "share";
//	}
//}
