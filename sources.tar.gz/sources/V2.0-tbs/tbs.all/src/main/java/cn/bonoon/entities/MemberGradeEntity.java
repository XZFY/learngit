package cn.bonoon.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import cn.bonoon.kernel.support.entities.AbstractEntity;

//会员级别
@Entity
@Table(name = "T_MEMBERGRADE")
public class MemberGradeEntity extends AbstractEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8934478621942918510L;

	@Column(name="C_POINTSLINE")
	private long pointsLine;

	public long getPointsLine() {
		return pointsLine;
	}

	public void setPointsLine(long pointsLine) {
		this.pointsLine = pointsLine;
	}
}
