package cn.bonoon.controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import cn.bonoon.core.ImportService;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.util.StringHelper;
import cn.bonoon.kernel.web.controllers.AbstractController;

public abstract class AbstractImportController extends AbstractController{

	@Autowired
	protected ImportService importService;
	
	protected final String rootPath = "/upload/import/";

	protected void unzip(MultipartFile annexFile) throws Exception {

		if(null == annexFile || annexFile.isEmpty()){
			return;
		}
		
		String ofn = annexFile.getOriginalFilename();
		if(!ofn.endsWith(".zip")){
			return;
		}
		
		String dirPath = servletContext.getRealPath(rootPath);// 取得存放的路径
		File outFile = new File(dirPath);
		if (!outFile.isDirectory()) {
			outFile.mkdirs();
		}
		File zFile = new File(dirPath + "/" + ofn);
		annexFile.transferTo(zFile);
		ZipFile zipFile = new ZipFile(zFile, "GBK");
		Enumeration<?> en = zipFile.getEntries();
		ZipEntry zipEntry = null;
		while (en.hasMoreElements()) {
			zipEntry = (ZipEntry) en.nextElement();
			if (zipEntry.isDirectory()) {
				// mkdir directory
				String dirName = zipEntry.getName();
				// System.out.println("=dirName is:=" + dirName + "=end=");
				dirName = dirName.substring(0, dirName.length() - 1);
				File f = new File(outFile.getPath() + File.separator + dirName);
				f.mkdirs();
			} else {
				// unzip file
				String strFilePath = outFile.getPath() + File.separator + zipEntry.getName();
				File f = new File(strFilePath);

				// the codes remedified by can_do on 2010-07-02 =begin=
				// /////begin/////
				// 判断文件不存在的话，就创建该文件所在文件夹的目录
				if (!f.exists()) {
					String[] arrFolderName = zipEntry.getName().split("/");
					String strRealFolder = "";
					for (int i = 0; i < (arrFolderName.length - 1); i++) {
						strRealFolder += arrFolderName[i] + File.separator;
					}
					strRealFolder = outFile.getPath() + File.separator + strRealFolder;
					File tempDir = new File(strRealFolder);
					// 此处使用.mkdirs()方法，而不能用.mkdir()
					tempDir.mkdirs();
				}
				// /////end///
				// the codes remedified by can_do on 2010-07-02 =end=
				f.createNewFile();
				InputStream in = zipFile.getInputStream(zipEntry);
				FileOutputStream out = new FileOutputStream(f);
				try {
					int c;
					byte[] by = new byte[1024];
					while ((c = in.read(by)) != -1) {
						out.write(by, 0, c);
					}
					// out.flush();
				} catch (IOException e) {
					throw e;
				} finally {
					out.close();
					in.close();
				}
			}
		}
		zipFile.close();
		//处理结束。删掉暂时文件
		zFile.delete();
	}
	
	private String _value(HSSFRow row, int j){
		HSSFCell cell = row.getCell(j);//e内容
		if(null != cell){
			String val = cell.getStringCellValue();
			if(null != val){
				return val.trim();
			}
		}
		return "";
	}
	
	/**
	 * 自动去掉前面两个字符
	 * @param row
	 * @param j
	 * @return
	 */
	private String _value2(HSSFRow row, int j){
		HSSFCell cell = row.getCell(j);//e内容
		if(null != cell){
			String val = cell.getStringCellValue();
			if(null != val && val.length() > 2){
				return val.substring(2).trim();
			}
			return val;
		}
		return "";
	}
	
	private String _value3(HSSFRow row, int j){
		String path = _value(row, j);
		if(!path.isEmpty()){
			if(path.startsWith("/")){
				return rootPath + path.substring(1);
			}
			return rootPath + path;
		}
		return path;
	}
	
	private Long _long(HSSFRow row, int j){
		HSSFCell cell = row.getCell(j);
		if(null != cell){
			if(cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
				return (long)cell.getNumericCellValue();
			}else{
				return StringHelper.toLong(cell.getStringCellValue());
			}
		}
		return null;
	}
	private int _int(HSSFRow row, int j){
		HSSFCell cell = row.getCell(j);
		if(null != cell){
			if(cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
				return (int)cell.getNumericCellValue();
			}
		}
		return 0;
	}
	
	private boolean _boolean(HSSFRow row, int j){
		HSSFCell cell = row.getCell(j);
		if(null != cell){
			return cell.getBooleanCellValue();
		}
		return false;
	}

	protected List<TopicEntity> __parse(MultipartFile excelFile, boolean pager) throws IOException {
		InputStream is = null;
		try{
			is = excelFile.getInputStream();
			POIFSFileSystem fs = new POIFSFileSystem(is);
			HSSFWorkbook wb = new HSSFWorkbook(fs);
			HSSFSheet st = wb.getSheetAt(0);
			int len = st.getLastRowNum();
			List<TopicEntity> topics = new ArrayList<TopicEntity>(200);
			for(int i = 1; i < len; i++){
				HSSFRow row = st.getRow(i);
			    if (row == null) {continue;}
			    int j = 1;
			    String code = _value(row, j++);//自定义的编码，由工作人员维护的一种编码，主要用在识别题目
			    
			    String ec = _value(row, j++);//e内容
			    String cc = _value(row, j++);
			    
			    if(StringHelper.isEmpty(cc) && StringHelper.isEmpty(ec)){ continue; }
			    
			    TopicEntity te = new TopicEntity();
			    te.setCode(code);
			    te.setEnContent(ec);
			    te.setCnContent(cc);
			    te.setAnswer(_value(row, j++));//正确答案
			    te.setArea(importService.getArea(_long(row, j++)));
			    te.setKnowledge(importService.getKnowledge(_long(row, j++)));
			    te.setGroup(importService.getGroup(_long(row, j++)));
			    te.setEnExplanation(_value(row, j++));
			    te.setCnExplanation(_value(row, j++));
			    
			    te.setEnOptionA(_value2(row, j++));
			    te.setCnOptionA(_value2(row, j++));
			    te.setEnOptionB(_value2(row, j++));
			    te.setCnOptionB(_value2(row, j++));
			    te.setEnOptionC(_value2(row, j++));
			    te.setCnOptionC(_value2(row, j++));
			    te.setEnOptionD(_value2(row, j++));
			    te.setCnOptionD(_value2(row, j++));
			    
			    te.setDifficulty(_int(row, j++));
			    
			    //读取文件，有三个。包括：英文图示、中文图示、题目的视频教学
			    te.setEnPicture(_value3(row, j++));
			    te.setCnPicture(_value3(row, j++));
			    te.setVideoPath(_value3(row, j++));
			    
			    if(!pager){
				    te.setFreeFast(_boolean(row, j++));//免费-快战
				    te.setFreeCombat(_boolean(row, j++));//免费-实战
				    te.setPraxis(_boolean(row, j++));//课后练习
				    te.setImprove(_boolean(row, j++));//提高练习
			    }
//			    te.setExam(_boolean(row, j++));
//			    te.setReal(_boolean(row, j++));
			    
			    topics.add(te);
			}
			return topics;
		}finally{
			if(null != is){
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
