package cn.bonoon.controllers;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.Util;
import cn.bonoon.core.KnowledgeAreaService;
import cn.bonoon.core.ProcessGroupService;
import cn.bonoon.core.ProcessService;
import cn.bonoon.core.configs.OpenedPointsConfig;
import cn.bonoon.core.infos.PraxisInfo;
import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.entities.BaseEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.MemberSettingEntity;
import cn.bonoon.kernel.security.LogonUser;

@Controller
@RequestMapping("pmp/improve")
public class MemberImproveController extends AbstractPracticeController{

	@Autowired
	private KnowledgeAreaService knowledgeAreaService;
	@Autowired
	private ProcessGroupService processGroupService;
	@Autowired
	private ProcessService processService;
	
	@Override
	protected void open(MemberSettingEntity fm, int cost, Date now) {
		fm.setImproveAt(now);
		fm.setImproveOpened(true);
		fm.setImprovePoints(cost);
	}

	@Override
	protected void init() {
		functionName 	= "提高";
		functionTitle 	= "提高";
		functionMenu 	= "menus/menu-improve.vm";
		channelSelected = "improve";
		vmName 			= "practices/improve";
		vmTrial 		= "practices/free";
		trialTitle 		= "<span style='font-size: 18px; font-family: Arial;padding-left:15px;'>试用</span>";
	}

	@Override
	protected boolean hasOpened(MemberSettingEntity fm) {
		return fm.isImproveOpened();
	}
	
	@Override
	protected int reachPoint(OpenedPointsConfig opc) {
		return opc.getImproveReach();
	}
	
	@Override
	protected int openCost(OpenedPointsConfig opc) {
		return opc.getImproveCost();
	}

	@Override
	protected boolean openCoseCash(OpenedPointsConfig opc) {
		return opc.isImproveCostCash();
	}
	
	@Override
	protected String trial(HttpServletRequest request, Model model) {
		String type = request.getParameter("type");
		Long selectedId = getLong(request, "selectedId");
		List<? extends BaseEntity> items;
		if("area".equals(type)){
			items = knowledgeAreaService.find(" order by x.id asc");
			BaseEntity be = Util.find(items, selectedId);
			if(null != be){
				selectedId = be.getId();
				model.addAttribute("topics", topicService.trialArea(selectedId));
			}
		}else if("process".equals(type)){
			items = processService.find(" order by x.id asc");
			BaseEntity be = Util.find(items, selectedId);
			if(null != be){
				selectedId = be.getId();
				model.addAttribute("topics", topicService.trialProcess(selectedId));
			}
		}else{
			type = "group";
			items = processGroupService.find(" order by x.id asc");
			BaseEntity be = Util.find(items, selectedId);
			if(null != be){
				selectedId = be.getId();
				model.addAttribute("topics", topicService.trialGroup(selectedId));
			}
		}

//		model.addAttribute("showTopicHead", true);
		model.addAttribute("menuSelected", type);
		
		if(null == selectedId){
			selectedId = 0L;
		}
		StringBuilder selector = new StringBuilder();
		selector.append("<select onchange='window.location.href=\"index.do?type=");
		selector.append(type).append("&selectedId=\" + jQuery(this).val();'>");
		for(BaseEntity be : items){
			selector.append("<option value='").append(be.getId());
			if(selectedId.equals(be.getId())){
				selector.append("' selected='selected");
			}
			selector.append("'>").append(be.getName()).append("</option>");
		}
		selector.append("</select>");
//		model.addAttribute("topicTitle", selector);
//		showHead(model, "切换：", selector.toString());
		
		model.addAttribute("showTopicHead", true);
		model.addAttribute("topicTitle", "<span style='font-size: 18px; font-family: Arial;padding-left:15px;'>切换：</span>" + selector);

		return super.trial(request, model);
	}

	@RequestMapping("items.do")
	public String items(Model model, String type, Long selectedId){
		__items(model, type, selectedId, getUser());
		model.addAttribute("layout", "layout-empty.vm");
		return "practices/improve-items";
	}
	
	@Override
	protected String render(HttpServletRequest request, Model model, MemberEntity member, LogonUser user) {
		String type = request.getParameter("type");
		Long selectedId = getLong(request, "selectedId");
		
		List<? extends BaseEntity> items = __items(model, type, selectedId, user);
		model.addAttribute("selector", items);
		return super.render(request, model, member, user);
	}
	
	private List<? extends BaseEntity> __items(Model model, String type, Long selectedId, LogonUser user){
		List<? extends BaseEntity> items = null;
		try{
			PraxisInfo topics;
			if("area".equals(type)){
				items = knowledgeAreaService.find(" order by x.id asc");
				selectedId = Util.find(items, selectedId).getId();
				topics = topicService.improveArea(user, selectedId);
			}else if("process".equals(type)){
				items = processService.find(" order by x.id asc");
				selectedId = Util.find(items, selectedId).getId();
				topics = topicService.improveProcess(user, selectedId);
			}else{
				type = "group";
				items = processGroupService.find(" order by x.id asc");
				selectedId = Util.find(items, selectedId).getId();
				topics = topicService.improveGroup(user, selectedId);
			}
			model.addAttribute("praxis", topics);
			model.addAttribute("selectedId", selectedId);
			model.addAttribute("type", type);
			model.addAttribute("menuSelected", type);
		}catch(Exception ex){
			loadWarning(model, ex);
		}
		return items;
	}

	@RequestMapping("{type}!{tid}!start.do")
	public String start(HttpServletRequest request, Model model, @PathVariable("type") String type, @PathVariable("tid") Long tid){
		try{
			String name;
			AnswerEntity answer;
			if("area".equals(type)){
				name = knowledgeAreaService.getName(tid);
				answer = topicService.startImproveArea(getUser(), tid);
			}else if("process".equals(type)){
				name = processService.getName(tid);
				answer = topicService.startImproveProcess(getUser(), tid);
			}else{
				type = "group";
				name = processGroupService.getName(tid);
				answer = topicService.startImproveGroup(getUser(), tid);
			}
			__parse(request, model, type, tid, name, answer);

		}catch(Exception ex){
			warning(model, ex);
		}
		return showProactice(model);
	}

	@RequestMapping("{type}!{tid}/{id}!start.do")
	public String start(HttpServletRequest request, Model model, @PathVariable("type") String type, @PathVariable("tid") Long tid, @PathVariable("id") Long id){
		try{
			String name;
			AnswerEntity answer;
			if("area".equals(type)){
				name = knowledgeAreaService.getName(tid);
				answer = topicService.startImproveArea(getUser(), tid, id);
			}else if("process".equals(type)){
				name = processService.getName(tid);
				answer = topicService.startImproveProcess(getUser(), tid, id);
			}else{
				type = "group";
				name = processGroupService.getName(tid);
				answer = topicService.startImproveGroup(getUser(), tid, id);
			}
			__parse(request, model, type, tid, name, answer);

		}catch(Exception ex){
			warning(model, ex);
		}
		return showProactice(model);
	}

	private void __parse(HttpServletRequest request, Model model, String type, Long tid, String name, AnswerEntity answer) {
		__parse(model, answer);
		if(!"p".equals(request.getParameter("in"))){
			model.addAttribute("moreUrl", type + "!" + tid + "!start.do");
		}
		showHead(model, name);
	}
	
	@RequestMapping("{type}!{tid}/{id}!restart.do")
	public String restart(HttpServletRequest request, Model model, @PathVariable("type") String type, @PathVariable("tid") Long tid, @PathVariable("id") Long id){
		try{	
			String name;
			AnswerEntity answer;
			if("area".equals(type)){
				name = knowledgeAreaService.getName(tid);
				answer = topicService.restartImproveArea(getUser(), tid, id);
			}else if("process".equals(type)){
				name = processService.getName(tid);
				answer = topicService.restartImproveProcess(getUser(), tid, id);
			}else{
				type = "group";
				name = processGroupService.getName(tid);
				answer = topicService.restartImproveGroup(getUser(), tid, id);
			}
			__parse(request, model, type, tid, name, answer);

		}catch(Exception ex){
			warning(model, ex);
		}
		return showProactice(model);
	}
	
}
