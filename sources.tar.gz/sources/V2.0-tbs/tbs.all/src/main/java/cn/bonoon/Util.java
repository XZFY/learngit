package cn.bonoon;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import cn.bonoon.entities.BaseEntity;
import cn.bonoon.kernel.support.models.Page;

public class Util {
	public static String host(HttpServletRequest request){
		return request.getScheme() + "://" + request.getServerName() + ':' + request.getServerPort() + request.getContextPath();
	}
	
	public static String timeSpent(long timeSpent){
		timeSpent /= 1000;
		String strTimeSpent = (timeSpent % 60) + "秒";
		timeSpent /= 60;
		if(timeSpent > 0){
			strTimeSpent = (timeSpent % 60) + "分" + strTimeSpent;
			timeSpent /= 60;
			if(timeSpent > 0){
				strTimeSpent = (timeSpent % 60) + "时" + strTimeSpent;
			}
		}
		return strTimeSpent;
	}
	
	public static BaseEntity find(List<? extends BaseEntity> kas, Long chapterId){
		//章节随机出题
		if(chapterId != null){
			for(BaseEntity ka : kas){
				if(chapterId.equals(ka.getId())){
					return ka;
				}
			}
		}
		if(kas.isEmpty()){
			return null;
		}
		return kas.get(0);
	}
	
	private final static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
	public static String toString(Date date){
		try{
			return sdf.format(date);
		}catch(Exception ex){
			return "";
		}
	}
	
	public static void paging(Model model, Page page, int pageIndex, int pageSize, String params){
		model.addAttribute("pageIndex", pageIndex);
		if(null != page){
			/*
			 * pageIndex 0,1...N
			 */
			long total = page.getTotal(), size = page.getRows().size();
			if(total > size){
				StringBuilder buttons = new StringBuilder();

				//--------------------------------------刷新按钮
				StringBuilder refreshUrl = new StringBuilder();
				refreshUrl.append(pageIndex).append("!index.do").append(params);
				model.addAttribute("refreshUrl", refreshUrl);
				
				long pageCount = ((total - 1) / pageSize) + 1;//总的有多少页
				long from = pageIndex * pageSize, to = from + size;
				buttons.append("记录：").append(total).append('[').append(from + 1).append("...").append(to).append(']');
				//只显示三个数字
				if(pageCount > 3){
					if(pageIndex > 1){
						//...2,3,4...
						//只有这个情况下才显示首页，并且以<<来表示
						buttons.append("<a href='0!index.do").append(params).append("' onclick='jQuery(\"#lb-items-paging\").load(this.href); return false;'>&lt;&lt;</a>...");
						long preIndex = pageIndex - 1, nexIndex = pageIndex + 1;
						buttons.append("<a href='").append(preIndex).append("!index.do").append(params).append("' onclick='jQuery(\"#lb-items-paging\").load(this.href); return false;'> ").append(preIndex + 1).append(" </a>,");
						buttons.append("<span class='cpb' style='font-weight:bold;color:blue;'> ").append(pageIndex + 1).append(" </span>");
						if(nexIndex < pageCount){
							buttons.append(",<a href='").append(nexIndex).append("!index.do").append(params).append("' onclick='jQuery(\"#lb-items-paging\").load(this.href); return false;'> ").append(nexIndex + 1).append(" </a>");
							if(nexIndex + 1 < pageCount){
								buttons.append("<a href='").append(pageCount - 1).append("!index.do").append(params).append("' onclick='jQuery(\"#lb-items-paging\").load(this.href); return false;'>&gt;&gt;</a>");
							}
						}
					}else{
						//1,2,3...>>
						//可能选择1，也可能选择2的情况
						if(pageIndex == 0){
							buttons.append("<span class='cpb' style='font-weight:bold;color:blue;'> 1 </span>,");
						}else{
							buttons.append("<a href='0!index.do").append(params).append("' onclick='jQuery(\"#lb-items-paging\").load(this.href); return false;'> 1 </a>,");
						}
						if(pageIndex == 1){
							buttons.append("<span class='cpb' style='font-weight:bold;color:blue;'> 2 </span>,");
						}else{
							buttons.append("<a href='1!index.do").append(params).append("' onclick='jQuery(\"#lb-items-paging\").load(this.href); return false;'> 2 </a>,");
						}
						buttons.append("<a href='2!index.do").append(params).append("' onclick='jQuery(\"#lb-items-paging\").load(this.href); return false;'> 3 </a>...");
						buttons.append("<a href='").append(pageCount - 1).append("!index.do").append(params).append("' onclick='jQuery(\"#lb-items-paging\").load(this.href); return false;'>&gt;&gt;</a>");
					}
				}else{
					//小于3页的情况
					//也不需要出现第一页和最后一页
					for(int i = 0; i < pageCount; i++){
						if(i > 0){
							buttons.append(',');
						}
						if(i == pageIndex){
							buttons.append("<span class='cpb' style='font-weight:bold;color:blue;'> ").append(i + 1).append(" </span>");
						}else{
							buttons.append("<a href='").append(i).append("!index.do").append(params).append("' onclick='jQuery(\"#lb-items-paging\").load(this.href); return false;'> ").append(i + 1).append(" </a>");
						}
					}
				}
				model.addAttribute("paging", buttons);
			}
		}
	}
	
	public static String videoParse(String path, String ext){
		return path;
	}
}
