package cn.bonoon.entities;

import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * 对试卷的评论、评分
 * @author jackson
 *
 */
@Entity
@Table(name = "CT_PAGER")
public class PagerComment extends AbstractComment<PagerEntity>{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5900016984778550152L;
}
