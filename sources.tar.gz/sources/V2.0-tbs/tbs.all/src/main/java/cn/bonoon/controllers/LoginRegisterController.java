package cn.bonoon.controllers;

import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message.RecipientType;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.bonoon.Util;
import cn.bonoon.core.ConfigService;
import cn.bonoon.core.MemberService;
import cn.bonoon.core.configs.EmailConfig;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.kernel.events.BaseEvent;
import cn.bonoon.kernel.util.StringHelper;
import cn.bonoon.kernel.web.models.JsonResult;
import cn.bonoon.util.VerifyCodeHelper;

@Controller
@RequestMapping("u/login")
public class LoginRegisterController {
	
	@Autowired
    @Qualifier("authenticationManager")
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private MemberService memberService;

	@Autowired
	private ConfigService configService;
	
	@ResponseBody
	@RequestMapping(value = "register", method = RequestMethod.POST)
	public JsonResult register(HttpServletRequest request, String loginName, String userName, 
			String loginPassword, String confirmPassword, String regCaptcha, String introducekey){
		
		try{//这里实现注册后可以自动登录
			VerifyCodeHelper.verify(request, 2, regCaptcha);
			
			memberService.register(loginName, userName, loginPassword, confirmPassword, introducekey);
			UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(loginName, loginPassword);
	        token.setDetails(new WebAuthenticationDetails(request));
	        Authentication authenticatedUser = authenticationManager.authenticate(token);

	        SecurityContextHolder.getContext().setAuthentication(authenticatedUser);
	        return JsonResult.result();
        }catch(Exception ex){
        	ex.printStackTrace();
        	return JsonResult.error(ex);
        }
	}
	
	@RequestMapping(value = "retrieve/password.do", method = RequestMethod.GET)
	public String retrieve(Model model){
		model.addAttribute("layout", "layout-empty.vm");
		return "mgr/retrieve-pwd";
	}
	
	private static final char[] CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890@#$&".toCharArray();
	
	private void random(StringBuilder sb){
		int i = (int)(Math.random() * 1000) % CHARS.length;
		sb.append(CHARS[i]);
	}
	
	@ResponseBody
	@RequestMapping(value = "retrieve/password.do", method = RequestMethod.POST)
	public JsonResult retrieve(HttpServletRequest request, String rpname, String rpemail){
		try{
			final EmailConfig ec = new EmailConfig();
			configService.read(new BaseEvent(ec), EmailConfig.class);
			if(StringHelper.isEmpty(ec.getSmtpHost()) 
					|| StringHelper.isEmpty(ec.getUsername())
					|| StringHelper.isEmpty(ec.getPassword())){
				throw new Exception("暂时不支持找回密码的功能！");
			}
			if(StringHelper.isEmpty(rpname)){
				throw new Exception("请输入用户名！");
			}
			if(StringHelper.isEmpty(rpemail)){
				throw new Exception("请输入用户登记的邮箱！");
			}
			MemberEntity member = memberService.get(rpname);
			if(null == member){
				throw new Exception("用户【" + rpname + "】不存在！");
			}
			if(StringHelper.isEmpty(member.getEmail())){
				throw new Exception("用户【" + rpname + "】没有登记邮箱！");
			}
			if(!rpemail.equals(member.getEmail())){
				throw new Exception("您输入的邮箱【" + rpemail + "】与已登记邮箱不一致，无法找回密码！");
			}
			//随机生成密码
			StringBuilder npwd = new StringBuilder();
			random(npwd);//1
			random(npwd);//2
			random(npwd);//3
			random(npwd);//4
			random(npwd);//5
			random(npwd);//6
			
			try{
				Properties props = System.getProperties();
				props.put("mail.smtp.auth", Boolean.toString(ec.isSmtpAuth()));
				props.put("mail.smtp.host", ec.getSmtpHost());
				//authenticator = new MailAuthenticator(ec.getUsername(), ec.getPassword());
				Session session = Session.getInstance(props, new Authenticator(){
					@Override
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(ec.getUsername(), ec.getPassword());
					}
				});
				final MimeMessage message = new MimeMessage(session);
				message.setFrom(new InternetAddress(ec.getUsername()));
				message.setRecipient(RecipientType.TO, new InternetAddress(rpemail));
				message.setSubject("找回密码");
				StringBuilder content = new StringBuilder();
				content.append("<p>您好：</p>");
				content.append("<p style='text-indet:2em;font-size:18px;'>您于").append(StringHelper.date2String(new Date()));
				content.append("进行密码找回，系统为您重新生成的密码【<span style='color:red;'>").append(npwd).append("</span>】，请尽快登录并修改密码！</p>");
				content.append("<p style='padding:10px 0 0 50px;'><a style='font-size:16px;color:blue;' href='").append(Util.host(request)).append("'>点击这里</a>");
				content.append("可以直接进入系统</p>");
				 message.setContent(content.toString(), "text/html;charset=utf-8");
				Transport.send(message);
				
				memberService.update(member, npwd.toString());
			}catch(Exception ex){
				ex.printStackTrace();
				throw new Exception("暂时不支持找回密码的功能！");
			}
			
			//发送邮件
			return JsonResult.result();
		}catch (Exception e) {
			return JsonResult.error(e);
		}
	}
}
