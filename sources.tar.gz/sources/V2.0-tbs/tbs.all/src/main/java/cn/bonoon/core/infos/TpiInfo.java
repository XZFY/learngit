package cn.bonoon.core.infos;

import java.util.List;

import cn.bonoon.core.configs.TpiConfig;
import cn.bonoon.entities.AnswerStatisticsItem;
import cn.bonoon.entities.BaseEntity;
import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.entities.ProcessGroupEntity;

public class TpiInfo {
	private final StringBuilder html = new StringBuilder();
	public TpiInfo(
			TpiConfig config,
			List<AnswerStatisticsItem> aas, 
			List<KnowledgeAreaEntity> aes,
			List<AnswerStatisticsItem> gas, 
			List<ProcessGroupEntity> ges,
			List<?> saa, 
			List<?> sga) {
		int passLine = config.getPassLine(), secureLine = config.getSecureLine();
		if(passLine < 1){
			passLine = 60;
		}
		if(secureLine < 1){
			secureLine = 75;
		}
		int p2 = config.getPercentage();
		if(p2 < 1){
			p2 = 60;
		}
		int p1 = 100 - p2;
		TpiItme areaItme = new TpiItme(), groupItem = new TpiItme();
		for(KnowledgeAreaEntity pe : aes){
			areaItme.add(pe, find(aas, pe), find2(saa, pe), p1, p2);
		}
		for(ProcessGroupEntity ge : ges){
			groupItem.add(ge, find(gas, ge), find2(sga, ge), p1, p2);
		}
		areaItme.end(html, "chart-process-container", "领域TPI");
		groupItem.end(html, "chart-group-container", "过程组TPI");
		
		average = (areaItme.right + groupItem.right) * 100 / (areaItme.total + groupItem.total);
		if(average > secureLine){
			result = "<span style='color:blue;'>可以通过</span>";
		}else if(average < passLine){
			result = "<span style='color:red;'>需要努力</span>";
		}else{
			result = "<span style='color:gray;'>勉强通过</span>";
		}
	}
	
	private int average;
	private String result;
	
	public String getResult() {
		return result;
	}
	
	public int getAverage() {
		return average;
	}
	
	@Override
	public String toString() {
		return html.toString();
	}

	public static class TpiItme{
		private String categories = "";
		
		//历史
		private String history = "";
		//当前
		private String current = "";
		
		//平均，综合计算
		private String average = "";
		
		void end(StringBuilder html, String id, String title){
			if(!categories.isEmpty()){
				html.append("jQuery('#").append(id).append("').highcharts({chart:{},title:{text:'");
				html.append(title).append("'},xAxis:{categories:[");
				html.append(categories.substring(1)).append("]},tooltip:{formatter:function(){return this.x+': '+this.y;}},series:[{type:'column', name: '历次练习', data:[");
				
				html.append(history.substring(1)).append("]},{type:'column', name: '最近练习', data:[");
				html.append(current.substring(1)).append("]},{name: '平均成绩', data:[");
				html.append(average.substring(1)).append("]}]");
						
				html.append(",credits:{enabled:false},exporting:{enabled:false}});");
			}
		}
		
		int right, total;
		int cal(int r, int t, int h, double w){
			if(t > 0){
				if(w > 0){
					right += r * h * w;
					total += t * h * w;
				}else{
					right += r * h;
					total += t * h;
				}
				return r * 100 / t;
			}
			return 0;
		}
		
		void add(BaseEntity be, AnswerStatisticsItem ai, Object[] ss, int p1, int p2){
			categories += ",'" + be.getName() + "'";
			int sca = 0, scs = 0;
			double w = be.getWeight();
			if(null != ai){
				sca = cal(ai.getRight(), ai.getTotal(), 60, w);
			}
			if(null != ss){
				scs = cal(((Number)ss[1]).intValue(), ((Number)ss[2]).intValue(), 40, w);
			}
			
			int av = 0;
			if(sca > 0 && scs > 0){
				av = ((scs * p1) + (sca * p2)) / 100;
			}else{
				av = sca + scs;//不用管哪一个值为0
			}
			
			current += "," + sca;
			history += "," + scs;
			average += "," + av;
		}
	}
	
	private AnswerStatisticsItem find(List<AnswerStatisticsItem> as, BaseEntity be){
		for(AnswerStatisticsItem ai : as){
			if(ai.getTid().equals(be.getId())){
				return ai;
			}
		}
		return null;
	}
	
	private Object[] find2(List<?> as, BaseEntity be){
		for(Object os : as){
			Object[] ss = (Object[])os;
			if(be.getId().longValue() == ((Number)ss[0]).longValue()){
				return ss;
			}
		}
		return null;
	}
}
