package cn.bonoon.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.KnowledgeAreaService;
import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.kernel.support.services.AbstractService;

@Service
@Transactional(readOnly = true)
public class KnowledgeAreaServiceImpl extends AbstractService<KnowledgeAreaEntity> implements KnowledgeAreaService{

	@Override
	public String getName(Long id) {
		String ql = "select x.name from KnowledgeAreaEntity x where x.id=?";
		return __first(String.class, ql, id);
	}

}
