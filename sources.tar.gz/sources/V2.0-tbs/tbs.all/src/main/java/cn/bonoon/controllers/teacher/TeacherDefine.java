package cn.bonoon.controllers.teacher;

import cn.bonoon.kernel.annotations.OptionArray;
import cn.bonoon.kernel.annotations.ResetProperties;
import cn.bonoon.kernel.annotations.ResetProperty;

@ResetProperties({
	@ResetProperty(value = "name", name = "教师姓名"),
	@ResetProperty(value = "loginName", name = "登录账号"),
	@ResetProperty(value = "courseNames", name = "课程"),
	@ResetProperty(value = "institution", name = "机构"),
	@ResetProperty(value = "introduction", name = "介绍"),
	@ResetProperty(value = "entryAt", name = "入职时间"),
	@ResetProperty(value = "tel", name = "电话"),
	@ResetProperty(value = "phone", name = "手机"),
	@ResetProperty(value = "remark", name = "备注"),
	@ResetProperty(value = "status", name = "状态", 
		options = @OptionArray(value = {"禁用", "未启用", "正常", "其它"}, offset = -1))
})
public interface TeacherDefine {

}
