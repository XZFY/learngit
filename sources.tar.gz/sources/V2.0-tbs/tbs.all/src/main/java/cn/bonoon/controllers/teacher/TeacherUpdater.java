package cn.bonoon.controllers.teacher;

import cn.bonoon.kernel.annotations.Transform;
import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.annotations.WriteModel;
import cn.bonoon.kernel.util.BoolType;
import cn.bonoon.kernel.web.annotations.form.FormUpdate;
import cn.bonoon.kernel.web.annotations.form.PropertyUpdate;

@Transform
@FormUpdate(2)
public class TeacherUpdater extends TeacherEditor{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2122382409946119255L;

	@TransformField(writable = WriteModel.NONE)
	@PropertyUpdate(readonly = BoolType.TRUE, value = 0)
	private String loginName;

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
}
