package cn.bonoon.core.infos;

import java.util.List;

public class AbstractRecord {

	/**
	 * 总题目数
	 */
	private int count;
	private List<RecordItem> records;
	
	private boolean canNew;

	public List<RecordItem> getRecords() {
		return records;
	}

	public void setRecords(List<RecordItem> records) {
		this.records = records;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public boolean isCanNew() {
		return canNew;
	}

	public void setCanNew(boolean canNew) {
		this.canNew = canNew;
	}

}
