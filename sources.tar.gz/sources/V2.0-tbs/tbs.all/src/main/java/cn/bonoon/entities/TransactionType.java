package cn.bonoon.entities;

public enum TransactionType {
	DEDUCT("扣除"),
	INCREASE("增加"),
	BUY("购买"),
	ADJUST("调整"),
	GIFTOUT("接收积分"),//赠送的积分，这种积分应该不会增加总积分
	GIFTIN("送出积分"),//接收别人赠送的积分
	AWARD("积分奖励"),//奖励的积分
	OTHER("其它");
	
	private final String title;
	
	private TransactionType(String title){
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}
}
