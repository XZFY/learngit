package cn.bonoon.core;

public interface IStudentRecommend {

	int getSeatNumber();
	
	Long getClasses();
}
