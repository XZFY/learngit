package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

@Entity
@Table(name = "T_BROWSERECORD")
public class BrowseRecordEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5988871991535914353L;

	@Column(name = "C_NAME")
	private String name;
	@Column(name = "C_TID")
	private Long tid;
	@Column(name = "C_UID")
	private Long uid;
	@Column(name = "C_TYPE")
	private int type;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CREATEAT")
	private Date createAt;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_LASTAT")
	private Date lastAt;
	
	@Column(name = "C_COUNT")
	private int count;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Long getUid() {
		return uid;
	}
	public void setUid(Long uid) {
		this.uid = uid;
	}
	public Date getCreateAt() {
		return createAt;
	}
	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}
	public Date getLastAt() {
		return lastAt;
	}
	public void setLastAt(Date lastAt) {
		this.lastAt = lastAt;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public Long getTid() {
		return tid;
	}
	public void setTid(Long tid) {
		this.tid = tid;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
}
