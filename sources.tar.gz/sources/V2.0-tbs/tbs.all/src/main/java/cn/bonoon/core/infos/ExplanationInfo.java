package cn.bonoon.core.infos;

import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.util.StringHelper;

public class ExplanationInfo {
	private Long id;
	private String key;
	private String explanation;
	private String answer;
	private String ext;
	private String path;
	private boolean hasAnswer;
	
	public ExplanationInfo(TopicEntity te, Boolean isen){
		id = te.getId();
		key = te.getKey();
		answer = te.getAnswer();
		//String ans = te.getAnswer();
		if(null != answer){
			answer = answer.trim().toUpperCase();
		}
		path = te.getVideoPath();
		ext = te.getVideoExt();
		
		if(null != isen && isen.booleanValue()){
			explanation = te.getEnExplanation();
		}else{
			explanation = te.getCnExplanation();
		}
		if(StringHelper.isEmpty(explanation)){
			explanation = null;
		}else{
			hasAnswer = true;
		}
		if(StringHelper.isEmpty(path)){
			path = null;
		}else{
			hasAnswer = true;
		}
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getExplanation() {
		return explanation;
	}
	public void setExplanation(String explanation) {
		this.explanation = explanation;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getExt() {
		return ext;
	}

	public void setExt(String ext) {
		this.ext = ext;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public boolean isHasAnswer() {
		return hasAnswer;
	}

	public void setHasAnswer(boolean hasAnswer) {
		this.hasAnswer = hasAnswer;
	}
}
