package cn.bonoon.core;

import cn.bonoon.entities.TeachingEntity;
import cn.bonoon.kernel.support.services.GenericService;

public interface TeachingService extends GenericService<TeachingEntity>{

}
