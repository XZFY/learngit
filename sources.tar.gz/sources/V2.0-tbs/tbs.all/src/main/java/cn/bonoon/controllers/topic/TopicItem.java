package cn.bonoon.controllers.topic;

import cn.bonoon.kernel.annotations.Cutoff;
import cn.bonoon.kernel.annotations.CutoffType;
import cn.bonoon.kernel.annotations.OptionArray;
import cn.bonoon.kernel.support.models.AbstractItem;
import cn.bonoon.kernel.web.annotations.grid.AsColumn;
import cn.bonoon.kernel.web.annotations.grid.AsDataGrid;
import cn.bonoon.kernel.web.annotations.grid.GridOptions;

@AsDataGrid(condition = TopicCondition.class, value = @GridOptions(operationWith = 180))
public class TopicItem extends AbstractItem implements TopicDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7929608559868027596L;

	@AsColumn(width = 60, ordinal = 0)
	private String code;
	@AsColumn(width = 300, ordinal = 1)
	@Cutoff(value = 30, type = CutoffType.HTML)
	private String cnContent;
	@AsColumn(width = 40, ordinal = 2)
	private int difficulty;
	@AsColumn(width = 40, ordinal = 10)
	@OptionArray({"否", "是"})
	private String freeFast;
	@AsColumn(width = 40, ordinal = 11)
	@OptionArray({"否", "是"})
	private String freeCombat;
	@AsColumn(width = 40, ordinal = 12)
	@OptionArray({"否", "是"})
	private String praxis;
	@AsColumn(width = 40, ordinal = 13)
	@OptionArray({"否", "是"})
	private String improve;
	@AsColumn(width = 40, ordinal = 14)
	@OptionArray({"否", "是"})
	private String exam;
	@AsColumn(width = 40, ordinal = 15)
	@OptionArray({"否", "是"})
	private String real;
	
	public int getDifficulty() {
		return difficulty;
	}
	public void setDifficulty(int difficulty) {
		this.difficulty = difficulty;
	}
	
	public String getPraxis() {
		return praxis;
	}
	public void setPraxis(String praxis) {
		this.praxis = praxis;
	}
	public String getExam() {
		return exam;
	}
	public void setExam(String exam) {
		this.exam = exam;
	}
	public String getReal() {
		return real;
	}
	public void setReal(String real) {
		this.real = real;
	}
	public String getCnContent() {
		return cnContent;
	}
	public void setCnContent(String cnContent) {
		this.cnContent = cnContent;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getFreeFast() {
		return freeFast;
	}
	public void setFreeFast(String freeFast) {
		this.freeFast = freeFast;
	}
	public String getFreeCombat() {
		return freeCombat;
	}
	public void setFreeCombat(String freeCombat) {
		this.freeCombat = freeCombat;
	}
	public String getImprove() {
		return improve;
	}
	public void setImprove(String improve) {
		this.improve = improve;
	}
	
}
