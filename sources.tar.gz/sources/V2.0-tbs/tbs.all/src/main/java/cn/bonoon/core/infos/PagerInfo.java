package cn.bonoon.core.infos;

public class PagerInfo extends AbstractRecord{

}
