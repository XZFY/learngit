package cn.bonoon;

import java.util.Collection;

public class MappingId {
	private final Long sid;
	private final Long tid;
	
	public MappingId(Long sid, Long tid){
		this.sid = sid;
		this.tid = tid;
	}

	public Long getSid() {
		return sid;
	}

	public Long getTid() {
		return tid;
	}
	
	public static Long find(Collection<MappingId> mappings, Long id){
		for(MappingId mi : mappings){
			if(id.equals(mi.sid)){
				return mi.tid;
			}
		}
		return null;
	}
}
