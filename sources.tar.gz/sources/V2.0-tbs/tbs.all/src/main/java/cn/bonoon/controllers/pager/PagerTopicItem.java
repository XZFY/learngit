package cn.bonoon.controllers.pager;

import cn.bonoon.kernel.annotations.Cutoff;
import cn.bonoon.kernel.annotations.CutoffType;
import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.support.models.AbstractItem;
import cn.bonoon.kernel.web.annotations.grid.AsColumn;
import cn.bonoon.kernel.web.annotations.grid.AsDataGrid;
import cn.bonoon.kernel.web.annotations.grid.GridOptions;
import cn.bonoon.kernel.web.annotations.grid.PaginationType;

@AsDataGrid(
		pagination = PaginationType.NONE, 
		condition = PagerTopicCondition.class, 
		value = @GridOptions(sortName = "ordinal"))
public class PagerTopicItem extends AbstractItem{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4842673680391094297L;
	
	@AsColumn(width = 80, ordinal = 0, name = "序号", sortable = false, editor = "numberbox")
	private int ordinal;
	
	@TransformField("ordinal")
	private int hiddenOrdinal;
	
	@TransformField("topic.cnContent")
	@Cutoff(value = 200, type = CutoffType.HTML)
	@AsColumn(width = 350, name = "题目", sortable = false)
	private String cnContent;
	
	@TransformField("topic.id")
	private Long topic;
	
	public int getOrdinal() {
		return ordinal;
	}
	public void setOrdinal(int ordinal) {
		this.ordinal = ordinal;
	}
	
	public Long getTopic() {
		return topic;
	}
	public void setTopic(Long topic) {
		this.topic = topic;
	}
	public int getHiddenOrdinal() {
		return hiddenOrdinal;
	}
	public void setHiddenOrdinal(int hiddenOrdinal) {
		this.hiddenOrdinal = hiddenOrdinal;
	}
	public String getCnContent() {
		return cnContent;
	}
	public void setCnContent(String cnContent) {
		this.cnContent = cnContent;
	}
}
