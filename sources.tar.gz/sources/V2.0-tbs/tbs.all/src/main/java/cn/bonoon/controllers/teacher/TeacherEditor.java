package cn.bonoon.controllers.teacher;

import java.util.Date;

import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.support.models.ObjectEditor;
import cn.bonoon.kernel.web.annotations.components.AsSelector;
import cn.bonoon.kernel.web.annotations.components.AsTextArea;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;

public abstract class TeacherEditor extends ObjectEditor implements TeacherDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3339482189739504264L;

	@TransformField
	@PropertyEditor(1)
	private String name;

//	@TransformField
//	@PropertyEditor(10)
//	@AsComboBox
//	@AutoDataLoader(TrainingInstitutionEntity.class)
//	@FilterParameter("id")
//	private Long institution;

	@TransformField
	@PropertyEditor(20)
	private String tel;

	@TransformField
	@PropertyEditor(21)
	private String phone;

	@TransformField
	@PropertyEditor(colspan = 1, value = 30)
	private String courseNames;

	@TransformField
	@PropertyEditor(colspan = 1, value = 40)
	@AsTextArea
	private String introduction;

	@TransformField
	@PropertyEditor(10)
	@AsSelector
	private int status;
	
	@TransformField
	@PropertyEditor(11)
	private Date entryAt;

	@TransformField
	@PropertyEditor(colspan = 1, value = 150)
	@AsTextArea
	private String remark;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

//	public Long getInstitution() {
//		return institution;
//	}
//
//	public void setInstitution(Long institution) {
//		this.institution = institution;
//	}

	public String getCourseNames() {
		return courseNames;
	}

	public void setCourseNames(String courseNames) {
		this.courseNames = courseNames;
	}

	public String getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

	public Date getEntryAt() {
		return entryAt;
	}

	public void setEntryAt(Date entryAt) {
		this.entryAt = entryAt;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
}
