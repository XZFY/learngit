package cn.bonoon.controllers.student;

import cn.bonoon.core.IStudentInsert;
import cn.bonoon.entities.ClassesEntity;
import cn.bonoon.kernel.annotations.Transform;
import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.annotations.Unique;
import cn.bonoon.kernel.annotations.WriteModel;
import cn.bonoon.kernel.util.BoolType;
import cn.bonoon.kernel.web.annotations.AutoDataLoader;
import cn.bonoon.kernel.web.annotations.components.AsComboBox;
import cn.bonoon.kernel.web.annotations.components.AsPassword;
import cn.bonoon.kernel.web.annotations.form.FormInsert;
import cn.bonoon.kernel.web.annotations.form.PropertyInsert;

@Transform
@FormInsert(2)
public class StudentInserter extends StudentEditor implements IStudentInsert{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4346476780410712800L;

	@TransformField(readable = false, writable = WriteModel.NONE)
	@PropertyInsert(2)
	private String name;
	
	@TransformField(readable = false, writable = WriteModel.NONE)
	@PropertyInsert(required = BoolType.TRUE, value = 1)
	@Unique
	private String loginName;
	
	@TransformField(readable = false, writable = WriteModel.NONE)
	@PropertyInsert(value = 3, name = "密码", required = BoolType.TRUE)
	@AsPassword
	private String loginPwd;
	
	@TransformField(readable = false, writable = WriteModel.NONE)
	@PropertyInsert(value = 4, name = "确认密码", required = BoolType.TRUE)
	@AsPassword
	private String confimPwd;
	

	@TransformField(readable = false, writable = WriteModel.NONE)
	@PropertyInsert(5)
	private int points;
	

	@TransformField(readable = false, writable = WriteModel.NONE)
	@PropertyInsert(6)
	private String phone;

	@AsComboBox
	@AutoDataLoader(ClassesEntity.class)
	@TransformField(readable = false, writable = WriteModel.NONE)
	@PropertyInsert(6)
	private Long classes;

	@TransformField(readable = false, writable = WriteModel.NONE)
	@PropertyInsert(6)
	private int seatNumber;
//	private int studyStatus;
	
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getLoginPwd() {
		return loginPwd;
	}
	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}
	public String getConfimPwd() {
		return confimPwd;
	}
	public void setConfimPwd(String confimPwd) {
		this.confimPwd = confimPwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPoints() {
		return points;
	}
	public void setPoints(int points) {
		this.points = points;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}
	public Long getClasses() {
		return classes;
	}
	public void setClasses(Long classes) {
		this.classes = classes;
	}
}
