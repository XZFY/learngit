package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

/**
 * 表示某一用户对某一功能的可操作的情况，如：该功能是否已经开通等
 * @author jackson
 *
 */
@Entity
@Table(name = "T_MEMBERSETTING")
public class MemberSettingEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 320910885069537472L;

	//练习的功能是否已经开通
	@Column(name = "C_PRAXISOPENED")
	private boolean praxisOpened;
	//开通的时间
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_PRAXISAT")
	private Date praxisAt;
	//开通时花费的积分
	@Column(name = "C_PRAXISPOINTS")
	private int praxisPoints;

	@Column(name = "C_IMPROVEOPENED")
	private boolean improveOpened;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_IMPROVEAT")
	private Date improveAt;
	@Column(name = "C_IMPROVEPOINTS")
	private int improvePoints;

	@Column(name = "C_ASSISTANTOPENED")
	private boolean assistantOpened;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_ASSISTANTAT")
	private Date assistantAt;
	@Column(name = "C_ASSISTANTPOINTS")
	private int assistantPoints;
	
	@Column(name = "C_EXAMOPENED")
	private boolean examOpened;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_EXAMAT")
	private Date examAt;

	@Column(name = "C_EXAMPOINTS")
	private int examPoints;
	
	@Column(name = "C_CLASSOPENED")
	private boolean classOpened;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CLASSAT")
	private Date classAt;

	@Column(name = "C_CLASSPOINTS")
	private int classPoints;

	@Column(name = "C_RESOURCEOPENED")
	private boolean resourceOpened;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_RESOURCEAT")
	private Date resourceAt;

	@Column(name = "C_RESOURCEPOINTS")
	private int resourcePoints;
	
	@OneToOne
	@JoinColumn(name = "R_MEMBER_ID")
	private MemberEntity member;
	
	//是否填写了培训机构
	@Column(name = "C_HASINSTITUTION")
	private boolean hasInstitution;

	@Column(name = "C_HASPHONE")
	private boolean hasPhone;

	@Column(name = "C_HASCOMPANY")
	private boolean hasCompany;

	@Column(name = "C_HASEMAIL")
	private boolean hasEmail;

	@Column(name = "C_HASPLACE")
	private boolean hasPlace;

	@Column(name = "C_HASINTRODUCTION")
	private boolean hasIntroduction;

	public boolean isPraxisOpened() {
		return praxisOpened;
	}

	public void setPraxisOpened(boolean praxisOpened) {
		this.praxisOpened = praxisOpened;
	}

	public Date getPraxisAt() {
		return praxisAt;
	}

	public void setPraxisAt(Date praxisAt) {
		this.praxisAt = praxisAt;
	}

	public int getPraxisPoints() {
		return praxisPoints;
	}

	public void setPraxisPoints(int praxisPoints) {
		this.praxisPoints = praxisPoints;
	}

	public boolean isExamOpened() {
		return examOpened;
	}

	public void setExamOpened(boolean examOpened) {
		this.examOpened = examOpened;
	}

	public Date getExamAt() {
		return examAt;
	}

	public void setExamAt(Date examAt) {
		this.examAt = examAt;
	}

	public int getExamPoints() {
		return examPoints;
	}

	public void setExamPoints(int examPoints) {
		this.examPoints = examPoints;
	}

	public MemberEntity getMember() {
		return member;
	}

	public void setMember(MemberEntity member) {
		this.member = member;
	}

	public boolean isClassOpened() {
		return classOpened;
	}

	public void setClassOpened(boolean classOpened) {
		this.classOpened = classOpened;
	}

	public Date getClassAt() {
		return classAt;
	}

	public void setClassAt(Date classAt) {
		this.classAt = classAt;
	}

	public int getClassPoints() {
		return classPoints;
	}

	public void setClassPoints(int classPoints) {
		this.classPoints = classPoints;
	}

	public boolean isResourceOpened() {
		return resourceOpened;
	}

	public void setResourceOpened(boolean resourceOpened) {
		this.resourceOpened = resourceOpened;
	}

	public Date getResourceAt() {
		return resourceAt;
	}

	public void setResourceAt(Date resourceAt) {
		this.resourceAt = resourceAt;
	}

	public int getResourcePoints() {
		return resourcePoints;
	}

	public void setResourcePoints(int resourcePoints) {
		this.resourcePoints = resourcePoints;
	}

	public boolean isImproveOpened() {
		return improveOpened;
	}

	public void setImproveOpened(boolean improveOpened) {
		this.improveOpened = improveOpened;
	}

	public Date getImproveAt() {
		return improveAt;
	}

	public void setImproveAt(Date improveAt) {
		this.improveAt = improveAt;
	}

	public int getImprovePoints() {
		return improvePoints;
	}

	public void setImprovePoints(int improvePoints) {
		this.improvePoints = improvePoints;
	}

	public boolean isAssistantOpened() {
		return assistantOpened;
	}

	public void setAssistantOpened(boolean assistantOpened) {
		this.assistantOpened = assistantOpened;
	}

	public Date getAssistantAt() {
		return assistantAt;
	}

	public void setAssistantAt(Date assistantAt) {
		this.assistantAt = assistantAt;
	}

	public int getAssistantPoints() {
		return assistantPoints;
	}

	public void setAssistantPoints(int assistantPoints) {
		this.assistantPoints = assistantPoints;
	}

	public boolean isHasInstitution() {
		return hasInstitution;
	}

	public void setHasInstitution(boolean hasInstitution) {
		this.hasInstitution = hasInstitution;
	}

	public boolean isHasPhone() {
		return hasPhone;
	}

	public void setHasPhone(boolean hasPhone) {
		this.hasPhone = hasPhone;
	}

	public boolean isHasCompany() {
		return hasCompany;
	}

	public void setHasCompany(boolean hasCompany) {
		this.hasCompany = hasCompany;
	}

	public boolean isHasEmail() {
		return hasEmail;
	}

	public void setHasEmail(boolean hasEmail) {
		this.hasEmail = hasEmail;
	}

	public boolean isHasPlace() {
		return hasPlace;
	}

	public void setHasPlace(boolean hasPlace) {
		this.hasPlace = hasPlace;
	}

	public boolean isHasIntroduction() {
		return hasIntroduction;
	}

	public void setHasIntroduction(boolean hasIntroduction) {
		this.hasIntroduction = hasIntroduction;
	}
	
}
