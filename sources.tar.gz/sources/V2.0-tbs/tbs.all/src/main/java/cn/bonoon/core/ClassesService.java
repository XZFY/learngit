package cn.bonoon.core;

import java.util.List;

import cn.bonoon.core.infos.InstitutionClassesInfo;
import cn.bonoon.entities.ClassesEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.StudyingEntity;
import cn.bonoon.entities.TrainingInstitutionEntity;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.services.GenericService;

public interface ClassesService extends GenericService<ClassesEntity>{

	List<ClassesEntity> myClasses(MemberEntity member);

	InstitutionClassesInfo institutionClasses(MemberEntity member);

	String applyInstitution(IOperator user, Long id);

	String abandonInstitution(IOperator user, Long id);

	void joinClasses(MemberEntity member, Long id);

	List<StudyingEntity> classmate(ClassesEntity classes);

	TrainingInstitutionEntity institution(ClassesEntity classes);

}
