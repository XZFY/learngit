package cn.bonoon.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.MappingId;
import cn.bonoon.Util;
import cn.bonoon.core.PagerService;
import cn.bonoon.core.PracticeService;
import cn.bonoon.core.configs.CountConfig;
import cn.bonoon.core.configs.HelperMessageConfig;
import cn.bonoon.core.configs.PointsConfig;
import cn.bonoon.core.infos.AbstractRecord;
import cn.bonoon.core.infos.ExplanationInfo;
import cn.bonoon.core.infos.PraxisInfo;
import cn.bonoon.core.infos.RealInfo;
import cn.bonoon.core.infos.RecordItem;
import cn.bonoon.core.infos.RedeemInfo;
import cn.bonoon.core.infos.ResultInfo;
import cn.bonoon.core.infos.TopicInfo;
import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.entities.AnswerStatisticsItem;
import cn.bonoon.entities.AnswerStatisticsType;
import cn.bonoon.entities.AnswerType;
import cn.bonoon.entities.BaseEntity;
import cn.bonoon.entities.CurrencyType;
import cn.bonoon.entities.HelperMessageEntity;
import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.entities.KnowledgePointEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.MemberPagerEntity;
import cn.bonoon.entities.PagerEntity;
import cn.bonoon.entities.PagerType;
import cn.bonoon.entities.ProcessEntity;
import cn.bonoon.entities.ProcessGroupEntity;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.entities.TransactionEntity;
import cn.bonoon.entities.TransactionType;
import cn.bonoon.entities.WrongAnswerEntity;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.models.Page;
import cn.bonoon.kernel.support.services.ServiceSupport;
import cn.bonoon.kernel.util.StringHelper;
import cn.bonoon.kernel.web.ConfigManager;

@Service
@Transactional(readOnly = true)
public class PracticeServiceImpl extends ServiceSupport implements PracticeService{
	
	private ConfigManager configManager;
	@Override
	public void afterPropertiesSet() throws Exception {
		super.afterPropertiesSet();
		configManager = ConfigManager.getManager();
	}
	
	private void __saveAnswer(AnswerEntity ae, List<String> items){
		if(items.isEmpty()){
			throw new RuntimeException("没有练习的题目！");
		}
		ae.setStatus(ANSWER_STATUS_DOING);
		ae.setResetAt(ae.getCreateAt());
		StringBuilder content = new StringBuilder();
		for(String it : items){
			content.append(";?0").append(it);
		}
		ae.setContent(content.substring(1));
		ae.setTotal(items.size());
		entityManager.persist(ae);
	}
	
	private HelperMessageConfig __message(){
		HelperMessageConfig hmc = new HelperMessageConfig();
		try{
			configManager.read(applicationContext, entityManager, hmc);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return hmc;
	}
	
	private CountConfig __count(){
		CountConfig cc = new CountConfig();
		try{
			configManager.read(applicationContext, entityManager, cc);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return cc;
	}
	
	private PointsConfig __points(){
		PointsConfig pc = new PointsConfig();
		try{
			configManager.read(applicationContext, entityManager, pc);
		}catch(Exception ex){
			//nothing to do
			ex.printStackTrace();
		}
		return pc;
	}
	
	@Override
	public List<String> freeFastRandom(Long chapterId) {
		String ql = "select x.key from TopicEntity x where x.freeFast=true and x.deleted=false and x.area.id=? and x.key is not null";
		int topCount = __count().getFreeFastCount();
		if(topCount < 1){
			topCount = 10;
		}
		return __random(ql, chapterId, topCount);
	}
	
	@Override
	public List<String> trialPraxis(Long selectedId) {
		String ql = "select x.key from TopicEntity x where x.praxis=true and x.deleted=false and x.area.id=? and x.key is not null order by x.key desc";
		TypedQuery<String> qt = __query(String.class, ql, selectedId);
		qt.setMaxResults(10);
		return qt.getResultList();
	}
	
	@Override
	public List<String> trialArea(Long selectedId) {
		String ql = "select x.key from TopicEntity x where x.improve=true and x.deleted=false and x.area.id=? and x.key is not null order by x.key desc";
		TypedQuery<String> qt = __query(String.class, ql, selectedId);
		qt.setMaxResults(10);
		return qt.getResultList();
	}
	
	@Override
	public List<String> trialGroup(Long selectedId) {
		String ql = "select x.key from TopicEntity x where x.improve=true and x.deleted=false and x.group.id=? and x.key is not null order by x.key desc";
		TypedQuery<String> qt = __query(String.class, ql, selectedId);
		qt.setMaxResults(10);
		return qt.getResultList();
	}
	
	@Override
	public List<String> trialProcess(Long selectedId) {
		String ql = "select x.key from TopicEntity x where x.improve=true and x.deleted=false and x.process.id=? and x.key is not null order by x.key desc";
		TypedQuery<String> qt = __query(String.class, ql, selectedId);
		qt.setMaxResults(10);
		return qt.getResultList();
	}
	
	@Override
	public PraxisInfo improveArea(IOperator user, Long id) {
		Long uid = user.getId();
		KnowledgeAreaEntity kae = __knowledge(id);
		PraxisInfo pi = new PraxisInfo();
		List<AnswerEntity> answers = __list(AnswerEntity.class, aeql_3, uid, AnswerType.AREA, kae.getId());
		__parseAnswer(pi, answers);
		return pi;
	}
	
	@Override
	public PraxisInfo improveGroup(IOperator user, Long id) {
		Long uid = user.getId();
		KnowledgeAreaEntity kae = __knowledge(id);
		PraxisInfo pi = new PraxisInfo();
		List<AnswerEntity> answers = __list(AnswerEntity.class, aeql_3, uid, AnswerType.GROUP, kae.getId());
		__parseAnswer(pi, answers);
		return pi;
	}
	
	@Override
	public PraxisInfo improveProcess(IOperator user, Long id) {
		Long uid = user.getId();
		KnowledgeAreaEntity kae = __knowledge(id);
		PraxisInfo pi = new PraxisInfo();
		List<AnswerEntity> answers = __list(AnswerEntity.class, aeql_3, uid, AnswerType.PROCESS, kae.getId());
		__parseAnswer(pi, answers);
		return pi;
	}
	
	@Override
	public PagerEntity trialPager() {
		return _pager(PagerType.EXAMINATION);
	}
	
	@Override
	public PagerEntity trialReal() {
		return _pager(PagerType.REAL);
	}
	
	@Override
	public List<String> trialPagerTopics(PagerEntity pe) {
		String ql = "select x.topic.key from PagerTopicEntity x where x.pager.id=? order by x.ordinal asc";
		return __list(String.class, ql, pe.getId());
	}
	
	private PagerEntity _pager(PagerType type){
		String ql = "select x from PagerEntity x where x.status=? and x.type=? and x.trial=true and x.deleted=false order by x.id asc";
		return __first(__query(PagerEntity.class, ql, PagerService.NORMAL, type));
	}
	
	@Override
	public List<String> freeCombatRandom() {
		int topCount = __count().getFreeCombatCount();
		if(topCount < 1){
			topCount = 200;
		}
		String ql = "select x.key from TopicEntity x where x.freeCombat=true and x.deleted=false and x.key is not null";
		return RandomHelper.random(__list(String.class, ql), topCount);
	}
	
	private List<String> __random(String ql, Long chapterId, int topCount){
		return RandomHelper.random(__list(String.class, ql, chapterId), topCount);
	}

	
	@Override
	public TopicInfo topic(String key, Boolean isen) {
		return new TopicInfo(__topic(key), isen);
	}
	
	@Override
	public TopicInfo topic(Long id, Boolean isen) {
		return new TopicInfo(entityManager.find(TopicEntity.class, id), isen);
	}
	
	@Override
	public ExplanationInfo explanation(String key, Boolean isen) {
		return new ExplanationInfo(__topic(key), isen);
	}
	
	private TopicEntity __topic(String key) {
		return __first(TopicEntity.class, "select x from TopicEntity x where x.key=?", key);
	}

	@Override
	@Transactional
	public AnswerEntity refresh(Long id) {
		AnswerEntity ea = entityManager.find(AnswerEntity.class, id);
		__refreshDate(ea, new Date());
		entityManager.merge(ea);
		return ea;
	}
	
	@Override
	@Transactional
	public void giveup(Long id) {
		__exec("update AnswerEntity set status=" + ANSWER_STATUS_GIVEUP + " where id=" + id);
		entityManager.flush();
	}
	
	@Override
	@Transactional
	public AnswerEntity refresh(Long id, String fromKey, String answer, Boolean imptMark) {
		AnswerEntity ea = entityManager.find(AnswerEntity.class, id);
		if(StringHelper.isNotEmpty(fromKey)){
			ea.setContent(__answer(ea.getContent(), fromKey, answer, imptMark));
		}
		__refreshDate(ea, new Date());
		entityManager.merge(ea);
		return ea;
	}
	
	private void __pagerStatistics(MemberPagerEntity mpe, PagerEntity pager, int right){
		double score = right * 100d / pager.getCount();
		
		long uc = mpe.getUsedCount() + 1;
		double maxs = mpe.getMaxScore();
		double mins = mpe.getMinScore();
		double totals = mpe.getTotalScore();
		totals += score;
		if(score > maxs){
			maxs = score;
		}
		if(mins == 0 || score < mins){
			mins = score;
		}
		mpe.setUsedCount(uc);
		mpe.setAvgScore(totals / uc);
		mpe.setMaxScore(maxs);
		mpe.setMinScore(mins);
		mpe.setTotalScore(totals);
		
		uc = pager.getUsedCount() + 1;
		maxs = pager.getMaxScore();
		mins = pager.getMinScore();
		totals = pager.getTotalScore();
		totals += score;
		if(score > maxs){
			maxs = score;
		}
		if(mins == 0 || score < mins){
			mins = score;
		}
		pager.setUsedCount(uc);
		pager.setAvgScore(totals / uc);
		pager.setMaxScore(maxs);
		pager.setMinScore(mins);
		pager.setTotalScore(totals);
		entityManager.merge(mpe);
		entityManager.merge(pager);
	}
	
	@Override
	@Transactional
	synchronized//这里会涉及一些数据的统计，所以必须使用同步限制，目前只是简单的对线程进行同步处理，没有考虑到集群等比较复杂的运行环境
	public ResultInfo finish(Long memId, Long id, String fromKey, String answer, Boolean imptMark) {
		/*
		 * TODO 所有完成的练习都会进入这个方法里进行处理
		 * 1.对会员完成的答案进行分析
		 * 2.把错的题目单独保存起来
		 * 3.按过程归类
		 * 4.按过程域归类
		 * 5.按知识归类
		 * 6.按知识点归类
		 * 7.计算积分
		 */
		MemberEntity member = entityManager.find(MemberEntity.class, memId);
		
		AnswerEntity ea = entityManager.find(AnswerEntity.class, id);
		String content = ea.getContent();
		if(StringHelper.isNotEmpty(fromKey)){
			ea.setContent(__answer(content, fromKey, answer, imptMark));
		}
		Date now = new Date();
		ea.setFinishAt(now);
		long ts = now.getTime() - ea.getResetAt().getTime() + ea.getTimeSpent();
		ea.setCurrentTimeSpent(0);
		ea.setTimeSpent(ts);
		ea.setRefreshAt(now);
		ea.setStatus(ANSWER_STATUS_FINISH);
		String[] answers = content.split(";");
		ResultInfo result = new ResultInfo();
		result.setTimeSpent(Util.timeSpent(ts));
		int points;
		boolean percent;
		PointsConfig pc = __points();
		AnswerType at = ea.getType();
		AnswerStatisticsInfo asi = new AnswerStatisticsInfo(member, ea, now);
		if(at == AnswerType.REAL || at == AnswerType.PAGER){
			points = pc.getRealPoints();
			percent = pc.isRealPercent();
			MemberPagerEntity mpe = entityManager.find(MemberPagerEntity.class, ea.getFromId());
			PagerEntity pager = mpe.getPager();
			__parse(asi, answers, pager.getId(), result);
			//进行一些统计工作
			__pagerStatistics(mpe, pager, result.getRight());
		}else{
			points = pc.getPraxisPoints();
			percent = pc.isPraxisPercent();
			for(String awr : answers){
				TopicEntity topic = __topic(awr.substring(2));
				if(null == topic){
					continue;
				}
				asi.parse(result, topic, awr);
			}
		}
		ea.setGiveupCount(result.getGiveUp());
		ea.setRightCount(result.getRight());
		ea.setWrongCount(result.getWrong());
		entityManager.merge(ea);
		
		//对做对的题目按比例进行计算积分
		int total = ea.getTotal(), right = ea.getRightCount();
		if(points > 0){
			if(percent){
				points = right * points / total;
			}
			
			if(points > 0){
				TransactionEntity tpe = new TransactionEntity();
				tpe.setCreateAt(now);
				tpe.setDeduct(false);
				tpe.setCurrencyType(CurrencyType.POINTS);
				tpe.setTransactionType(TransactionType.INCREASE);
				tpe.setRemark("做题[" + at.getDisplay() + "]奖励积分");
				tpe.setUserId(member.getId());
				
				tpe.setAmount(points);
				member.setAvailablePoints(member.getAvailablePoints() + points);
				member.setTotalPoints(member.getTotalPoints() + points);
				member.setLevelPoints(member.getLevelPoints() + points);
				tpe.setAvailable(member.getAvailablePoints());
				tpe.setTotal(member.getTotalPoints());
				tpe.setLevelPoints(points);
				
				entityManager.persist(tpe);
			}
		}
		asi.end();
		//成绩
		int score = right * 100 / total;
		if(score > member.getLastScore()){
			//有进步
			HelperMessageConfig hmc = __message();
			int tg = score - member.getLastScore();
			String mc = hmc.getMessage_8();
			if(StringHelper.isNotEmpty(mc)){
				mc.replace("{用户名}", member.getName());
				mc.replace("{分数}", String.valueOf(tg));
				HelperMessageEntity hm1 = new HelperMessageEntity();
				hm1.setContent(mc);
				hm1.setCreateAt(now);
				hm1.setMember(member);
				entityManager.persist(hm1);
			}
		}
		//最后的成绩
		member.setLastScore(score);
		entityManager.merge(member);
		return result.sort();
	}
	
	private void __parse(AnswerStatisticsInfo asi, String[] answers, Long id, ResultInfo result){
		String teql = "select x.topic from PagerTopicEntity x where x.pager.id=? order by x.ordinal asc";
		List<TopicEntity> topics = __list(TopicEntity.class, teql, id);
		for(String awr : answers){
			TopicEntity topic = null;
			for(TopicEntity tte : topics){
				if(null != tte.getKey() && awr.endsWith(tte.getKey())){
					topic = tte;
					break;
				}
			}
			if(null != topic){
				topics.remove(topic);
			}else{
				//从数据库加载
				topic = __topic(awr.substring(2));
				if(null == topic){
					continue;
				}
			}
			asi.parse(result, topic, awr);
		}
	}
	
	private class AnswerStatisticsInfo{
		final AnswerEntity answer;
		final MemberEntity member;
		final Date now;
		
		AnswerStatisticsInfo(MemberEntity member, AnswerEntity answer, Date now){
			this.member = member;
			this.answer = answer;
			this.now = now;
		}
		
		Map<Long, AnswerStatisticsItem> groups = new HashMap<>();
		Map<Long, AnswerStatisticsItem> areas = new HashMap<>();
		Map<Long, AnswerStatisticsItem> knowledges = new HashMap<>();
		Map<Long, AnswerStatisticsItem> processes = new HashMap<>();
		
		void end(){
			for(AnswerStatisticsItem asi : groups.values()){
				asi.setScore(((double)asi.getRight()) / asi.getTotal() * 100);
				entityManager.persist(asi);
			}
			for(AnswerStatisticsItem asi : areas.values()){
				asi.setScore(((double)asi.getRight()) / asi.getTotal() * 100);
				entityManager.persist(asi);
			}
			for(AnswerStatisticsItem asi : knowledges.values()){
				asi.setScore(((double)asi.getRight()) / asi.getTotal() * 100);
				entityManager.persist(asi);
			}
			for(AnswerStatisticsItem asi : processes.values()){
				asi.setScore(((double)asi.getRight()) / asi.getTotal() * 100);
				entityManager.persist(asi);
			}
		}
		
		void parse(ResultInfo result, TopicEntity topic, String awr){
			topic.setTotalCount(topic.getTotalCount() + 1);
			if(result.parse(topic, awr)){
				topic.setRightCount(topic.getRightCount() + 1);
				group(topic, 1);
				area(topic, 1);
				knowledge(topic, 1);
				process(topic, 1);
			}else{
				group(topic, 0);
				area(topic, 0);
				knowledge(topic, 0);
				process(topic, 0);
				//该题目做错了，添加到我的错题集里
				WrongAnswerEntity wae = new WrongAnswerEntity();
				wae.setCreateAt(now);
				wae.setKey(member.getKey());
				wae.setTopic(topic);
				wae.setPracticeAt(answer.getCreateAt());
				wae.setRemark(answer.getName());
				entityManager.persist(wae);
			}
			entityManager.merge(topic);
			
		}
			
		//统计
		void process(TopicEntity topic, int i){
			ProcessEntity pe = topic.getProcess();
			if(null != pe){
				AnswerStatisticsItem asi = processes.get(pe.getId());
				if(null == asi){
					asi = new AnswerStatisticsItem();
					asi.setOrdinal(pe.getOrdinal());
					asi.setAnswer(answer);
					asi.setCreateAt(now);
					asi.setCreatorId(member.getId());
					asi.setName(pe.getName());
					asi.setTid(pe.getId());
					asi.setType(AnswerStatisticsType.PROCESS);
					asi.setTotal(1);
					processes.put(pe.getId(), asi);
				}else{
					asi.setTotal(asi.getTotal() + 1);
				}
				asi.setRight(asi.getRight() + i);
			}
		}
		
		void knowledge(TopicEntity topic, int i){
			KnowledgePointEntity ke = topic.getKnowledge();
			if(null != ke){
				AnswerStatisticsItem asi = knowledges.get(ke.getId());
				if(null == asi){
					asi = new AnswerStatisticsItem();
					asi.setOrdinal(ke.getOrdinal());
					asi.setAnswer(answer);
					asi.setCreateAt(now);
					asi.setCreatorId(member.getId());
					asi.setName(ke.getName());
					asi.setTid(ke.getId());
					asi.setType(AnswerStatisticsType.KNOWLEDGE);
					asi.setTotal(1);
					knowledges.put(ke.getId(), asi);
				}else{
					asi.setTotal(asi.getTotal() + 1);
				}
				asi.setRight(asi.getRight() + i);
			}
		}
		
		void area(TopicEntity topic, int i){
			KnowledgeAreaEntity ae = topic.getArea();
			if(null != ae){
				AnswerStatisticsItem asi = areas.get(ae.getId());
				if(null == asi){
					asi = new AnswerStatisticsItem();
					asi.setOrdinal(ae.getOrdinal());
					asi.setAnswer(answer);
					asi.setCreateAt(now);
					asi.setCreatorId(member.getId());
					asi.setName(ae.getName());
					asi.setTid(ae.getId());
					asi.setType(AnswerStatisticsType.AREA);
					asi.setTotal(1);
					areas.put(ae.getId(), asi);
				}else{
					asi.setTotal(asi.getTotal() + 1);
				}
				asi.setRight(asi.getRight() + i);
			}
		}
		void group(TopicEntity topic, int i){
			ProcessGroupEntity ge = topic.getGroup();
			if(null != ge){
				AnswerStatisticsItem asi = groups.get(ge.getId());
				if(null == asi){
					asi = new AnswerStatisticsItem();
					asi.setOrdinal(ge.getOrdinal());
					asi.setAnswer(answer);
					asi.setCreateAt(now);
					asi.setCreatorId(member.getId());
					asi.setName(ge.getName());
					asi.setTid(ge.getId());
					asi.setType(AnswerStatisticsType.GROUP);
					asi.setTotal(1);
					groups.put(ge.getId(), asi);
				}else{
					asi.setTotal(asi.getTotal() + 1);
				}
				asi.setRight(asi.getRight() + i);
			}
		}
	}
	
	private void __refreshDate(AnswerEntity ea, Date now){
		ea.setRefreshAt(now);
		ea.setCurrentTimeSpent(now.getTime() - ea.getResetAt().getTime());
	}
	
	private String __answer(String content, String fromKey, String answer, Boolean imptMark){
		char[] cs = content.toCharArray();
		int point = content.indexOf(fromKey);
		if(null != answer && answer.length() == 1){
			cs[point - 2] = answer.charAt(0);
		}else{
			cs[point - 2] = '-';
		}
		if(null != imptMark && imptMark){
			cs[point - 1] = '1';
		}else{
			cs[point - 1] = '0';
		}
		return new String(cs);
	}
	
	private final static String[] pagerStatusName = { "草稿","正常","下架" };
	
	private final static String[] answerStatusName = { "未完成","完成","放弃" };
	
	private final static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

	private final String aeql_0 = "select x from AnswerEntity x where x.creatorId=? and x.type=?";
	/**
	 * 需要3个参数，顺序为：creatorId,fromId,type
	 */
	private final String aeql_3 = aeql_0 + " and x.fromId=? order by x.id desc";
	/**
	 * 需要4个参数，顺序为：creatorId,fromId,type,id
	 */
	private final String aeql_4 = aeql_0 + " and x.fromId=? and x.id=? order by x.id desc";
	
	@Override
	public PraxisInfo myPraxis(IOperator user, Long chapterId) {
		Long uid = user.getId();
		KnowledgeAreaEntity kae = __knowledge(chapterId);
		PraxisInfo pi = new PraxisInfo();
		List<AnswerEntity> answers = __list(AnswerEntity.class, aeql_3, uid, AnswerType.PRAXIS, kae.getId());
		__parseAnswer(pi, answers);
		return pi;
	}
	
	private void __parseAnswer(AbstractRecord mrpi, List<AnswerEntity> answers){
		boolean canNew = true;
		if(!answers.isEmpty()){
			List<RecordItem> records = new ArrayList<RecordItem>();
			for(AnswerEntity ae : answers){
				RecordItem pri = new RecordItem();
				pri.setId(ae.getId());
				pri.setStart(sdf.format(ae.getCreateAt()));
				pri.setRightCount(ae.getRightCount());
				pri.setTotal(ae.getTotal());
				pri.setSpentTime(ae.getTimeSpent() + ae.getCurrentTimeSpent());
				pri.setStatus(answerStatusName[ae.getStatus()]);
				if(ae.getStatus() == ANSWER_STATUS_DOING){
					pri.setUnfinished(true);
					canNew = false;
				}
				records.add(pri);
			}
			mrpi.setRecords(records);
		}
		mrpi.setCanNew(canNew);
	}
	
	private AnswerEntity __refreshAnswer(AnswerEntity ae){
		ae.setResetAt(new Date());
		long t = ae.getTimeSpent(), c = ae.getCurrentTimeSpent();
		ae.setCurrentTimeSpent(0L);
		ae.setTimeSpent(t + c);
		//重新计时
		entityManager.merge(ae);
		return ae;
	}
	
	@Override
	@Transactional
	public AnswerEntity startReal(IOperator user, Long rid, Long aid) {
		AnswerEntity ae = __findAnswer(user, __memberPager(user, rid).getId(), aid, AnswerType.REAL);
		return __refreshAnswer(ae);
	}
	
	@Override
	public AnswerEntity startPager(IOperator user, Long pid, Long aid) {
		AnswerEntity ae = __findAnswer(user, __memberPager(user, pid).getId(), aid, AnswerType.PAGER);
		return __refreshAnswer(ae);
	}
	
	@Override
	@Transactional
	public AnswerEntity startReal(IOperator user, Long rid) {//TODO real的处理
		return __createAnswer(__memberPager(user, rid), AnswerType.REAL);
	}
	
	@Override
	@Transactional
	public AnswerEntity startPager(IOperator user, Long pid) {
		return __createAnswer(__memberPager(user, pid), AnswerType.PAGER);
	}
	
	private void __giveupAnswer(AnswerEntity old){
		old.setStatus(ANSWER_STATUS_GIVEUP);
		entityManager.merge(old);
	}
	
	private AnswerEntity __findAnswer(IOperator user, Long tid, Long id, AnswerType at){
		return __first(AnswerEntity.class, aeql_4, user.getId(), at, tid, id);
	}
	
	private MemberPagerEntity __memberPager(IOperator user, Long pid){
		String mpql = "select x from MemberPagerEntity x where x.member.id=? and x.id=? and x.pager.deleted=false";
		MemberPagerEntity mpe = __first(MemberPagerEntity.class, mpql, user.getId(), pid);
		if(null == mpe){
			throw new RuntimeException("无法进行该试卷/真题的测试！");
		}
		return mpe;
	}

	@Override
	public Page myPagers(IOperator user, int pageIndex, int pageSize, String name, String type) {
		return __pager(user, pageIndex, pageSize, name, type, PagerType.EXAMINATION, AnswerType.PAGER);
	}
	
	private Page __pager(MemberEntity member, int pageIndex, int pageSize, String name, String type, PagerType pt, AnswerType at){
		Long uid = member.getId();
		
		int skip = pageIndex * pageSize, lenght = pageSize;
		
		
		if(pageSize <= 0){
			skip = 0;
			lenght = Integer.MAX_VALUE;
		}
		
		List<Object> items = new ArrayList<>();
		int count;
		
		//TODO 需要修改的地方
		if("0".equals(type)){
			//只查看已经兑换的试卷
			String mpql = "select x from MemberPagerEntity x where x.member.id=? and x.pager.type=? and x.pager.deleted=false";
			String coql = "select count(x) from MemberPagerEntity x where x.member.id=? and x.pager.type=? and x.pager.deleted=false";
			List<MemberPagerEntity> myPagers;
			if(StringHelper.isNotEmpty(name)){
				name = "%" + name + "%";
				
				mpql += " and x.name like ?";
				coql += " and x.name like ?";
				
				myPagers = __query(MemberPagerEntity.class, mpql, uid, pt, name).setFirstResult(skip).setMaxResults(lenght).getResultList();
				count = __first(Number.class, coql, uid, pt, name).intValue();

			}else{
				myPagers = __query(MemberPagerEntity.class, mpql, uid, pt).setFirstResult(skip).setMaxResults(lenght).getResultList();
				count = __first(Number.class, coql, uid, pt).intValue();
			}

			for(MemberPagerEntity mpe : myPagers){//已经购买的
				PagerEntity epe = mpe.getPager();
				RealInfo mrpi = new RealInfo();
				mrpi.setId(mpe.getId());
				mrpi.setName(epe.getName());
				mrpi.setCount(epe.getCount());
				mrpi.setStatus(pagerStatusName[epe.getStatus()]);
				
				mrpi.setPurchased(true);
				List<AnswerEntity> answers = __list(AnswerEntity.class, aeql_3, uid, at, mpe.getId());
				__parseAnswer(mrpi, answers);
				items.add(mrpi);
			}
		}else if("1".equals(type)){
			//只查看未兑换的试卷
			String epql = "select x from PagerEntity x,MemberPagerEntity y where x.deleted=false and x.id<>y.pager.id and y.member.id=? and x.status=? and x.type=?";
			String coql = "select count(x) from PagerEntity x ,MemberPagerEntity y where x.deleted=false and x.id<>y.pager.id and y.member.id=? and  x.status=? and x.type=?";
			List<PagerEntity> pagers;
			if(StringHelper.isNotEmpty(name)){
				name = "%" + name + "%";
				
				epql += " and x.name like ?";
				coql += " and x.name like ?";
				
				pagers = __query(PagerEntity.class, epql, uid, PagerEntity.NORMAL, pt, name).setFirstResult(skip).setMaxResults(lenght).getResultList();;
				count = __first(Number.class, coql, uid, PagerEntity.NORMAL, pt, name).intValue();
			}else{
				pagers = __query(PagerEntity.class, epql, uid, PagerEntity.NORMAL, pt).setFirstResult(skip).setMaxResults(lenght).getResultList();;
				count = __first(Number.class, coql, uid, PagerEntity.NORMAL, pt).intValue();
			}
			
			for(PagerEntity epe : pagers){//未购买的
				RealInfo mrpi = new RealInfo();
				mrpi.setId(epe.getId());
				mrpi.setName(epe.getName());
				mrpi.setCount(epe.getCount());
				mrpi.setStatus(pagerStatusName[epe.getStatus()]);
				
				mrpi.setPurchased(false);
				
				mrpi.setAmount(epe.getAmount());
				mrpi.setDiamond(epe.isDiamond());
				items.add(mrpi);
			}
		}else{ 
			//两者都看
			String epql = "select x from PagerEntity x where x.deleted=false and x.status=? and x.type=?";
			String coql = "select count(x) from PagerEntity x where x.deleted=false and x.status=? and x.type=?";
			List<PagerEntity> pagers;
			
			if(StringHelper.isNotEmpty(name)){
				name = "%" + name + "%";
				
				epql += " and x.name like ?";
				coql += " and x.name like ?";
				
				pagers = __query(PagerEntity.class, epql, PagerEntity.NORMAL, pt, name).setFirstResult(skip).setMaxResults(lenght).getResultList();;
				count = __first(Number.class, coql, PagerEntity.NORMAL, pt, name).intValue();
			}else{
				pagers = __query(PagerEntity.class, epql, PagerEntity.NORMAL, pt).setFirstResult(skip).setMaxResults(lenght).getResultList();;
				count = __first(Number.class, coql, PagerEntity.NORMAL, pt).intValue();
			}
			String idql = "select new cn.bonoon.MappingId(x.pager.id, x.id) from MemberPagerEntity x where x.member.id=? and x.pager.status=? and x.pager.type=? and x.pager.deleted=false";		
			List<MappingId> hadIds = __list(MappingId.class, idql, uid, PagerEntity.NORMAL, pt);

			for(PagerEntity epe : pagers){//未购买的
				RealInfo mrpi = new RealInfo();
				mrpi.setName(epe.getName());
				mrpi.setCount(epe.getCount());
				mrpi.setStatus(pagerStatusName[epe.getStatus()]);
				Long pid = MappingId.find(hadIds, epe.getId());
				if(null == pid){
					mrpi.setId(epe.getId());
					mrpi.setPurchased(false);
					
					mrpi.setAmount(epe.getAmount());
					mrpi.setDiamond(epe.isDiamond());
				}else{
					mrpi.setId(pid);
					mrpi.setPurchased(true);
					
					List<AnswerEntity> answers = __list(AnswerEntity.class, aeql_3, uid, at, pid);
					__parseAnswer(mrpi, answers);
				}
				
				items.add(mrpi);
			}
		}
		return new Page(count, items);
	}
	
	private Page __pager(IOperator user, int pageIndex, int pageSize, String name, String type, PagerType pt, AnswerType at){
		MemberEntity member = entityManager.find(MemberEntity.class, user.getId());
		if(null == member){
			return Page.EMPTY;
		}
		return __pager(member, pageIndex, pageSize, name, type, pt, at);
	}
	@Override
	public Page myReals(IOperator user, int pageIndex, int pageSize, String name, String type) {
		return __pager(user, pageIndex, pageSize, name, type, PagerType.REAL, AnswerType.REAL);
	}
	
	private RedeemInfo __redeem(Long id, IOperator user, int pageSize, PagerType pt, AnswerType at){
		MemberEntity member = entityManager.find(MemberEntity.class, user.getId());
		PagerEntity epe = entityManager.find(PagerEntity.class, id);
		int needPoints = epe.getAmount();
		Date now = new Date();
		if(needPoints > 0){
			boolean diamond = epe.isDiamond();
			//所需要的积分或钻石
			long available;
			if(diamond){
				available = member.getAvailableCash();
			}else{
				available = member.getAvailablePoints();
			}
			if(needPoints > available){
				throw new RuntimeException("用户积分不够！");
			}else{
				//添加一条积分的扣分记录
				TransactionEntity dpe = new TransactionEntity();
				dpe.setCreateAt(now);
				dpe.setUserId(member.getId());
				dpe.setTransactionType(TransactionType.DEDUCT);
				dpe.setDeduct(true);
				dpe.setAmount(needPoints);
				if(diamond){
					member.setAvailableCash(available - needPoints);
					dpe.setCurrencyType(CurrencyType.DIAMOND);
					dpe.setAvailable(member.getAvailableCash());
					dpe.setTotal(member.getTotalCash());
					dpe.setRemark("钻石兑换真题");
				}else{
					member.setAvailablePoints(available - needPoints);
					dpe.setCurrencyType(CurrencyType.POINTS);
					dpe.setAvailable(member.getAvailablePoints());
					dpe.setTotal(member.getTotalPoints());
					dpe.setRemark("积分兑换真题");
				}
				
				entityManager.persist(dpe);
				
				entityManager.merge(member);
			}
		}
		MemberPagerEntity mpe = new MemberPagerEntity();
		mpe.setMember(member);
		mpe.setPager(epe);
		mpe.setCreateAt(now);
		mpe.setTimeless(true);
		entityManager.persist(mpe);

		RedeemInfo ri = new RedeemInfo();
		ri.setPage(__pager(member, 0, pageSize, null, null, pt, at));
		ri.setMember(member);
		return ri;
	}
	
	@Override
	@Transactional
	public RedeemInfo redeemPager(Long id, IOperator user, int pageSize) {
		return __redeem(id, user, pageSize, PagerType.EXAMINATION, AnswerType.PAGER);
	}
	
	@Override
	@Transactional
	public RedeemInfo redeemReal(Long id, IOperator user, int pageSize) {
		return __redeem(id, user, pageSize, PagerType.REAL, AnswerType.REAL);
	}
	
	private AnswerEntity __createAnswer(MemberPagerEntity mpe, AnswerType at){
		
		String ql = "select x.topic.key from PagerTopicEntity x where x.pager.id=? and x.topic.key is not null order by x.ordinal asc";
		List<String> items = __list(String.class, ql, mpe.getPager().getId());
		
		//创建一个答案对象
		Date now = new Date();
		AnswerEntity answer = new AnswerEntity();
		answer.setCreateAt(now);
		answer.setResetAt(now);
		answer.setRefreshAt(now);
		answer.setCreatorId(mpe.getMember().getId());
		answer.setFromId(mpe.getId());
		answer.setName(mpe.getPager().getName());
		answer.setType(at);

		__saveAnswer(answer, items);
		return answer;
	}
	
	@Override
	public List<TopicEntity> find(String[] keys) {
		StringBuilder str = new StringBuilder("select x from TopicEntity x where x.key");
		int len = keys.length;
		if(len > 1){
			str.append(" in ('").append(keys[0]).append('\'');
			for(int i = 1; i < len; i++){
				str.append(",'").append(keys[i]).append('\'');
			}
			str.append(')');
		}else if(len == 1){
			str.append("='").append(keys[0]).append('\'');
		}else{
			str.append("='NULL'");
		}
		return __list(TopicEntity.class, str.toString());
	}
	
	@Override
	@Transactional
	public AnswerEntity startPraxis(IOperator user, Long chapterId) {
		return __createPraxisAnswer(user, __knowledge(chapterId));
	}
	
	@Override
	@Transactional
	public AnswerEntity startImproveArea(IOperator user, Long tid) {
		return __createImproveAnswer(user, __knowledge(tid), AnswerType.AREA, "area");
	}
	
	@Override
	@Transactional
	public AnswerEntity startImproveGroup(IOperator user, Long tid) {
		return __createImproveAnswer(user, __group(tid), AnswerType.GROUP, "group");
	}
	
	@Override
	@Transactional
	public AnswerEntity startImproveProcess(IOperator user, Long tid) {
		return __createImproveAnswer(user, __process(tid), AnswerType.PROCESS, "process");
	}
	
	@Override
	@Transactional
	public AnswerEntity startPraxis(IOperator user, Long chapterId, Long id) {
		return __refreshAnswer(__findAnswer(user, chapterId, id, AnswerType.PRAXIS));
	}
	
	@Override
	@Transactional
	public AnswerEntity startImproveArea(IOperator user, Long tid, Long id) {
		return __refreshAnswer(__findAnswer(user, tid, id, AnswerType.AREA));
	}
	
	@Override
	@Transactional
	public AnswerEntity startImproveGroup(IOperator user, Long tid, Long id) {
		return __refreshAnswer(__findAnswer(user, tid, id, AnswerType.GROUP));
	}
	
	@Override
	@Transactional
	public AnswerEntity startImproveProcess(IOperator user, Long tid, Long id) {
		return __refreshAnswer(__findAnswer(user, tid, id, AnswerType.PROCESS));
	}
	
	@Override
	@Transactional
	public AnswerEntity restartPraxis(IOperator user, Long chapterId, Long id) {
		KnowledgeAreaEntity kae = __knowledge(chapterId);
		__giveupAnswer(__findAnswer(user, kae.getId(), id, AnswerType.PRAXIS));
		return __createPraxisAnswer(user, kae);
	}
	
	@Override
	@Transactional
	public AnswerEntity restartImproveArea(IOperator user, Long tid, Long id) {
		KnowledgeAreaEntity entity = __knowledge(tid);
		__giveupAnswer(__findAnswer(user, entity.getId(), id, AnswerType.AREA));
		return __createImproveAnswer(user, entity, AnswerType.AREA, "area");
	}
	
	@Override
	@Transactional
	public AnswerEntity restartImproveGroup(IOperator user, Long tid, Long id) {
		ProcessGroupEntity entity = __group(tid);
		__giveupAnswer(__findAnswer(user, entity.getId(), id, AnswerType.GROUP));
		return __createImproveAnswer(user, entity, AnswerType.GROUP, "group");
	}
	
	@Override
	@Transactional
	public AnswerEntity restartImproveProcess(IOperator user, Long tid, Long id) {
		ProcessEntity entity = __process(tid);
		__giveupAnswer(__findAnswer(user, entity.getId(), id, AnswerType.PROCESS));
		return __createImproveAnswer(user, entity, AnswerType.PROCESS, "process");
	}
	
	private KnowledgeAreaEntity __knowledge(Long chapterId){
		KnowledgeAreaEntity entity = entityManager.find(KnowledgeAreaEntity.class, chapterId);
		if(null == entity){
			throw new RuntimeException("数据出现异常！");
		}
		return entity;
	}
	
	private ProcessEntity __process(Long id){
		ProcessEntity entity = entityManager.find(ProcessEntity.class, id);
		if(null == entity){
			throw new RuntimeException("数据出现异常！");
		}
		return entity;
	}

	private ProcessGroupEntity __group(Long id){
		ProcessGroupEntity entity = entityManager.find(ProcessGroupEntity.class, id);
		if(null == entity){
			throw new RuntimeException("数据出现异常！");
		}
		return entity;
	}
	
	private AnswerEntity __createImproveAnswer(IOperator user, BaseEntity kae, AnswerType at, String name){
		String tql = " and x.improve=true and x." + name + ".id=?";
		CountConfig cc = __count();
		
		int topCount = cc.getImproveCount();
		tql += " and x.difficulty>=" + cc.getImproveStart();
		if(cc.getImproveEnd() > 0){
			tql += " and x.difficulty<" + cc.getImproveEnd();
		}
		return __answer(user, kae, cc, topCount, tql, "-[提高]", at);
	}
	
	private AnswerEntity __createPraxisAnswer(IOperator user, BaseEntity kae){
		String tql = " and x.praxis=true and x.area.id=?";
		
		CountConfig cc = __count();
		
		int topCount = cc.getPraxisCount();
		tql += " and x.difficulty>=" + cc.getPraxisStart();
		if(cc.getPraxisEnd() > 0){
			tql += " and x.difficulty<" + cc.getPraxisEnd();
		}
		return __answer(user, kae, cc, topCount, tql, "-[练习]", AnswerType.PRAXIS);
	}
	
	private AnswerEntity __answer(IOperator user, BaseEntity kae, CountConfig cc, int topCount, String where, String suffix, AnswerType at){

		MemberEntity me = entityManager.find(MemberEntity.class, user.getId());
		
		String tql = "select x.key from TopicEntity x where x.deleted=false and x.key is not null";
		if(topCount < 1){
			topCount = 10;
		}
		
		long total = me.getTotalPoints();
		if(total >= cc.getLevelThree()){
			tql += " and x.difficulty<=3";
		}else if(total >= cc.getLevelTwo()){
			tql += " and x.difficulty<=2";
		}else if(total >= cc.getLevelOne()){
			tql += " and x.difficulty<=1";
		}else{
			tql += " and x.difficulty=0";
		}
		List<String> items = __random(tql + where, kae.getId(), topCount);
		//TODO 需要修改的地方
		AnswerEntity ae = new AnswerEntity();
		ae.setCreateAt(new Date());
		ae.setCreatorId(me.getId());
		ae.setFromId(kae.getId());
		ae.setName(kae.getName() + suffix);
		ae.setType(at);
		__saveAnswer(ae, items);
		return ae;
	}
}
