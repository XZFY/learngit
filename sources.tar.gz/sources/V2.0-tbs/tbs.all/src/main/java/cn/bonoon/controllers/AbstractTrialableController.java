package cn.bonoon.controllers;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.bonoon.core.configs.HelperMessageConfig;
import cn.bonoon.core.configs.OpenedPointsConfig;
import cn.bonoon.entities.MemberSettingEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.kernel.events.BaseEvent;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.util.StringHelper;

public abstract class AbstractTrialableController extends AbstractConfigurableController{

	protected AbstractTrialableController(){
		init();
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		super.afterPropertiesSet();
	}
	/**
	 * <pre>
	 * 对一些参数进行设置
	 * </pre>
	 */
	protected void init(){ }
	
	protected Long getLong(HttpServletRequest request, String name){
		String value = request.getParameter(name);
		return StringHelper.toLong(value);
	}
	
	protected int getInt(HttpServletRequest request, String name){
		String value = request.getParameter(name);
		return StringHelper.toint(value);
	}

	@RequestMapping(value = "open.do", method = RequestMethod.GET)
	public String open(HttpServletRequest request, Model model){
		setting(model);
		LogonUser user = getUser();
		if(null == user){
			//试用的内容
			//未登录
			return touristTrial(request, model);
		}
		MemberSettingEntity fm = funMapping(model, user);
		MemberEntity member = fm.getMember();
		OpenedPointsConfig opc = loginConfig(model, request, fm);
		if(!hasOpened(fm)){
			int cost = openCost(opc);
			HelperMessageConfig hmc = new HelperMessageConfig();
			configService.read(new BaseEvent(hmc), HelperMessageConfig.class);
			
			if(!reachLine(member, opc, model, true)){
				//在执行开通的时候，发现会员未达到所要求的积分条件
				//只能继续试用
				String cnt = hmc.getMessage_5();
				if(StringHelper.isNotEmpty(cnt)){
					cnt.replace("{功能}", functionName);
					addMessage(model, request, cnt);
				}
				
				boolean costCash = openCoseCash(opc);
				long availableCash = parseCash(model, member, costCash);
				return memberTrial(request, model, availableCash, cost, costCash);
			}
			Date now = new Date();
			//可以开通
			if(cost > 0){
				boolean costCash = openCoseCash(opc);
				long availableCash;
				String costClass;
				if(costCash){
					availableCash = member.getAvailableCash();
					costClass = "member-available-cash";
				}else{
					availableCash = member.getAvailablePoints();
					costClass = "member-available-points";
				}
				model.addAttribute("costClass", costClass);
				if(cost > availableCash){//当前会员所需要购买该功能的积分不足
					tooltip(model, "开通[" + functionName + "]功能需要花费<span class='" + costClass+"'>" + cost + "</span>，而您当前可用<span class='" + costClass+"'>" + availableCash + "</span>，无法开通[" + functionName + "]功能！");
//					model.addAttribute("msgTooltip", );
					return memberTrial(request, model, availableCash, cost, costCash);
				}
				open(fm, cost, now);
				memberService.update(fm, now, cost, costCash, "开通" + functionName + "功能");
			}else{
				//这里0积分就可以开通这个功能
				open(fm, 0, now);//这里是为了避免出现 "cost < 0" 的情况
				memberService.update(fm);
			}
			model.addAttribute("myPoints", member.getAvailablePoints());
			model.addAttribute("myCash", member.getAvailableCash());
			
			//开通成功
			String cnt = hmc.getMessage_4();
			if(StringHelper.isNotEmpty(cnt)){
				cnt.replace("{功能}", functionName);
				addMessage(model, request, cnt);
			}
		}
		return render(request, model, member, user);
	}

	@RequestMapping(value = "index.do", method = RequestMethod.GET)
	public String get(HttpServletRequest request, Model model){
		setting(model);
		/*
		 * 判断是否已经登录：
		 * 1.未登录，显示试用的内容
		 * 2.已登录，判断是否已经开通：
		 *   2.1 未开通，显示试用的内容，并显示开能的按钮；如果积分不够，则还需要显示充值的按钮
		 *   2.2 已开通，显示该功能
		 *   
		 * 功能有区分大功能和同一个大功能下的小功能。
		 * 大功能或小功能都可能有列表项，如：过程、过程组等列表项
		 * */
		LogonUser user = getUser();
		if(null == user){
			//试用的内容
			//未登录
			return touristTrial(request, model);
		}
		MemberSettingEntity fm = funMapping(model, user);
		MemberEntity member = fm.getMember();
		OpenedPointsConfig opc = loginConfig(model, request, fm);
		if(!hasOpened(fm)){
			int cost = openCost(opc);
			if(reachLine(member, opc, model, false)){
				if(cost <= 0){//直接开通，0积分购买
					open(fm, 0,  new Date());
					memberService.update(fm);
					return render(request, model, member, user);
				}
			}
			boolean costCash = openCoseCash(opc);
			long availableCash = parseCash(model, member, costCash);
			//这里主要的是如何组open.do的url(参数)
			return memberTrial(request, model, availableCash, cost, costCash);
		}
		return render(request, model, member, user);
	}
	
	private long parseCash(Model model, MemberEntity member, boolean costCash){
		if(costCash){
			model.addAttribute("costClass", "member-available-cash");
			return member.getAvailableCash();
		}
		model.addAttribute("costClass", "member-available-points");
		return member.getAvailablePoints();
	}
	
	/**
	 * 直接开通某一个功能，这里如何设值只有具体的子类才能确定
	 * @param fm
	 */
	protected abstract void open(MemberSettingEntity fm, int cost, Date now);
	
	protected String functionName;
	protected String functionTitle;
	protected String functionLayout = "master.vm";
	protected String functionMenu;
	protected String channelSelected;
	protected String vmName;
	
	protected void setting(Model model){
		model.addAttribute("layout", functionLayout);
		model.addAttribute("mainMenu", functionMenu);
		model.addAttribute("channelSelected", channelSelected);
		model.addAttribute("sysTitle", functionTitle);
	}
	/**
	 * 生成该功能
	 * @param request
	 * @param model
	 * @param selectedId
	 * @param member
	 * @param user
	 * @return
	 */
	protected String render(HttpServletRequest request, Model model, MemberEntity member, LogonUser user){
		return vmName;
	}

	/**
	 * 只有试用的功能
	 * @param request
	 * @param model
	 * @param selectedId
	 * @return
	 */
	protected String trial(HttpServletRequest request, Model model){
		model.addAttribute("trialTitle", trialTitle);
		return vmTrial;
	}
	
	protected String vmTrial;
	protected String trialTitle;
	
	protected String touristTrial(HttpServletRequest request, Model model){
		nologinConfig(model, request);

		return trial(request, model);
	}
	
	protected String memberTrial(HttpServletRequest request, Model model, long availableCash, int cost, boolean costCash){
		model.addAttribute("needOpen", true);
		//availableCash可用的现金
		model.addAttribute("availableCash", availableCash);
		model.addAttribute("cost", cost);
		model.addAttribute("costCash", costCash);
		model.addAttribute("urlParameters", request.getQueryString());
		model.addAttribute("funName", functionName);
		//可能需要进行充值或转换
		return trial(request, model);
	}
	
	/**
	 * 是否已经达到积分线，如果没有达到积分线的，则与未登录的一样，只显示试用的部分
	 * @param member
	 * @param opc
	 * @param showAlert 在未达到积分要求的情况下，是否进行提示，如果是，则应该如何提示
	 * @return
	 */
	protected boolean reachLine(MemberEntity member, OpenedPointsConfig opc, Model model, boolean showAlert){
		//未达到积分要求的进行提示	
		int reach = reachPoint(opc);
		long tp = member.getLevelPoints();
		if(reach > tp){//这个情况应该是异常情况，也许管理员调整了该会员的积分记录
			if(showAlert){
				tooltip(model, "需要达到开通[" + functionName + "]功能的积分线为" + reach + "，而您当前的总积分值为" + tp + "，无法开通此功能！");
			}
			return false;
		}
		return true;
	}
	
	protected int reachPoint(OpenedPointsConfig opc){ return 0; }
	
	protected boolean hasOpened(MemberSettingEntity fm){ return false; }
	
	/**
	 * 开通该功能需要花费的积分，如果为0则表示可以直接购买进来
	 * @param opc
	 * @return
	 */
	protected int openCost(OpenedPointsConfig opc){ return 0; }
	
	/**
	 * 是不是使用现金开通
	 * @return
	 */
	protected boolean openCoseCash(OpenedPointsConfig opc){ return false; }
	
}
