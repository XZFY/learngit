package cn.bonoon.controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.bonoon.core.ConfigService;
import cn.bonoon.core.MemberService;
import cn.bonoon.core.configs.CashExchangeConfig;
import cn.bonoon.core.configs.HelperMessageConfig;
import cn.bonoon.core.configs.KuaiQianConfig;
import cn.bonoon.entities.ExchangeEntity;
import cn.bonoon.entities.KuaiqianRechargeEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.kernel.events.BaseEvent;
import cn.bonoon.kernel.util.StringHelper;
import cn.bonoon.kernel.web.controllers.AbstractController;
import cn.bonoon.kernel.web.models.JsonResult;

/**
 * 充值或进行钻石与金币的兑换
 * @author jackson
 *
 */
@Controller
@RequestMapping("pmp/recharge")
public class RechargeController extends AbstractController{
	@Autowired
	protected ConfigService configService;
	
	@Autowired
	protected MemberService memberService;
	
	@RequestMapping("exchange.do")
	public String exchange(Model model){
		model.addAttribute("layout", "layout-empty.vm");
		MemberEntity member = memberService.getMember(getUser());
		model.addAttribute("availablePoints", member.getAvailablePoints());
		model.addAttribute("availableCash", member.getAvailableCash());
		CashExchangeConfig cec = config();
		model.addAttribute("exchangeRate", cec.getExchangeRate());
		StringBuilder ptSelect = new StringBuilder();
		for(Map.Entry<String, String> entry : payTypes.entrySet()){
			ptSelect.append("<option value='").append(entry.getKey()).append("'>").append(entry.getValue()).append("</option>");
		}
		model.addAttribute("ptSelect", ptSelect);
		StringBuilder sp = new StringBuilder();
		cec.bonus().exp(sp);
		model.addAttribute("sp", sp);
		int cp = cec.getCashPoints();
		if(cp > 0){
			model.addAttribute("cp", "<span style='color:blue'>每充值1元人民币可得" + cp + "积分</span>");
		}
		return "recharge/exchange";
	}

	@ResponseBody
	@RequestMapping("refresh.do")
	public JsonResult refresh(){
		try{
			MemberEntity member = memberService.getMember(getUser());
			long availableCash = member.getAvailableCash();
			long availablePoints = member.getAvailablePoints();
			long[] data = {availableCash, availablePoints};
			return JsonResult.result(data);
		}catch(Exception ex){
			return JsonResult.error(ex);
		}
	}
	@ResponseBody
	@RequestMapping("recharge.do")
	public JsonResult recharge(int exchangeDiamond){
		try{
			MemberEntity member = memberService.getMember(getUser());
			long availableCash = member.getAvailableCash();
			if(availableCash < exchangeDiamond){
				throw new Exception("您当前的钻石只有" + availableCash + "无法兑换" + exchangeDiamond + "个");
			}
			CashExchangeConfig cec = config();
			int rate = cec.getExchangeRate();
			availableCash -= exchangeDiamond;
			int ep = rate * exchangeDiamond;
			long availablePoints = member.getAvailablePoints(), totalPoints = member.getTotalPoints();
			totalPoints += ep;
			availablePoints += ep;
			member.setAvailablePoints(availablePoints);
			member.setTotalPoints(totalPoints);
			member.setAvailableCash(availableCash);
			ExchangeEntity ee = new ExchangeEntity();
			ee.setCreateAt(new Date());
			ee.setCreatorId(member.getId());
			ee.setMember(member);
			ee.setDiamond(exchangeDiamond);
			ee.setRate(rate);
			ee.setPoints(ep);
			ee.setAvailablePoints(availablePoints);
			ee.setTotalPoints(totalPoints);
			memberService.saveExchange(member, ee);
			long[] data = {availableCash, availablePoints, exchangeDiamond, ep};
			return JsonResult.result(data);
		}catch(Exception ex){
			return JsonResult.error(ex);
		}
	}
	
	private CashExchangeConfig config(){
		CashExchangeConfig cec = new CashExchangeConfig();
		configService.read(new BaseEvent(cec), CashExchangeConfig.class);
		return cec;
	}

//	@Value("${pki.pfx.path}")
//	private String ispfx;
//	@Value("${pki.cer.path}")
//	private String iscer;
//	@Value("${pki.code}")
//	private String kpicode;
//	@Value("${pki.key.passwrod}")
//	private String kpikey;
//	@Value("${pki.key.alias}")
//	private String kpialias;
//	@Value("${pki.url}")
//	private String kpiurl;
	
	@RequestMapping("kuaiqian.do")
	public String kuaiqian(HttpServletResponse response, HttpServletRequest request, KuaiQianInfo kqi, Model model){
		try{
			double orderAmount = StringHelper.todouble(kqi.getOrderAmount());
			if(orderAmount <= 0){
				//严重异常
				throw new Exception("金额不正确！");
			}
			KuaiQianConfig kqc = new KuaiQianConfig();
			configService.read(new BaseEvent(kqc), KuaiQianConfig.class);
			if(StringHelper.isEmpty(kqc.getPkiCode())){
				throw new Exception("没有定义商户信息！");
			}
			kqi.setMerchantAcctId(kqc.getPkiCode());
			kqi.setKuaiqianUrl(kqc.getPkiUrl());
			//保存到数据库
			KuaiqianRechargeEntity kre = kqi.entity();
			kre.setOrderAmount(orderAmount);
			
			MemberEntity member = memberService.getMember(getUser());
			kre.setMember(member);
			
			memberService.saveRecharge(kre);
			//跳转
	//		try {
	//			
	//			//response.sendRedirect(url);
	//		} catch (IOException e) {
	//			e.printStackTrace();
	//		}
			//orderAmount *= 100;
			kqi.setOrderAmount(String.valueOf((int)orderAmount));
			kqi.parameter(response, request, applicationContext.getResource(kqc.getPkipfxPath()), kqc);
			model.addAttribute("pki", kqi);
			return "recharge/pki-send";
		}catch (Exception e) {
			e.printStackTrace();
			return errorPanel(model, e.getMessage());
		}
//		MemberEntity member = memberService.getMember(getUser());
//		kqi.setPayerName(member.getName());
//		String email = member.getEmail();
//		if(StringHelper.isNotEmpty(email)){
//			kqi.setPayerContactType("1");
//			kqi.setPayerContact(email);
//		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("return.do")
	public String kqreturn(HttpServletRequest request, Model model){
		//这里是从快钱那边回调过来的，所以是拿不到当前操作的会员的信息的
		try{
			KuaiQianReturn kqReturn = new KuaiQianReturn(request);
			KuaiQianConfig kqc = new KuaiQianConfig();
			configService.read(new BaseEvent(kqc), KuaiQianConfig.class);
			if(StringHelper.isEmpty(kqc.getPkiCode())){
				throw new Exception("没有定义商户信息！");
			}
			if(!kqReturn.check(applicationContext.getResource(kqc.getPkicerPath()))){
				throw new Exception("验证失败");
			}
			String msg;
			if("10".equals(kqReturn.getPayResult())){
				//成功
				//充值成功的提示
				HelperMessageConfig hmc = new HelperMessageConfig();
				configService.read(new BaseEvent(hmc), HelperMessageConfig.class);
				String cnt = hmc.getMessage_10();
				if(StringHelper.isNotEmpty(cnt)){
					cnt = cnt.replace("{用户名}", getUser().getUsername());
					HttpSession hs = request.getSession();
					Object hms = hs.getAttribute("helperMessages");
					List<String> items;
					if(hms instanceof List){
						items = (List<String>)hms;
					}else{
						items = new ArrayList<>();
						hs.setAttribute("helperMessages", items);
					}
					items.add(cnt);
				}
				msg = "充值成功！";
			}else{
				//失败
				msg = errorCodes.get(kqReturn.getErrCode());
			}
			String oid = kqReturn.getOrderId();
			model.addAttribute("orderId", oid);
			model.addAttribute("orderAmount", kqReturn.getOrderAmount());
			KuaiqianRechargeEntity re = memberService.getRecharge(oid, KuaiqianRechargeEntity.class);
			if(null == re){
				//不知道是什么情况，居然不是从这里发出去的连接，又怎么会回来的，好吧。那也得记录下来。
//				re = kqReturn.entity();
//				re.setRemark(msg);
//				memberService.saveRecharge(re);
				throw new Exception("充值异常，请联系客服核对本次充值操作！");
			}else{
				kqReturn.entity(re);
				re.setRemark(msg);
				memberService.updateRecharge(re, config());
			}
			model.addAttribute("msg", msg);
		}catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("msg", e.getMessage());
		}
		return "recharge/pki-receive";
	}
	
	private final static Map<String, String> payTypes = new HashMap<>();
	private final static Map<String, String> bankCodes = new HashMap<>();
	private final static Map<String, String> errorCodes = new HashMap<>();
	
	static{
		bankCodes.put("ICBC", "中国工商银行");
		bankCodes.put("CMB", "招商银行");
		bankCodes.put("CCB", "中国建设银行");
		bankCodes.put("ABC", "中国农业银行");
		bankCodes.put("BOC", "中国银行");
		bankCodes.put("SPDB", "上海浦东发展银行");
		bankCodes.put("BCOM", "交通银行");
		bankCodes.put("CMBC", "中国民生银行");
		bankCodes.put("SDB", "深圳发展银行");
		bankCodes.put("GDB", "广东发展银行");
		bankCodes.put("CITIC", "中信银行");
		bankCodes.put("HXB", "华夏银行");
		bankCodes.put("CIB", "兴业银行");
		bankCodes.put("GZRCC", "广州市农村信用合作社");
		bankCodes.put("GZCB", "广州市商业银行");
		bankCodes.put("SHRCC", "上海农村商业银行");
		bankCodes.put("CPSRB", "中国邮政储蓄");
		bankCodes.put("CEB", "中国光大银行");
		bankCodes.put("NJCB", "南京银行");
		bankCodes.put("BEA", "东亚银行");
		bankCodes.put("BOB", "北京银行");
		bankCodes.put("CBHB", "渤海银行");
		bankCodes.put("BJRCB", "北京农村商业银行");
		bankCodes.put("CNPY", "中国银联");
		bankCodes.put("PAB", "平安银行");
		bankCodes.put("HSB", "徽商银行");
		bankCodes.put("SHB", "上海银行");
		bankCodes.put("HZB", "杭州银行");
		bankCodes.put("NBCB", "宁波银行");
		
		errorCodes.put("00000", "未知错误");
		errorCodes.put("10001", "不支持的字符编码格式，系统支持的编码格式为 1.UTF-8，2.GBK， 3.GB2312");
		errorCodes.put("10002", "不支持的返回类型，系统支持的返回类型为 1.页面返回， 2.后台返回， 3.同时支持页面和后台返回");
		errorCodes.put("10003", "页面返回地址和后台返回地址不能同时为空，请使用符合URL规则的http或者https地址");
		errorCodes.put("10004", "页面返回地址和后台返回地址不能同时为空，请使用符合URL规则的http或者https地址");
		errorCodes.put("10005", "不支持的风头接口版本号，目前系统支持的版本号为 v2.0");
		errorCodes.put("10006", "商户号不存在");
		errorCodes.put("10007", "付款方用户名不正确");
		errorCodes.put("10008", "");
		errorCodes.put("10009", "");
		errorCodes.put("10010", "");
		errorCodes.put("10011", "");
		errorCodes.put("10012", "");
		errorCodes.put("10013", "");
		errorCodes.put("10014", "");
		errorCodes.put("10015", "");
		errorCodes.put("10016", "");
		errorCodes.put("10017", "");
		errorCodes.put("10018", "");
		errorCodes.put("10019", "");
		errorCodes.put("10020", "");
		errorCodes.put("10021", "");
		errorCodes.put("10022", "");
		errorCodes.put("10023", "");
		errorCodes.put("10024", "");
		errorCodes.put("10025", "");
		errorCodes.put("10026", "");
		errorCodes.put("10027", "");
		errorCodes.put("10028", "");
		errorCodes.put("10029", "");
		errorCodes.put("10030", "");
		errorCodes.put("10031", "");
		errorCodes.put("10032", "");
		errorCodes.put("10033", "");
		errorCodes.put("10034", "");
		errorCodes.put("10035", "");
		errorCodes.put("10036", "");
		errorCodes.put("10037", "");
		
		errorCodes.put("20001", "");
		errorCodes.put("20002", "");
		errorCodes.put("20003", "");
		errorCodes.put("20004", "");
		errorCodes.put("20005", "");
		errorCodes.put("20006", "");
		errorCodes.put("20007", "");
		errorCodes.put("20008", "");
		errorCodes.put("20009", "");
		errorCodes.put("20010", "");
		errorCodes.put("20011", "");
		errorCodes.put("20012", "");
		errorCodes.put("20013", "");

		errorCodes.put("30001", "");
		errorCodes.put("30002", "");
		errorCodes.put("30003", "");
		errorCodes.put("30004", "");
		errorCodes.put("30005", "");

		errorCodes.put("50001", "");
		errorCodes.put("50002", "");
		errorCodes.put("50003", "");
		errorCodes.put("50004", "");
		errorCodes.put("50005", "");
		errorCodes.put("50006", "");
		errorCodes.put("50007", "");
		errorCodes.put("50008", "");
		errorCodes.put("50009", "");
		errorCodes.put("50010", "");
		errorCodes.put("50011", "");
		errorCodes.put("50012", "");
		errorCodes.put("50013", "");
		errorCodes.put("50014", "");
		errorCodes.put("50015", "");
		errorCodes.put("50016", "");
		errorCodes.put("50017", "");

		errorCodes.put("60001", "");
		errorCodes.put("60002", "");
		errorCodes.put("60003", "");
		errorCodes.put("60004", "");
		errorCodes.put("60005", "");

		errorCodes.put("70001", "");
		errorCodes.put("70002", "");
		errorCodes.put("70003", "");
		
		payTypes.put("00", "其它支付");
		payTypes.put("10", "银行卡网银支付");
		payTypes.put("11", "电话支付");
		payTypes.put("12", "快钱账户支付");
		payTypes.put("13", "线下支付");
		payTypes.put("14", "企业网银在线支付");
		payTypes.put("15", "信用卡在线支付");
		payTypes.put("17", "预付卡支付");
	}
	
	
}
