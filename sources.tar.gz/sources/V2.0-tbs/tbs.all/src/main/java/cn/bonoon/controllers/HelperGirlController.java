package cn.bonoon.controllers;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.bonoon.Util;
import cn.bonoon.core.plugins.FaqService;
import cn.bonoon.core.plugins.QuestionService;
import cn.bonoon.entities.plugins.QuestionEntity;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.support.models.Page;
import cn.bonoon.kernel.web.models.JsonResult;
import cn.bonoon.util.VerifyCodeHelper;

@Controller
@RequestMapping("pmp/helper")
public class HelperGirlController extends AbstractConfigurableController{
	
	@Autowired
	private FaqService faqService;
	@Autowired
	private QuestionService questionService;
	
	@RequestMapping("self/index.do")
	public String self(Model model, HttpServletRequest request){
		__make(model, request, "self", "自助问答");
		model.addAttribute("faqItems", faqService.find(" and x.level=2"));
		return "help-self";
	}

	@RequestMapping("ask/index.do")
	public String ask(Model model, HttpServletRequest request){
		items(model, __make(model, request, "ask", "专业问答"), 0, 10);
		return "help-ask";
	}
	
	@ResponseBody
	@RequestMapping("ask/add.do")
	public JsonResult addAsk(HttpServletRequest request, String validateCode, String questionContent){
		try{
			Assert.hasText(questionContent, "请输入问题描述！");
			Assert.hasText(validateCode, "请输入验证码！");
			VerifyCodeHelper.verify(request, 2, validateCode);
			
			QuestionEntity qe = new QuestionEntity();
			LogonUser user = getUser();
			if(null != user){
				qe.setCreatorId(user.getId());
				qe.setCreatorName(user.getUsername());
				qe.setLevel(1);
				qe.setOwnerId(user.getOwnerId());
			}else{
				qe.setCreatorName("游客");
				qe.setLevel(2);
			}
			qe.setCreateAt(new Date());
			qe.setQuestion(questionContent);
			
			questionService.save(qe);
			return JsonResult.result();
		}catch(Exception ex){
			return JsonResult.error(ex);
		}
	}

	@RequestMapping("ask/{pageIndex}!index.do")
	public String askItems(Model model, @PathVariable("pageIndex") int pageIndex){
		model.addAttribute("layout", "layout-empty.vm");
		items(model, getUser(), pageIndex, 10);
		return "help-ask-items";
	}
	
	private void items(Model model, LogonUser user , int pageIndex, int pageSize){
		try{
			Page page = questionService.questions(user, pageIndex, pageSize);
			model.addAttribute("page", page);
			Util.paging(model, page, pageIndex, pageSize, "");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	private LogonUser __make(Model model, HttpServletRequest request, String selected, String title){
		model.addAttribute("mainMenu", "menus/menu-helper.vm");
		model.addAttribute("menuSelected", selected);
		model.addAttribute("sysTitle", title);
		return __channel(model, request);
	}
	private LogonUser __channel(Model model, HttpServletRequest request){
		LogonUser user = getUser();
		if(null == user){
			//未登录
			nologinConfig(model, request);
		}else{
			loginConfig(model, request, funMapping(model, user));
		}
		return user;
	}
}
