package cn.bonoon.core;

public interface IStudentInsert extends ILoginEditor, IStudentRecommend {

	int getPoints();

	String getPhone();
}
