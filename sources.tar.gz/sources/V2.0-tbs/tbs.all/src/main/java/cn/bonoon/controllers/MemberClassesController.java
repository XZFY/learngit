package cn.bonoon.controllers;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.bonoon.core.ClassesService;
import cn.bonoon.core.configs.OpenedPointsConfig;
import cn.bonoon.entities.ClassesEntity;
import cn.bonoon.entities.MemberSettingEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.kernel.security.LogonUser;

//班级
@Controller
@RequestMapping("pmp/classes")
public class MemberClassesController extends AbstractIndexController{
	private final ClassesService classesService;
	
	@Autowired
	public MemberClassesController(ClassesService classesService){
		this.classesService = classesService;
	}

	@Override
	protected void init() {
		functionName 	= "班级";
		functionTitle 	= "班级-加入";
		functionMenu 	= "menus/menu-classes.vm";
		channelSelected = "classes";
		vmName 			= "classes";
		vmTrial 		= "practices/free";
		menuSelected 	= "join";
		trialTitle 		= "<span style='font-size: 18px; font-family: Arial;padding-left:15px;'>试用</span>";
	}

	@Override
	protected boolean hasOpened(MemberSettingEntity fm) {
		return fm.isClassOpened();
	}
	
	@Override
	protected int reachPoint(OpenedPointsConfig opc) {
		return opc.getClassReach();
	}
	
	@Override
	protected int openCost(OpenedPointsConfig opc) {
		return opc.getClassCost();
	}

	@Override
	protected boolean openCoseCash(OpenedPointsConfig opc) {
		return opc.isClassCostCash();
	}
	
	@Override
	protected void open(MemberSettingEntity fm, int cost, Date now) {
		fm.setClassAt(now);
		fm.setClassOpened(true);
		fm.setClassPoints(cost);
	}
//
//	@RequestMapping(value = "index.do", method = RequestMethod.GET)
//	public String get(Model model, Long selectedId){
//		try{
//			LogonUser user = getUser();
//			FunctionMappingEntity fm = funMapping(model, user);
//			MemberEntity member = fm.getMember();
//			OpenedPointsConfig opc = config(model, member);
//			if(!fm.isClassOpened()){
//				if(opc.getClassReach() > member.getTotalPoints()){
//					return "redirect:/";
//				}
//				int cost = opc.getClassCost();
//				if(cost > 0){
//					return __grant(model, selectedId, cost);
//				}
//				__open(fm);
//			}
//			return __classes(model, member, selectedId);
//		}catch(Exception ex){
//			return __error(model, ex);
//		}
//	}
//
//	@RequestMapping(value = "open.do", method = RequestMethod.GET)
//	public String open(HttpServletRequest request, Model model, Long selectedId){
//		try{
//			LogonUser user = getUser();
//			FunctionMappingEntity fm = funMapping(model, user);
//			MemberEntity member = fm.getMember();
//			OpenedPointsConfig opc = config(model, member);
//			if(!fm.isClassOpened()){
//				int reach = opc.getClassReach();
//				long tp = member.getTotalPoints();
//				int cost = opc.getClassCost();
//				if(reach > tp){//这个情况应该是异常情况，也许管理员调整了该会员的积分记录
//					model.addAttribute("msg", "需要达到开通班级功能的积分线为" + reach + "，而您当前的总积分值为" + tp + "，无法开通班级功能！");
//					return __grant(model, selectedId, cost);
//				}
//				if(cost > 0){
//					long ap = member.getAvailablePoints();
//					if(cost > ap){//也许您刚刚在其它的页面消费过了积分，导致这里积分不够使用的
//						model.addAttribute("msg", "开通班级功能需要花费" + cost + "积分，而您当前的可用积分为" + ap + "，无法开通班级功能！");
//						return __grant(model, selectedId, cost);
//					}
//					//可以开通
//					Date now = new Date();
//					fm.setClassAt(now);
//					fm.setClassOpened(true);
//					fm.setClassPoints(cost);
//					memberService.update(fm, now, cost, "开通班级功能");
//				}else{
//					//也许这个时候，管理员把该功能的开通积分线调为了0
//					__open(fm);
//				}
//			}
//			return __classes(model, member, selectedId);
//		}catch(Exception ex){
//			return __error(model, ex);
//		}
//	}
	
	@RequestMapping(value = "{id}!join.do", method = RequestMethod.GET)
	public String join(Model model, HttpServletRequest request, @PathVariable("id") Long id){
		try{
			LogonUser user = getUser();
			MemberSettingEntity fm = funMapping(model, user);
			MemberEntity member = fm.getMember();
			OpenedPointsConfig opc = loginConfig(model, request, fm);
			if(!fm.isClassOpened()){
				if(opc.getClassReach() > member.getTotalPoints()){
					return "redirect:/";
				}
				int cost = opc.getClassCost();
				if(cost > 0){
					return __grant(model, 0L, cost);
				}
				__open(fm);
			}
			classesService.joinClasses(member, id);
			return __classes(model, member, null);
		}catch(Exception ex){
			return __error(model, ex);
		}
	}

	@RequestMapping(value = "{id}!apply.do", method = RequestMethod.GET)
	public String apply(Model model, HttpServletRequest request, @PathVariable("id") Long id){
		try{
			LogonUser user = getUser();
			MemberSettingEntity fm = funMapping(model, user);
			MemberEntity member = fm.getMember();
			OpenedPointsConfig opc = loginConfig(model, request, fm);
			if(!fm.isClassOpened()){
				if(opc.getClassReach() > member.getTotalPoints()){
					return "redirect:/";
				}
				int cost = opc.getClassCost();
				if(cost > 0){
					return __grant(model, id, cost);
				}
				__open(fm);
			}
			String ti = classesService.applyInstitution(user, id);
			alert(model, "您已经成功申请了加入【" + ti + "】机构了！请耐心等待审核！");
			return __classes(model, member, id);
		}catch(Exception ex){
			return __error(model, ex);
		}
	}

	@RequestMapping(value = "{id}!abandon.do", method = RequestMethod.GET)
	public String abandon(Model model, HttpServletRequest request, @PathVariable("id") Long id){
		try{
			LogonUser user = getUser();
			MemberSettingEntity fm = funMapping(model, user);
			MemberEntity member = fm.getMember();
			OpenedPointsConfig opc = loginConfig(model, request, fm);
			if(!fm.isClassOpened()){
				if(opc.getClassReach() > member.getTotalPoints()){
					return "redirect:/";
				}
				int cost = opc.getClassCost();
				if(cost > 0){
					return __grant(model, id, cost);
				}
				__open(fm);
			}
			String ti = classesService.abandonInstitution(getUser(), id);
			alert(model, "您已经成功取消了加入【" + ti + "】机构的申请！");
			return __classes(model, member, id);
		}catch(Exception ex){
			return __error(model, ex);
		}
//		return __classes(model, member, null);
	}
	
	protected void __open(MemberSettingEntity fm) {
		fm.setClassAt(new Date());
		fm.setClassOpened(true);
		memberService.update(fm);
	}

	private void __set(Model model){
		model.addAttribute("layout", "master.vm");
		model.addAttribute("mainMenu", "emnu-classes.vm");
		model.addAttribute("channelSelected", "classes");

		model.addAttribute("sysTitle", "班级");
	}
	
	private String __grant(Model model, Long selectedId, int cost){
		__set(model);
		if(null != selectedId){
			model.addAttribute("urlParameters", "?selectedId=" + selectedId);
		}
		model.addAttribute("funName", "班级");
		model.addAttribute("cost", cost);
		return "grant-authorization";
	}
	
	private String __error(Model model, Exception ex){
		ex.printStackTrace();
		__set(model);
		model.addAttribute("error", ex.getMessage());
		return "tbs-error";
	}
	
	private String __classes(Model model, MemberEntity member, Long selectedId){
		__set(model);
		List<ClassesEntity> items = classesService.myClasses(member);
		if(items.isEmpty()){
			//没有加入任何的班级
			model.addAttribute("ici", classesService.institutionClasses(member));
		}else{
			ClassesEntity currentClasses = null;
			if(selectedId != null && selectedId > 0){
				for(ClassesEntity ce : items){
					if(selectedId.equals(ce.getId())){
						currentClasses = ce;
						break;
					}
				}
				if(null == currentClasses){
					currentClasses = items.get(0);
					selectedId = currentClasses.getId();
				}
			}else{
				currentClasses = items.get(0);
				selectedId = currentClasses.getId();
			}
			model.addAttribute("selectedId", selectedId);
			//读取班级的一些信息
			//同班同学
			//培训机构信息
			model.addAttribute("institution", classesService.institution(currentClasses));
			model.addAttribute("classes", currentClasses);
			model.addAttribute("classmate", classesService.classmate(currentClasses));
		}
		model.addAttribute("items", items);
		
		return "classes";
	}
}
