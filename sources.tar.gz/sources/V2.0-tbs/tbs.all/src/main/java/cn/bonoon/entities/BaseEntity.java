package cn.bonoon.entities;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import cn.bonoon.kernel.support.entities.AbstractEntity;

@MappedSuperclass
public abstract class BaseEntity extends AbstractEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6783744211198764415L;

	@Column(name = "C_ENNAME")
	private String enName;

	@Column(name = "C_ORDINAL")
	private int ordinal;

	//过程组的权重
	@Column(name = "C_WEIGHT")
	private double weight;

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}
	public String getEnName() {
		return enName;
	}

	public void setEnName(String enName) {
		this.enName = enName;
	}

	public int getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(int ordinal) {
		this.ordinal = ordinal;
	}
}
