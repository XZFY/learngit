package cn.bonoon.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import cn.bonoon.entities.plugins.AccountEntity;
import cn.bonoon.entities.plugins.PlaceEntity;
import cn.bonoon.entities.plugins.Sex;

/**
 * 系统的会员，可以登录
 * @author jackson
 *
 */
@Entity
@Table(name = "T_MEMBER")
public class MemberEntity extends AccountEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2727386410198952050L;
	public MemberEntity(){
		this.typeName = "会员";
	}

	@Enumerated
	@Column(name = "C_SEX")
	private Sex sex;
	//头像
	@Column(name = "C_PIC")
	private String pic;
	/**
	 * 家庭电话
	 */
	@Column(name = "C_HOMETEL", length = 50)
	private String homeTel;
	@Column(name = "C_KEY", length = 50)
	private String key;
	@Column(name = "C_PHONE", length = 50)
	private String phone;
	@Column(name = "C_EMAIL", length = 50)
	private String email;
	@Column(name = "C_QQ", length = 50)
	private String qq;
	@Column(name = "C_COMPANYNAME", length = 200)
	private String companyName;
	/**
	 * 办公电话
	 */
	@Column(name = "C_COMPANYTEL", length = 50)
	private String companyTel;
	/**
	 * 培训机构
	 */
	@Column(name = "C_TRAININGORG", length = 200)
	private String trainingOrg;
	/**
	 * 当前工作、生活所在的主要城市
	 */
	@ManyToOne
	@JoinColumn(name = "R_PLACE_ID")
	private PlaceEntity place;
	/**
	 * 现住址
	 */
	@Column(name = "C_HOMEADDRESS")
	private String homeAddress;
	/**
	 * 现公司所在的地址
	 */
	@Column(name = "C_COMPANYADDRESS")
	private String companyAddress;

	//级别分，也就是所有分值的转换及累加，如：1块钱为200分，做题为20可用分。
	@Column(name = "C_LEVELPOINTS")
	private long levelPoints;

	@Column(name = "C_TOTALPOINTS")
	private long totalPoints;
	
	@Column(name = "C_AVAILABLEPOINTS")
	private long availablePoints;

	//总的充值或奖励过的现金
	@Column(name = "C_TOTALCASH")
	private long totalCash;

	//可用现金
	@Column(name = "C_AVAILABLECASH")
	private long availableCash;
	
	/**
	 * 介绍人
	 */
	@Column(name = "C_INTRODUCER", length = 50)
	private String introducer;
	
	/**
	 * 自我介绍
	 */
	@Column(name = "C_INTRODUCTION")
	private String introduction;
	
//	//是否完成的会员资料的填写，如果是，则有一定的积分
//	private boolean finish;
	
	/**
	 * 该会员最后一次练习的成绩，用于对比
	 */
	@Column(name = "C_LASTSCORE")
	private int lastScore;
	
	//小助手的名称，会员可以自己设置
	@Column(name = "C_HELPERNAME")
	private String helperName;

	@Column(name = "C_GRADE")
	private Long grade;
	
	public Sex getSex() {
		return sex;
	}

	public void setSex(Sex sex) {
		this.sex = sex;
	}

	public String getHomeTel() {
		return homeTel;
	}
	
	public void setHomeTel(String homeTel) {
		this.homeTel = homeTel;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getQq() {
		return qq;
	}
	
	public void setQq(String qq) {
		this.qq = qq;
	}
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyTel() {
		return companyTel;
	}
	public void setCompanyTel(String companyTel) {
		this.companyTel = companyTel;
	}
	public String getTrainingOrg() {
		return trainingOrg;
	}
	public void setTrainingOrg(String trainingOrg) {
		this.trainingOrg = trainingOrg;
	}
	public PlaceEntity getPlace() {
		return place;
	}
	public void setPlace(PlaceEntity place) {
		this.place = place;
	}
	public String getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}
	public String getCompanyAddress() {
		return companyAddress;
	}
	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}
	public long getTotalPoints() {
		return totalPoints;
	}
	public void setTotalPoints(long totalPoints) {
		this.totalPoints = totalPoints;
	}
	public long getAvailablePoints() {
		return availablePoints;
	}
	public void setAvailablePoints(long availablePoints) {
		this.availablePoints = availablePoints;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getIntroducer() {
		return introducer;
	}
	public void setIntroducer(String introducer) {
		this.introducer = introducer;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}

	public String getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

//	public boolean isFinish() {
//		return finish;
//	}
//
//	public void setFinish(boolean finish) {
//		this.finish = finish;
//	}

	public long getLevelPoints() {
		return levelPoints;
	}

	public void setLevelPoints(long levelPoints) {
		this.levelPoints = levelPoints;
	}

	public long getTotalCash() {
		return totalCash;
	}

	public void setTotalCash(long totalCash) {
		this.totalCash = totalCash;
	}

	public long getAvailableCash() {
		return availableCash;
	}

	public void setAvailableCash(long availableCash) {
		this.availableCash = availableCash;
	}

	public int getLastScore() {
		return lastScore;
	}

	public void setLastScore(int lastScore) {
		this.lastScore = lastScore;
	}

	public String getHelperName() {
		return helperName;
	}

	public void setHelperName(String helperName) {
		this.helperName = helperName;
	}

	public Long getGrade() {
		return grade;
	}

	public void setGrade(Long grade) {
		this.grade = grade;
	}
}
