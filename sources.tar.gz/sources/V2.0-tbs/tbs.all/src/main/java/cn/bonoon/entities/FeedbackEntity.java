package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

@Entity
@Table(name = "T_FEEDBACK")
public class FeedbackEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4908782673118221557L;

	@Column(name = "R_UID")
	private Long uid;
	@Column(name = "C_USERNAME")
	private String userName;
	@Column(name = "C_EMAIL")
	private String email;
	@Column(name = "C_PHONE")
	private String phone;
	@Column(name = "C_CONTENT")
	private String content;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CREATEAT")
	private Date createAt;

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}
	
}
