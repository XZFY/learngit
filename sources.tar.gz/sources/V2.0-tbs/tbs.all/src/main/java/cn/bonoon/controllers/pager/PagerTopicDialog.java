package cn.bonoon.controllers.pager;

import cn.bonoon.controllers.topic.TopicDetail;
import cn.bonoon.core.TopicPagerService;
import cn.bonoon.core.TopicService;
import cn.bonoon.entities.PagerTopicEntity;
import cn.bonoon.kernel.web.ButtonRefreshType;
import cn.bonoon.kernel.web.controllers.BaseButtonResolver;
import cn.bonoon.kernel.web.handlers.DialogDetailHandler;
import cn.bonoon.kernel.web.handlers.DialogGridHandler;
import cn.bonoon.kernel.web.handlers.HandlerRegister;
import cn.bonoon.kernel.web.html.grid.StandardGridBuilder;

public class PagerTopicDialog extends DialogGridHandler<PagerTopicEntity>{
//	private final PagerService service;
	private final TopicService topicService;
//	private final TopicPagerService topicPagerService;
	
	public PagerTopicDialog(
			HandlerRegister register, 
			TopicPagerService topicPagerService, 
//			PagerService service, 
			TopicService topicService) throws Exception {
		super(register, topicPagerService, PagerTopicItem.class);
//		this.service = service;
		this.topicService = topicService;
//		this.topicPagerService = topicPagerService;
		this.relatedKey = "pager";
	}
	
	@Override
	protected ButtonRefreshType getButtonRefreshType() {
		return ButtonRefreshType.ONCLOSE;
	}
	
	@Override
	protected void register(BaseButtonResolver resolver, StandardGridBuilder builder) throws Exception {
		set("编辑试卷题目", true);
		size(700, 480);
		resolver.setName("试题");
		
		//"添加"按钮
//		PagerTopicInsertHandler oih = new PagerTopicInsertHandler(topicService, service, currentRegister.getManager());
//		DialogInsertHandler<TopicEntity> dih = new DialogInsertHandler<TopicEntity>(currentRegister, oih);
//		GridToolbarResolver gtResolver = builder.addToolbar();
//		gtResolver.addParameter("pager", "${form}");
//		dih.register(gtResolver);
		
		//"选择题目"按钮
//		PagerTopicSearchDialog std = new PagerTopicSearchDialog(currentRegister, topicService);
//		std.register(builder.addToolbar()).addParameter("id", "${form}");
		
		//"保存排序"按钮
//		GridToolbarResolver btnSaveOrdinal = builder.addToolbar();
//		btnSaveOrdinal.setName("保存排序");
//		btnSaveOrdinal.setIconCls("icon-save");
//		btnSaveOrdinal.setEventType(ButtonEventType.POST);
//		btnSaveOrdinal.setRefreshType(ButtonRefreshType.FINISH);
//		btnSaveOrdinal.setUrl("exe.ordinal");
		//操作按钮的js处理代码
//		StringBuilder saveBody = new StringBuilder();
//		saveBody.append("var ip=0;var __rows=jQuery('#").append(builder.getId());
//		saveBody.append("').").append(builder.getGridType());
//		saveBody.append("('getRows');for(var __row in __rows){if(__row.ordinal!==__row.hiddenOrdinal){");
//		saveBody.append("__data['ids'][ip++]=__row.id;");
//		saveBody.append("__data['ordinal-'+__row.id]=__row.ordinal;");
//		saveBody.append("}}");
//		btnSaveOrdinal.setFunctionBody(saveBody.toString());
		
		//"优化排序"按钮
//		GridToolbarResolver btnOptimizeOrdinal = builder.addToolbar();
//		btnOptimizeOrdinal.setName("优化排序");
//		btnOptimizeOrdinal.setIconCls("icon-refresh");
//		btnOptimizeOrdinal.setEventType(ButtonEventType.POST);
//		btnOptimizeOrdinal.setRefreshType(ButtonRefreshType.FINISH);
//		btnOptimizeOrdinal.setUrl("exe.optimize");
		//操作按钮的js处理代码
//		btnOptimizeOrdinal.setFunctionBody("__data['id']=" + relatedValue + ';');

		//"删除"按钮
//		OperateIdsHandler.delete(currentRegister, topicPagerService);
		
		//列表"查看","删除"按钮
		DialogDetailHandler.button(currentRegister, topicService, TopicDetail.class).addParameter("id", "topic");
//		OperateIdHandler.delete(currentRegister, topicPagerService);
		
		super.register(resolver, builder);
	}
}
