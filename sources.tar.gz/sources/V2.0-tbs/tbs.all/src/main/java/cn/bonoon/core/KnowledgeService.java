package cn.bonoon.core;

import cn.bonoon.entities.KnowledgePointEntity;
import cn.bonoon.kernel.support.services.GenericService;

public interface KnowledgeService extends GenericService<KnowledgePointEntity>{

}
