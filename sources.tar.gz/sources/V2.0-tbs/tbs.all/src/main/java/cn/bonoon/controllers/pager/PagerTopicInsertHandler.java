package cn.bonoon.controllers.pager;

import cn.bonoon.controllers.topic.TopicEditor;
import cn.bonoon.core.PagerService;
import cn.bonoon.core.TopicService;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.handler.impl.StandardAutoManager;
import cn.bonoon.kernel.events.OperateEvent;
import cn.bonoon.kernel.support.models.ObjectEditor;
import cn.bonoon.kernel.web.handlers.AbstractOperateFormHandler;

public class PagerTopicInsertHandler extends AbstractOperateFormHandler<TopicEntity>{
	private final PagerService pagerService;
	public PagerTopicInsertHandler(TopicService service, PagerService pagerService, StandardAutoManager initializer) throws Exception {
		super(SAVE_INSERT, service, initializer, TopicEditor.class);
		this.pagerService = pagerService;
	}

	@Override
	protected Object internalExecute(OperateEvent event, ObjectEditor editor) {
		Long id = event.getLong("pager");
		if(null == id) throw new NullPointerException();
		//先保存题目
		TopicEntity te = service.save(event);
		//再生成试卷的试题
		return pagerService.save(id, te);
	}
}
