package cn.bonoon.services;

import java.util.Date;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.TransactionService;
import cn.bonoon.entities.CurrencyType;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.TransactionEntity;
import cn.bonoon.entities.TransactionType;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.support.services.AbstractSearchService;

@Service
@Transactional(readOnly = true)
public class TransactionServiceImpl extends AbstractSearchService<TransactionEntity> implements TransactionService{

	@Override
	@Transactional
	public void save(LogonUser user, Long id, int amount, boolean deduct, Date transactionAt, TransactionType transactionType, 
			int levelPoints, CurrencyType currencyType, String remark) {
		TransactionEntity tpe = new TransactionEntity();
		MemberEntity me = entityManager.find(MemberEntity.class, id);
		long tp = amount, ap = amount;
		if(currencyType == CurrencyType.DIAMOND){
			if(deduct){
				tp = me.getTotalCash();
				ap = me.getAvailableCash() - ap;
			}else{
				tp += me.getTotalCash();
				ap += me.getAvailableCash();
			}
			
			me.setTotalCash(tp);
			me.setAvailableCash(ap);
		}else{
			if(deduct){
				tp = me.getTotalPoints();
				ap = me.getAvailablePoints() - ap;
			}else{
				tp += me.getTotalPoints();
				ap += me.getAvailablePoints();
			}
		
			me.setTotalPoints(tp);
			me.setAvailablePoints(ap);
		}
		
		long lp = me.getLevelPoints();
		if(deduct){
			lp -= levelPoints;
		}else{
			lp += levelPoints;
		}
		me.setLevelPoints(lp);
		
		tpe.setAvailable(ap);
		tpe.setTotal(tp);
		
		tpe.setLevelPoints(amount);
		tpe.setAmount(amount);
		tpe.setTransactionType(transactionType);
		tpe.setCurrencyType(currencyType);
		tpe.setCreateAt(new Date());
		tpe.setCreatorId(user.getId());
		tpe.setDeduct(deduct);
		tpe.setRemark(remark);
		tpe.setTransactionAt(transactionAt);
		tpe.setUserId(me.getId());
		entityManager.persist(tpe);
		entityManager.merge(me);
	}

}
