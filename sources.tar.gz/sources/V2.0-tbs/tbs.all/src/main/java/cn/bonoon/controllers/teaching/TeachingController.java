package cn.bonoon.controllers.teaching;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.core.TeachingService;
import cn.bonoon.entities.TeachingEntity;
import cn.bonoon.kernel.web.annotations.grid.GridStandardDefinition;
import cn.bonoon.kernel.web.controllers.AbstractGridController;

//哪个教师在哪个班任哪一门课程
@Controller
@RequestMapping("s/tms/teaching")
public class TeachingController extends AbstractGridController<TeachingEntity, TeachingItem>{
	private final TeachingService service;
	@Autowired
	public TeachingController(TeachingService service) {
		super(service);
		this.service = service;
	}

	@Override
	protected Class<TeachingItem> itemClass() {
		return TeachingItem.class;
	}
	
	@Override
	@GridStandardDefinition(
			insertClass = TeachingEditor.class,
			updateClass = TeachingEditor.class,
			detailClass = TeachingDetail.class)
	protected TeachingService initLayoutGrid(LayoutGridRegister register) throws Exception {
		return service;
	}
}
