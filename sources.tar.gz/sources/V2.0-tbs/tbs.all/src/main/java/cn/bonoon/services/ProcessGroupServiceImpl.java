package cn.bonoon.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.ProcessGroupService;
import cn.bonoon.entities.ProcessGroupEntity;
import cn.bonoon.kernel.support.services.AbstractService;

@Service
@Transactional(readOnly = true)
public class ProcessGroupServiceImpl extends AbstractService<ProcessGroupEntity> implements ProcessGroupService{

	@Override
	public String getName(Long id) {
		String ql = "select x.name from ProcessGroupEntity x where x.id=?";
		return __first(String.class, ql, id);
	}

}
