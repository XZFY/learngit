package cn.bonoon.controllers.topic;

import cn.bonoon.kernel.annotations.ResetProperties;
import cn.bonoon.kernel.annotations.ResetProperty;

@ResetProperties({
	@ResetProperty(value = "name", name = "关键词"),
	@ResetProperty(value = "code", name = "题目编码"),
	@ResetProperty(value = "cnContent", name = "内容(中)"),
	@ResetProperty(value = "cnOptionA", name = "选项(中)-A"),
	@ResetProperty(value = "cnOptionB", name = "选项(中)-B"),
	@ResetProperty(value = "cnOptionC", name = "选项(中)-C"),
	@ResetProperty(value = "cnOptionD", name = "选项(中)-D"),
	@ResetProperty(value = "cnExplanation", name = "答案解释(中)"),
	@ResetProperty(value = "enContent", name = "内容(英)"),
	@ResetProperty(value = "enOptionA", name = "选项(英)-A"),
	@ResetProperty(value = "enOptionB", name = "选项(英)-B"),
	@ResetProperty(value = "enOptionC", name = "选项(英)-C"),
	@ResetProperty(value = "enOptionD", name = "选项(英)-D"),
	@ResetProperty(value = "enExplanation", name = "答案解释(英)"),
	@ResetProperty(value = "cnPicture", name = "示图(中)"),
	@ResetProperty(value = "enPicture", name = "示图(英)"),
	@ResetProperty(value = "creatorName", name = "创建者"),
	@ResetProperty(value = "createAt", name = "创建时间"),
	@ResetProperty(value = "remark", name = "备注"),
	@ResetProperty(value = "process", name = "过程"),
	@ResetProperty(value = "group", name = "过程组"),
	@ResetProperty(value = "area", name = "知识领域"),
	@ResetProperty(value = "knowledge", name = "知识点"),
	@ResetProperty(value = "freeFast", name = "快战"),
	@ResetProperty(value = "freeCombat", name = "实战"),
	@ResetProperty(value = "improve", name = "提高"),
	@ResetProperty(value = "praxis", name = "练习"),
	@ResetProperty(value = "exam", name = "试题"),
	@ResetProperty(value = "real", name = "真题"),
	@ResetProperty(value = "videoPath", name = "视频讲解"),
	@ResetProperty(value = "videoExt", name = "视频类型"),
	@ResetProperty(value = "answer", name = "答案"),
	@ResetProperty(value = "difficulty", name = "难度")
})
public interface TopicDefine {

}
