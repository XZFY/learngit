package cn.bonoon.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import cn.bonoon.entities.MemberEntity;
import cn.bonoon.kernel.security.LogonUser;

public abstract class AbstractIndexController extends AbstractTrialableController{

	@Override
	protected String touristTrial(HttpServletRequest request, Model model) {
		nologinConfig(model, request);
		model.addAttribute("menuSelected", menuSelected);
		model.addAttribute("error", "<p style='padding: 50px 0 0 120px;font-size:16px;color:red;'>使用[" + functionTitle + "]的功能请先登录系统！</p>");
		return "tbs-error";
	}

	protected String menuSelected;
	
	@Override
	protected String render(HttpServletRequest request, Model model, MemberEntity member, LogonUser user) {
		model.addAttribute("menuSelected", menuSelected);
		return super.render(request, model, member, user);
	}
	
	@Override
	protected String memberTrial(HttpServletRequest request, Model model, long availableCash, int cost, boolean costCash) {
		model.addAttribute("menuSelected", menuSelected);
		return super.memberTrial(request, model, availableCash, cost, costCash);
	}
}
