package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

//教师任课记录
@Entity
@Table(name = "T_TEACHING")
public class TeachingEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3485633931452536927L;

	@ManyToOne
	@JoinColumn(name = "R_TEACHER_ID")
	private TeacherEntity teacher;
	
	@ManyToOne
	@JoinColumn(name = "R_CLASSES_ID")
	private ClassesEntity classes;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CREATEAT")
	private Date createAt;
	
	//课程名称
	@Column(name = "C_COURSENAME")
	private String courseName;
	
	@Column(name = "C_REMARK")
	private String remark;
	
	@Column(name = "C_STATUS")
	private int status;

	public TeacherEntity getTeacher() {
		return teacher;
	}

	public void setTeacher(TeacherEntity teacher) {
		this.teacher = teacher;
	}

	public ClassesEntity getClasses() {
		return classes;
	}

	public void setClasses(ClassesEntity classes) {
		this.classes = classes;
	}

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
}
