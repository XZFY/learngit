package cn.bonoon.controllers.pager;

import cn.bonoon.kernel.support.models.AbstractItem;
import cn.bonoon.kernel.web.annotations.grid.AsColumn;
import cn.bonoon.kernel.web.annotations.grid.AsDataGrid;
import cn.bonoon.kernel.web.annotations.grid.GridOptions;

@AsDataGrid(condition = PagerCondition.class, value = @GridOptions(operationWith = 300))
public class PagerItem extends AbstractItem implements PagerDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = -396709200328813040L;
	
	@AsColumn(width = 180, ordinal = 0)
	private String name;

	@AsColumn(width = 80, ordinal = 10)
	private String type;

	@AsColumn(width = 40, ordinal = 20)
	private int amount;
	@AsColumn(width = 40, ordinal = 21)
	private boolean diamond;

	@AsColumn(width = 60, ordinal = 30)
	private int count;

	@AsColumn(width = 60, ordinal = 40)
	private String status;

	@AsColumn(width = 130, ordinal = 50)
	private String createAt;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

//	public int getPoints() {
//		return points;
//	}
//
//	public void setPoints(int points) {
//		this.points = points;
//	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreateAt() {
		return createAt;
	}

	public void setCreateAt(String createAt) {
		this.createAt = createAt;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public boolean isDiamond() {
		return diamond;
	}

	public void setDiamond(boolean diamond) {
		this.diamond = diamond;
	}
	
}
