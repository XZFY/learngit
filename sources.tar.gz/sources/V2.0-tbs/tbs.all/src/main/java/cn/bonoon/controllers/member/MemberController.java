package cn.bonoon.controllers.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.controllers.comment.CommentDialog;
import cn.bonoon.core.AnswerService;
import cn.bonoon.core.MemberService;
import cn.bonoon.core.TopicCommentService;
import cn.bonoon.core.TransactionService;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.kernel.web.ButtonEventType;
import cn.bonoon.kernel.web.annotations.grid.GridStandardDefinition;
import cn.bonoon.kernel.web.controllers.AbstractGridController;

@Controller
@RequestMapping("s/pmp/member")
public class MemberController extends AbstractGridController<MemberEntity, MemberItem>{
	private final MemberService service;
	private final TransactionService pointsService;
	private final TopicCommentService commentService;
	private final AnswerService answerService;
	
	@Autowired
	public MemberController(MemberService service, 
			TopicCommentService commentService, 
			TransactionService pointsService,
			AnswerService answerService) {
		super(service);
		this.service = service;
		this.commentService = commentService;
		this.pointsService = pointsService;
		this.answerService = answerService;
	}

	@Override
	@GridStandardDefinition(
			insertClass = MemberInserter.class, 
			updateClass = MemberUpdater.class, 
			detailClass = MemberDetail.class)
	protected MemberService initLayoutGrid(LayoutGridRegister register) throws Exception {
		//积分记录
		MemberProcessDialog.button(register, answerService).ordinal(60);
		MemberPointsDialog.button(register, pointsService).ordinal(70);
		register.button("积分登记", "record.do", ButtonEventType.DIALOG).ordinal(80);
		register.button("介绍的会员", "introduce.do", ButtonEventType.DIALOG).ordinal(51);
		
		//评论、评分记录
		CommentDialog.button(register, commentService, "creatorId");
		return service;
	}

	@Override
	protected Class<MemberItem> itemClass() {
		return MemberItem.class;
	}
}
