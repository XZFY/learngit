package cn.bonoon.entities;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * 题目的领域、应该是相当于章节的
 * @author jackson
 *
 */
@Entity
@Table(name = "T_KNOWLEDGEAREA")
public class KnowledgeAreaEntity extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7321479157803249752L;

}
