package cn.bonoon.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.TopicCommentService;
import cn.bonoon.entities.TopicComment;
import cn.bonoon.kernel.support.services.AbstractService;

@Service
@Transactional(readOnly = true)
public class TopicCommentServiceImpl extends AbstractService<TopicComment> implements TopicCommentService{

}
