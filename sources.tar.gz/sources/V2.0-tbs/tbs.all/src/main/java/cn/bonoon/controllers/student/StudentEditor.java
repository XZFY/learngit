package cn.bonoon.controllers.student;

import java.util.Date;

import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.support.models.ObjectEditor;
import cn.bonoon.kernel.web.annotations.components.AsSelector;
import cn.bonoon.kernel.web.annotations.components.AsTextArea;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

public class StudentEditor extends ObjectEditor implements StudentDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4344204190487807731L;
	
	@TransformField
	@PropertyEditor(value = 0, colspan = 1, width = 200)
	@PropertyHelper(value = "国家的学号、机构编号或者为空！", type = HelperType.DIRECT)
	private String sid;
	
	@TransformField
	@PropertyEditor(11)
	private Date registerAt;
//
//	@TransformField
//	@PropertyEditor(12)
//	@AsComboBox
//	@AutoDataLoader(TrainingInstitutionEntity.class)
//	@FilterParameter("id")
//	private Long institution;
	
	@TransformField
	@PropertyEditor(10)
	@AsSelector
	private int status;

	@TransformField
	@PropertyEditor(value = 150, colspan = 1)
	@AsTextArea
	private String remark;

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

//	public Long getInstitution() {
//		return institution;
//	}
//
//	public void setInstitution(Long institution) {
//		this.institution = institution;
//	}
	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getRegisterAt() {
		return registerAt;
	}

	public void setRegisterAt(Date registerAt) {
		this.registerAt = registerAt;
	}
	
}
