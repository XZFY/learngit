package cn.bonoon.core.infos;

import cn.bonoon.Util;

/**
 * 做题记录
 * @author jackson
 *
 */
public class RecordItem {
	
	private Long id;
	
	private String start;
	
	private String spentTime;
	
	private boolean unfinished;
	
	private int rightCount;
	
	private int total;

	private String status;

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getSpentTime() {
		return spentTime;
	}

	public void setSpentTime(String spentTime) {
		this.spentTime = spentTime;
	}

	public void setSpentTime(long spentTime) {
		this.spentTime = Util.timeSpent(spentTime);
	}

	public boolean isUnfinished() {
		return unfinished;
	}

	public void setUnfinished(boolean unfinished) {
		this.unfinished = unfinished;
	}

	public int getRightCount() {
		return rightCount;
	}

	public void setRightCount(int rightCount) {
		this.rightCount = rightCount;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}
}
