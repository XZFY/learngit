package cn.bonoon.core;

import cn.bonoon.entities.CompetitionEntity;
import cn.bonoon.kernel.support.services.GenericService;

public interface CompetitionService extends GenericService<CompetitionEntity>{

}
