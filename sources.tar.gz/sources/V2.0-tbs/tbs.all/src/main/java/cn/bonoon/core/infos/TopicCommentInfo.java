package cn.bonoon.core.infos;

import cn.bonoon.entities.TopicComment;
import cn.bonoon.kernel.util.StringHelper;

public class TopicCommentInfo {
	
	public TopicCommentInfo(TopicComment tc){
		id = tc.getId();
		name = tc.getCreatorName();
		time = StringHelper.datetime2String(tc.getCreateAt());
		content = tc.getContent().replace("\t", "<br/>").replace("\n", "<br/>");
	}
	private final Long id;
	
	private final String name;
	
	private final String time;
	
	private final String content;

	public String getName() {
		return name;
	}

	public String getTime() {
		return time;
	}

	public String getContent() {
		return content;
	}

	public Long getId() {
		return id;
	}
	
}
