package cn.bonoon.services;

import java.util.Date;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.FeedbackService;
import cn.bonoon.entities.FeedbackEntity;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.services.AbstractSearchService;

@Service
@Transactional(readOnly = true)
public class FeedbackServiceImpl extends AbstractSearchService<FeedbackEntity> implements FeedbackService{

	@Override
	@Transactional
	public void save(IOperator user, String name, String phone, String email, String content) {
		FeedbackEntity fe = new FeedbackEntity();
		fe.setContent(content);
		fe.setCreateAt(new Date());
		fe.setEmail(email);
		fe.setPhone(phone);
		fe.setUserName(name);
		if(null != user){
			fe.setUid(user.getId());
		}
		entityManager.persist(fe);
	}

}
