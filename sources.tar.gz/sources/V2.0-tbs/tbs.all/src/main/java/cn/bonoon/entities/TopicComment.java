package cn.bonoon.entities;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;


/**
 * <pre>
 * 关于试题的评论
 * 
 * 对试卷进行评分后，用户应该可以得到相应的积分
 * </pre>
 * @author jackson
 *
 */
@Entity
@Table(name = "CT_TOPIC")
public class TopicComment extends AbstractComment<TopicEntity>{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4576904953244802949L;
	
	@Transient
	private String cnContent;
	
	@Transient
	private String enContent;

	public String getCnContent() {
		cnContent = getCommented().getCnContent();
		return cnContent;
	}

	public void setCnContent(String cnContent) {
		this.cnContent = cnContent;
	}

	public String getEnContent() {
		enContent = getCommented().getEnContent();
		return enContent;
	}

	public void setEnContent(String enContent) {
		this.enContent = enContent;
	}
}
