package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

//专门用于把钻石转为积分
@Entity
@Table(name = "T_EXCHANGE")
public class ExchangeEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4722462018432298031L;

	@ManyToOne
	@JoinColumn(name = "R_MEMBER_ID")
	private MemberEntity member;

	@Column(name = "C_CREATORID")
	private Long creatorId;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CREATEAT")
	private Date createAt;

	@Column(name = "C_DIAMOND")
	private int diamond;

	@Column(name = "C_POINTS")
	private int points;

	@Column(name = "C_RATE")
	private int rate;

	@Column(name = "C_AVAILABLEPOINTS")
	private long availablePoints;

	@Column(name = "C_TOTALPOINTS")
	private long totalPoints;

	public MemberEntity getMember() {
		return member;
	}

	public void setMember(MemberEntity member) {
		this.member = member;
	}

	public Long getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(Long creatorId) {
		this.creatorId = creatorId;
	}

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	public int getDiamond() {
		return diamond;
	}

	public void setDiamond(int diamond) {
		this.diamond = diamond;
	}

	public int getPoints() {
		return points;
	}

	public void setPoints(int points) {
		this.points = points;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public long getAvailablePoints() {
		return availablePoints;
	}

	public void setAvailablePoints(long availablePoints) {
		this.availablePoints = availablePoints;
	}

	public long getTotalPoints() {
		return totalPoints;
	}

	public void setTotalPoints(long totalPoints) {
		this.totalPoints = totalPoints;
	}
}
