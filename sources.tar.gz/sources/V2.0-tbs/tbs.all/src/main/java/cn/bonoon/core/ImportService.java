package cn.bonoon.core;

import java.util.List;

import cn.bonoon.core.infos.TopicTypeSetting;
import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.entities.KnowledgePointEntity;
import cn.bonoon.entities.ProcessEntity;
import cn.bonoon.entities.ProcessGroupEntity;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.support.IOperator;

public interface ImportService {

	KnowledgeAreaEntity getArea(Long id);

	KnowledgePointEntity getKnowledge(Long id);

	ProcessGroupEntity getGroup(Long id);

	//List<TopicEntity> 
	void importExcel(IOperator user, Long id, List<TopicEntity> topics, boolean cleanold);

	//List<TopicEntity> 
	void importExcel(IOperator user, List<TopicEntity> topics, TopicTypeSetting tts);

	List<ProcessGroupEntity> groups();

	List<ProcessEntity> processes();

	List<KnowledgeAreaEntity> areas();

	List<KnowledgePointEntity> points();
}
