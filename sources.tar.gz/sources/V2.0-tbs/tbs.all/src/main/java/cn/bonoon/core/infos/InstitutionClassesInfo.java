package cn.bonoon.core.infos;

import java.util.ArrayList;
import java.util.List;

import cn.bonoon.entities.ClassesEntity;
import cn.bonoon.entities.TrainingInstitutionEntity;

public class InstitutionClassesInfo {
	//我可以加班的班级
	private List<ClassesEntity> classes;
	//所有的机构
	private List<TrainingInstitutionEntity> institutions;
	//我已经加入的机构
	private final List<Long> joinInstitution = new ArrayList<Long>();
	private final List<Long> applyInstitution = new ArrayList<Long>();
	
	public void addJoin(Long id){
		this.joinInstitution.add(id);
	}
	
	public void addApply(Long id){
		this.applyInstitution.add(id);
	}
	
	public void setClasses(List<ClassesEntity> classes) {
		this.classes = classes;
	}
	
	public void setInstitutions(List<TrainingInstitutionEntity> institutions) {
		this.institutions = institutions;
	}
	
	public boolean hasJoin(Long id){
		return joinInstitution.contains(id);
	}
	
	public boolean hasApply(Long id){
		return applyInstitution.contains(id);
	}
	
	public List<ClassesEntity> getClasses() {
		return classes;
	}
	
	public List<TrainingInstitutionEntity> getInstitutions() {
		return institutions;
	}
}
