package cn.bonoon.core;

import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.kernel.support.services.SearchService;

public interface AnswerService extends SearchService<AnswerEntity>{

}
