package cn.bonoon.core.infos;

import cn.bonoon.entities.DocContentEntity;
import cn.bonoon.kernel.util.StringHelper;

public class DocumentInfo {
	
	private Long id;
	private String name;
	private String share;
	private String employAt;
	private String attrs = "";
	private String content;
	private String path;
	private String userName;
	
	public DocumentInfo(DocContentEntity doc) {
		id = doc.getId();
		name = doc.getName();
		share = doc.isShare() ? "共享" : "私有";
		content = doc.getContent();
		userName = doc.getCreatorName();
		employAt = StringHelper.date2String(doc.getEmployAt());
		path = doc.getPath();
		if(StringHelper.isEmpty(path)){
			path = null;
		}
		if(null != doc.getArea()){
			attrs = "<span title='知识领域'>" + doc.getArea().getName() + "</span>";
		}
		if(null != doc.getGroup()){
			if(!attrs.isEmpty()){
				attrs += "/";
			}
			attrs += "<span title='过程组'>" + doc.getGroup().getName() + "</span>";
		}
		if(null != doc.getProcess()){
			if(!attrs.isEmpty()){
				attrs += "/";
			}
			attrs += "<span title='过程'>" + doc.getProcess().getName() + "</span>";
		}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShare() {
		return share;
	}

	public void setShare(String share) {
		this.share = share;
	}

	public String getEmployAt() {
		return employAt;
	}

	public void setEmployAt(String employAt) {
		this.employAt = employAt;
	}

	public String getAttrs() {
		return attrs;
	}

	public void setAttrs(String attrs) {
		this.attrs = attrs;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}
