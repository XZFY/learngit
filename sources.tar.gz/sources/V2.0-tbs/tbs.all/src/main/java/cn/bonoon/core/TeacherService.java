package cn.bonoon.core;

import cn.bonoon.entities.TeacherEntity;
import cn.bonoon.kernel.support.services.GenericService;

public interface TeacherService extends GenericService<TeacherEntity>{

}
