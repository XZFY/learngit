package cn.bonoon.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.core.configs.TpiConfig;
import cn.bonoon.core.infos.TpiInfo;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.kernel.events.BaseEvent;
import cn.bonoon.kernel.security.LogonUser;

@Controller
@RequestMapping("pmp/tpi")
public class MemberTpiController extends AbstractAssistantController{

	@Override
	protected void init() {
		functionTitle 	= "学习助手-预言家";
		vmName 			= "assistant/tpi";
		menuSelected 	= "tpi";
		super.init();
	}
	
	@Override
	protected String render(HttpServletRequest request, Model model, MemberEntity member, LogonUser user) {
		//生成界面
		TpiConfig tc = new TpiConfig();
		configService.read(new BaseEvent(tc), TpiConfig.class);
		
		TpiInfo ti = assistantService.tpi(user, tc);
		model.addAttribute("render", ti);
		model.addAttribute("helperMessage", "您的预测成绩为：<span style='color:red;'>" + ti.getAverage() + "分</span>");
		return super.render(request, model, member, user);
	}

}
