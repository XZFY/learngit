package cn.bonoon.core;

import java.util.Date;

import cn.bonoon.entities.CurrencyType;
import cn.bonoon.entities.TransactionEntity;
import cn.bonoon.entities.TransactionType;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.support.services.SearchService;

public interface TransactionService extends SearchService<TransactionEntity>{

	void save(LogonUser user, Long id, int amount, boolean deduct, Date transactionAt, TransactionType transactionType, 
			int levelPoints, CurrencyType currencyType, String remark);

}
