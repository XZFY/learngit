package cn.bonoon.services;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.ImportService;
import cn.bonoon.core.infos.TopicTypeSetting;
import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.entities.KnowledgePointEntity;
import cn.bonoon.entities.PagerEntity;
import cn.bonoon.entities.PagerTopicEntity;
import cn.bonoon.entities.PagerType;
import cn.bonoon.entities.ProcessEntity;
import cn.bonoon.entities.ProcessGroupEntity;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.services.ServiceSupport;
import cn.bonoon.kernel.util.MD5Util;

@Service
@Transactional(readOnly = true)
public class ImportServiceImpl extends ServiceSupport implements ImportService	{
	
//	private final String topic_exist = "select count(x) from TopicEntity x where x.code=?";
//	private final String topic_code = "select x from TopicEntity x where x.code=?";
	
	@Override
	@Transactional
	public void importExcel(IOperator user, List<TopicEntity> topics, TopicTypeSetting tts) {
		Date now = new Date();
		Long cid = user.getId();
		long oid = user.toOwnerId();
		String cname = user.getUsername();
//		List<TopicEntity> exsitEntities = new ArrayList<TopicEntity>();
//		if(forcedreplace){
//			for(TopicEntity tp : topics){
//				TopicEntity otp = null;
//				String code = tp.getCode();
//				if(StringHelper.isNotEmpty(code)){
//					otp = __first(TopicEntity.class, topic_code, code);
//				}
//				if(null != otp){
//					exsitEntities.add(tp);
//					otp.setAnswer(tp.getAnswer());
//					otp.setArea(tp.getArea());
//					otp.setCnContent(tp.getCnContent());
//					otp.setCnExplanation(tp.getCnExplanation());
//					otp.setCnOptionA(tp.getCnOptionA());
//					otp.setCnOptionB(tp.getCnOptionB());
//					otp.setCnOptionC(tp.getCnOptionC());
//					otp.setCnOptionD(tp.getCnOptionD());
//					otp.setEnContent(tp.getEnContent());
//					otp.setEnExplanation(tp.getEnExplanation());
//					otp.setEnOptionA(tp.getEnOptionA());
//					otp.setEnOptionB(tp.getEnOptionB());
//					otp.setEnOptionC(tp.getEnOptionC());
//					otp.setEnOptionD(tp.getEnOptionD());
//					otp.setExam(exam);
//					otp.setFree(free);
//					otp.setGroup(tp.getGroup());
//					otp.setKnowledge(tp.getKnowledge());
//					otp.setPraxis(praxis);
//					otp.setProcess(tp.getProcess());
//					otp.setReal(real);
//					otp.setUpdateAt(now);
//					otp.setUpdaterId(cid);
//					otp.setUpdaterName(cname);
//					entityManager.merge(otp);
//				}else{
//					tp.setKey(MD5Util.randomMD5String());
//					tp.setCreateAt(now);
//					tp.setCreatorId(cid);
//					tp.setCreatorName(cname);
//					tp.setOwnerId(oid);
//					tp.setReal(real);
//					tp.setExam(exam);
//					tp.setFree(free);
//					tp.setPraxis(praxis);
//					entityManager.persist(tp);
//				}
//			}
//		}else{
			for(TopicEntity tp : topics){
//				String code = tp.getCode();
//				if(StringHelper.isNotEmpty(code) && __exsit(topic_exist, code)){
//					exsitEntities.add(tp);
//					continue;
//				}
				tp.setKey(MD5Util.randomMD5String());
				tp.setCreateAt(now);
				tp.setCreatorId(cid);
				tp.setCreatorName(cname);
				tp.setOwnerId(oid);
				tts.setting(tp);
//				tp.setReal(real);
//				tp.setExam(exam);
//				tp.setFree(free);
//				tp.setPraxis(praxis);
				entityManager.persist(tp);
			}
//		}
		
//		return exsitEntities;
	}
	
	@Override
	@Transactional
	public void importExcel(IOperator user, Long id, List<TopicEntity> topics, boolean cleanold) {
		Date now = new Date();
		Long cid = user.getId();
		long oid = user.toOwnerId();
		String cname = user.getUsername();
		PagerEntity pager = entityManager.find(PagerEntity.class, id);
		int count;
		if(cleanold){
			__exec("delete PagerTopicEntity where pager.id=?", pager.getId());
			count = 0;
		}else{
			count = pager.getCount();
		}
		PagerType type = pager.getType();
		boolean real = type == PagerType.REAL;
		boolean exam = type == PagerType.EXAMINATION;
//		List<TopicEntity> exsitEntities = new ArrayList<TopicEntity>();
		for(TopicEntity tp : topics){
			PagerTopicEntity tpe = new PagerTopicEntity();
			//TopicEntity otp = null;
			//String code = tp.getCode();
			//if(StringHelper.isNotEmpty(code)){
			//	otp = __first(TopicEntity.class, topic_code, code);
			//}
			//if(null != otp){
			//	tpe.setTopic(otp);
			//	exsitEntities.add(tp);
			//}else{
				tp.setKey(MD5Util.randomMD5String());
				tp.setCreateAt(now);
				tp.setCreatorId(cid);
				tp.setCreatorName(cname);
				tp.setOwnerId(oid);
				tp.setReal(tp.isReal() || real);
				tp.setExam(tp.isExam() || exam);
				entityManager.persist(tp);
				tpe.setTopic(tp);
			//}
			tpe.setPager(pager);
			count++;
			tpe.setOrdinal(count);
			entityManager.persist(tpe);
		}
		pager.setCount(count);
		entityManager.merge(pager);
		
		entityManager.flush();
//		return exsitEntities;
	}

	@Override
	public KnowledgeAreaEntity getArea(Long id) {
		if(null != id){
			return entityManager.find(KnowledgeAreaEntity.class, id);
		}
		return null;
	}

	@Override
	public ProcessGroupEntity getGroup(Long id) {
		if(null != id){
			return entityManager.find(ProcessGroupEntity.class, id);
		}
		return null;
	}

	@Override
	public KnowledgePointEntity getKnowledge(Long id) {
		if(null != id){
			return entityManager.find(KnowledgePointEntity.class, id);
		}
		return null;
	}

	@Override
	public List<ProcessGroupEntity> groups() {
		return __list(ProcessGroupEntity.class, "select x from ProcessGroupEntity x where x.deleted=false");
	}

	@Override
	public List<ProcessEntity> processes() {
		return __list(ProcessEntity.class, "select x from ProcessEntity x where x.deleted=false");
	}

	@Override
	public List<KnowledgeAreaEntity> areas() {
		return __list(KnowledgeAreaEntity.class, "select x from KnowledgeAreaEntity x where x.deleted=false");
	}

	@Override
	public List<KnowledgePointEntity> points() {
		return __list(KnowledgePointEntity.class, "select x from KnowledgePointEntity x where x.deleted=false");
	}
}
