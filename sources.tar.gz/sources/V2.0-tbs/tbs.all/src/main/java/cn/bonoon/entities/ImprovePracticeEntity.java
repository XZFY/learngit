package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

@Entity
@Table(name = "T_IMPROVEPRACTICE")
public class ImprovePracticeEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3525212234801920264L;

	//一般情况下，一个答题结果只需要一次提高练习
	@ManyToOne
	@JoinColumn(name = "R_ANSWER_ID")
	private AnswerEntity answer;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CREATEAT")
	private Date createAt;

	/**
	 * 本次的提高练习是否完成
	 */
	@Column(name = "C_STATUS")
	private int status;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	public AnswerEntity getAnswer() {
		return answer;
	}

	public void setAnswer(AnswerEntity answer) {
		this.answer = answer;
	}
}
