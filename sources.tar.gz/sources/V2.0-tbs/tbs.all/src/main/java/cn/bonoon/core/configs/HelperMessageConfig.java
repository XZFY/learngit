package cn.bonoon.core.configs;

import cn.bonoon.kernel.web.annotations.components.AsNumberBox;
import cn.bonoon.kernel.web.annotations.components.AsSelector;
import cn.bonoon.kernel.web.annotations.components.SelectorOption;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

@FormEditor(headWidth = 140, width = 600)
public class HelperMessageConfig {
	
	//欢迎您访问TestBank题库，小助手将为您提供热情周到的服务，为您解答疑问！
	@PropertyEditor(name = "访客进入网站的欢迎词", value = 0)
	private String message_0;

	//欢迎您进入TestBank免费测区域，您可在这里免费体验我们的做题功能哦！注册后您将能享受到更多的服务！
	@PropertyEditor(name = "进入免费测版块时提示", value = 1)
	private String message_1;

	//亲爱的用户，祝贺您完成N道试题的练习，您是否想要现在注册以使用更强大的功能呢？
	@PropertyEditor(name = "注册提醒", value = 2)
	@PropertyHelper(value = "达到'注册提醒条件N'时，小助手进行注册提醒；条件N请使用'{N}'表示，注意：不包括''号", type = HelperType.WRAP)
	private String message_2;	
	@AsNumberBox
	@PropertyEditor(name = "注册提醒条件N", value = 3, width = 40)
	@PropertyHelper(value = "练习达到N个题目时，小助手会提醒用户进行注册！", type = HelperType.DIRECT)
	private int freeCount;

	//您已注册成功，恭喜您成为了TestBank的注册会员！完善个人信息可以获得积分奖励哦，现在就去填写吧！
	@PropertyEditor(name = "注册成功提示", value = 4)
	private String message_3;

	//您已经成功开通练习/提高/试卷/真题/预言家功能，现在即可开始使用！
	@PropertyEditor(name = "功能开通成功", value = 5)
	@PropertyHelper(value = "具体开通的功能名请使用'{功能}'进行表示；注意：不包括''号", type = HelperType.WRAP)
	private String message_4;

	//抱歉，功能开能失败，您的积分未达到开通标准（您的账户余额不足），请努力提升您的积分等级（请先去充值）吧！
	@PropertyEditor(name = "功能开通失败", value = 6)
	@PropertyHelper(value = "具体开通的功能名请使用'{功能}'进行表示；注意：不包括''号", type = HelperType.WRAP)
	private String message_5;

	//亲爱的【用户名】，欢迎您回到TestBank！【小助手昵称】一直在等您呢！
	@PropertyEditor(name = "登录提示", value = 7)
	@PropertyHelper(value = "用户名使用'{用户名}'、小助手昵称使用'{小助手}'代替；注意：不包括''号", type = HelperType.WRAP)
	private String message_6;

	//亲爱的【用户名】，恭喜您做题积分达到【用户等级分】，晋升成TestBank的资深会员/大师会员/VIP大师啦！
	@PropertyEditor(name = "等级晋升提示", value = 8)
	@PropertyHelper(value = "用户名使用'{用户名}'、等级分使用'{等级分}'、等级名称使用'{等级名}'代替；注意：不包括''号", type = HelperType.WRAP)
	private String message_7;

	//太棒了！亲爱的【用户名】，您最近的成绩进步很大，您的考力比上一次提高了N分。
	@PropertyEditor(name = "成绩进步提示", value = 9)
	@PropertyHelper(value = "用户名使用'{用户名}'、分数使用'{分数}'代替；注意：不包括''号", type = HelperType.WRAP)
	private String message_8;

	//亲爱的【用户名】，您已经是TestBank的资深会员/大师会员/VIP大师，只要充值X元就可开通【相应功能】，您现在是否去要充值呢？
	@PropertyEditor(name = "定期充值提醒", value = 10)
	@PropertyHelper(value = "用户名使用'{用户名}'、等级名称使用'{等级名}'、功能名使用'{功能}'、金额使用'{金额}'代替；注意：不包括''号", type = HelperType.WRAP)
	private String message_9;
	@PropertyEditor(name = "充值提醒类型", value = 11, width = 130)
	@PropertyHelper(value = "在什么情况下进行充值的提醒", type = HelperType.DIRECT)
	@AsSelector({
		@SelectorOption("不提示"),
		@SelectorOption("登录时"),
		@SelectorOption("每次请求"),
		@SelectorOption("每半小时后"),
		@SelectorOption("每小时后")
	})
	private String rechargeTips;

	//亲爱的【用户名】，感谢您对TestBank的支持，您充值的金币/钻石已到账，请查收吧！
	@PropertyEditor(name = "充值成功提示", value = 21)
	@PropertyHelper(value = "用户名使用'{用户名}'代替；注意：不包括''号", type = HelperType.WRAP)
	private String message_10;

	//亲爱的【用户名】，您介绍过来的好友【A】已经注册了哦！为了感谢您的信任支持，TestBank给您赠送了150积分，请查收吧！
	@PropertyEditor(name = "拉人成功提示", value = 22)
	@PropertyHelper(value = "用户名使用'{用户名}'、好友名使用'{好友}'、赠送积分使用'{积分}'代替；注意：不包括''号", type = HelperType.WRAP)
	private String message_11;

	//亲爱的【用户名】，感谢您赋予我新的名字/形象！【小助手昵称】以后会一直为您服务哦！
	@PropertyEditor(name = "小助手信息修改提示", value = 23)
	@PropertyHelper(value = "用户名使用'{用户名}'、小助手昵称使用'{小助手}'代替；注意：不包括''号", type = HelperType.WRAP)
	private String message_12;

	public String getMessage_0() {
		return message_0;
	}

	public void setMessage_0(String message_0) {
		this.message_0 = message_0;
	}

	public String getMessage_1() {
		return message_1;
	}

	public void setMessage_1(String message_1) {
		this.message_1 = message_1;
	}

	public String getMessage_2() {
		return message_2;
	}

	public void setMessage_2(String message_2) {
		this.message_2 = message_2;
	}

	public int getFreeCount() {
		return freeCount;
	}

	public void setFreeCount(int freeCount) {
		this.freeCount = freeCount;
	}

	public String getMessage_3() {
		return message_3;
	}

	public void setMessage_3(String message_3) {
		this.message_3 = message_3;
	}

	public String getMessage_4() {
		return message_4;
	}

	public void setMessage_4(String message_4) {
		this.message_4 = message_4;
	}

	public String getMessage_5() {
		return message_5;
	}

	public void setMessage_5(String message_5) {
		this.message_5 = message_5;
	}

	public String getMessage_6() {
		return message_6;
	}

	public void setMessage_6(String message_6) {
		this.message_6 = message_6;
	}

	public String getMessage_7() {
		return message_7;
	}

	public void setMessage_7(String message_7) {
		this.message_7 = message_7;
	}

	public String getMessage_8() {
		return message_8;
	}

	public void setMessage_8(String message_8) {
		this.message_8 = message_8;
	}

	public String getMessage_9() {
		return message_9;
	}

	public void setMessage_9(String message_9) {
		this.message_9 = message_9;
	}

	public String getRechargeTips() {
		return rechargeTips;
	}

	public void setRechargeTips(String rechargeTips) {
		this.rechargeTips = rechargeTips;
	}

	public String getMessage_10() {
		return message_10;
	}

	public void setMessage_10(String message_10) {
		this.message_10 = message_10;
	}

	public String getMessage_11() {
		return message_11;
	}

	public void setMessage_11(String message_11) {
		this.message_11 = message_11;
	}

	public String getMessage_12() {
		return message_12;
	}

	public void setMessage_12(String message_12) {
		this.message_12 = message_12;
	}
}
