package cn.bonoon.controllers.topic;

import java.util.Date;

import cn.bonoon.kernel.query.PageCondition;
import cn.bonoon.kernel.web.annotations.condition.ConditionContent;

public class TopicCondition extends PageCondition implements TopicDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1323779366091173962L;

	@ConditionContent(value = "内容", ordinal = 0)
	private String searchCnContent;
	
	@ConditionContent(value = "时间 从", ordinal = 1)
	private Date searchStartAt;
	
	@ConditionContent("到")
	private Date searchEndAt;

	public Date getSearchStartAt() {
		return searchStartAt;
	}

	public void setSearchStartAt(Date searchStartAt) {
		this.searchStartAt = searchStartAt;
	}

	public Date getSearchEndAt() {
		return searchEndAt;
	}

	public void setSearchEndAt(Date searchEndAt) {
		this.searchEndAt = searchEndAt;
	}

	public String getSearchCnContent() {
		return searchCnContent;
	}

	public void setSearchCnContent(String searchCnContent) {
		this.searchCnContent = searchCnContent;
	}
}
