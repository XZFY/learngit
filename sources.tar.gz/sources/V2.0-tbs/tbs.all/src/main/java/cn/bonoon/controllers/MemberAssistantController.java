package cn.bonoon.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.entities.MemberEntity;
import cn.bonoon.kernel.security.LogonUser;

@Controller
@RequestMapping("pmp/assistant")
public class MemberAssistantController extends AbstractAssistantController{
	
//	@Autowired
//	private CapabilityEvaluationService capabilityEvaluationService;
//	
//	@RequestMapping(value = "index.do", method = RequestMethod.GET)
//	public String get(Model model){
//		LogonUser user = getUser();
//		FunctionMappingEntity fm = funMapping(model, user);
//		if(!fm.isExamOpened()){
//			return "redirect:" + toUrl("/pmp/pager/index.do");
//		}
//		MemberEntity member = fm.getMember();
//		evaluationConfig(model);
//		config(model, member);
//		//如果是通过路径直接访问的，则。。。。
//		//加载所有的真真题，并显示哪些是已经购买的
//		__setting(model, member);
//		
//		return __setting(model);
//	}
//
//	@RequestMapping(value = "evaluate.do", method = RequestMethod.GET)
//	public String evaluate(Model model){
//		LogonUser user = getUser();
//		FunctionMappingEntity fm = funMapping(model, user);
//		if(!fm.isExamOpened()){
//			return "redirect:" + toUrl("/pmp/pager/index.do");
//		}
//		MemberEntity member = fm.getMember();
//		config(model, member);
//		try{
//			EvaluationConfig cfg = evaluationConfig(model);
//			List<CapabilityEvaluationEntity> items = capabilityEvaluationService.evaluate(member, cfg);
//			__setting(model, items);
//		}catch(Exception ex){
//			model.addAttribute("errorMsg", ex.getMessage());
//			__setting(model, member);
//		}
//		return __setting(model);
//	}
//	
//	private void __setting(Model model, MemberEntity member) {
//		List<CapabilityEvaluationEntity> items = capabilityEvaluationService.evaluations(member);
//		if(!items.isEmpty()){
//			__setting(model, items);
//		}
//	}
////
//	protected void __setting(Model model, List<CapabilityEvaluationEntity> items) {
//		//最后一次进行的个人能力评估
//		CapabilityEvaluationEntity cee = items.get(0);
//		List<EvaluationItemInfo> eiis = capabilityEvaluationService.evaluation(cee);
//		int size = eiis.size();
//		if(size > 0){
//			model.addAttribute("esi", new EvaluationStatisticsInfo(cee, size));
//			model.addAttribute("eiis", eiis);
//		}
//		model.addAttribute("items", items);
//	}
//	
//	private String __setting(Model model){
//		model.addAttribute("layout", "master.vm");
//		model.addAttribute("mainMenu", "menus/menu-pager.vm");
//		model.addAttribute("channelSelected", "pager");
//		model.addAttribute("menuSelected", "assistant");
//		model.addAttribute("sysTitle", "考试-助手");
//		return "assistant";
//	}

//	private EvaluationConfig evaluationConfig(Model model){
//		EvaluationConfig ec = new EvaluationConfig();
//		try{
//			configService.read(new BaseEvent(ec), EvaluationConfig.class);
//			model.addAttribute("cfg", ec);
//		}catch(Exception ex){ }
//		return ec;
//	}
	private String[] paths;
	@Override
	protected void init() {
		functionTitle 	= "学习助手-考力计";
		vmName 			= "assistant/forcetor";
		menuSelected 	= "forcetor";
		super.init();
		paths = new String[3];
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		super.afterPropertiesSet();
		paths[0] = toUrl("/r/images/tpi-up.png");
		paths[1] = toUrl("/r/images/tpi-down.png");
		paths[2] = toUrl("/r/images/tpi-line.png");
	}
	
	@Override
	protected String render(HttpServletRequest request, Model model, MemberEntity member, LogonUser user) {
		//生成界面
		model.addAttribute("render", assistantService.forcetor(user, paths));
		return super.render(request, model, member, user);
	}
}
