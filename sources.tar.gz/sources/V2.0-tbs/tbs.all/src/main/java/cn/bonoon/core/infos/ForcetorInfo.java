package cn.bonoon.core.infos;

import java.util.List;

import cn.bonoon.entities.AnswerStatisticsItem;
import cn.bonoon.entities.BaseEntity;
import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.entities.ProcessGroupEntity;

public class ForcetorInfo {
	public ForcetorInfo(
			List<AnswerStatisticsItem> aas,
			List<KnowledgeAreaEntity> aes,
			List<AnswerStatisticsItem> gas,
			List<ProcessGroupEntity> ges, 
			String[] paths) {
		parse(aes, aas, area, paths);
		parse(ges, gas, group, paths);
	}
	
	private void parse(List<? extends BaseEntity> bes, List<AnswerStatisticsItem> asis, StringBuilder sb, String[] paths){
		for(BaseEntity pe : bes){
			sb.append("<tr><td style='width:180px;text-align:right;'>").append(pe.getName()).append("</td><td style='width:80px;text-align:left;'");
			AnswerStatisticsItem ai = find(asis, pe);
			if(null != ai){
				int sc = ai.getRight() * 100 / ai.getTotal();
				sb.append(" title='总题目：").append(ai.getTotal()).append("/正确：").append(ai.getRight()).append("'><span style='padding:0 15px 0 15px;'>=</span>").append(sc).append("分</td><td style='text-align:left;'><img src='");
				if(sc >= 75){
					sb.append(paths[0]).append("' title='非常好' alt='非常好");
				}else if(sc < 60){
					sb.append(paths[1]).append("' title='还需要努力' alt='还需要努力");
				}else{
					sb.append(paths[2]).append("' title='要保持' alt='要保持");
				}
				sb.append("'/>");
			}else{
				sb.append(" title='没有相关统计数据！'><span style='color:red;padding-left:40px;'>-</span></td><td>");
			}
			sb.append("</td></tr>");
		}
	}
	
	private AnswerStatisticsItem find(List<AnswerStatisticsItem> as, BaseEntity be){
		for(AnswerStatisticsItem ai : as){
			if(ai.getTid().equals(be.getId())){
				return ai;
			}
		}
		return null;
	}
	
	private final StringBuilder area = new StringBuilder(), group = new StringBuilder();
	
	public StringBuilder getArea() {
		return area;
	}
	
	public StringBuilder getGroup() {
		return group;
	}
}
