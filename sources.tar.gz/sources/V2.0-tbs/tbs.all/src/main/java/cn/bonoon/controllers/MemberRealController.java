package cn.bonoon.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.core.configs.PracticeConfig;
import cn.bonoon.core.infos.RedeemInfo;
import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.PagerEntity;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.support.models.Page;

/**
 * 真题
 * @author jackson
 *
 */
@Controller
@RequestMapping("pmp/real")
public class MemberRealController extends AbstractPagerController{

	@Override
	protected void init() {
		functionTitle 	= "考试-真题";
		vmName 			= "practices/pager";
		super.init();
	}

	@Override
	protected String render(HttpServletRequest request, Model model, MemberEntity member, LogonUser user) {
		model.addAttribute("menuSelected", "real");
//		String name = request.getParameter("name");

		__paging(model, user);
		
		return super.render(request, model, member, user);
	}
	
	@Override
	protected Page __get(LogonUser user, int pageIndex, int pageSize, String name, String type) {
		return topicService.myReals(user, pageIndex, pageSize, name, type);
	}
	
	@Override
	protected int __size() {
		return __pageSize().getRealSize();
	}

	@Override
	protected PagerEntity trial(Model model){
		model.addAttribute("menuSelected", "real");
		return topicService.trialReal();
	}

	@Override
	protected RedeemInfo __redeem(Long id, int size) {
		return topicService.redeemReal(id, getUser(), size);
	}
//	
//	@RequestMapping(value = "{id}!redeem.do", method = RequestMethod.GET)
//	public String redeem(Model model, @PathVariable("id") Long id){
//		//使用积分进行兑换
//		try{
//			RedeemInfo ri = topicService.redeemReal(id, getUser());
//			model.addAttribute("pagers", ri.getItems());
//			
//			//把钻石和金币的值都改变一下
//			MemberEntity me = ri.getMember();
//			StringBuilder ext = new StringBuilder("<script t ype='text/javascript'>");
//			ext.append("$('.member-available-cash').text(").append(me.getAvailableCash()).append(");");
//			ext.append("$('.member-available-points').text(").append(me.getAvailablePoints()).append(");");
//			ext.append("</script>");
//			model.addAttribute("ext", ext);
//		}catch(Exception ex){
//			loadWarning(model, ex);
//		}
//		model.addAttribute("layout", "layout-empty.vm");
//		return "practices/pager-items";
//	}

	@Override
	protected AnswerEntity start(Long id) {
		return topicService.startReal(getUser(), id);
	}

	@Override
	protected String showProactice(Model model){
		PracticeConfig pc = practiceConfig();
		model.addAttribute("showTopicAnswer", pc.isRealAnswer());
		model.addAttribute("topicComment", pc.isRealComment());
		model.addAttribute("topicStudy", pc.isRealStudy());
		return super.showProactice(model);
	}
	
	@RequestMapping("{pid}/{aid}!start.do")
	public String start(Model model, @PathVariable("pid") Long pid, @PathVariable("aid") Long aid){
		try{
			AnswerEntity ae = topicService.startReal(getUser(), pid, aid);
			__parse(model, ae);
			showHead(model, ae.getName());
		}catch(Exception ex){
			warning(model, ex);
		}
		return showProactice(model);
	}
}
