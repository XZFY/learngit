package cn.bonoon.core;

import cn.bonoon.entities.PagerTopicEntity;
import cn.bonoon.kernel.support.services.OperateService;
import cn.bonoon.kernel.support.services.SearchService;

public interface TopicPagerService extends SearchService<PagerTopicEntity>, OperateService{

}
