package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

@Entity
@Table(name = "T_STUDYING")
public class StudyingEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -235273356835714059L;

	//座位号
	@Column(name = "C_SEATNUMBER")
	private int seatNumber;
	
	@ManyToOne
	@JoinColumn(name = "R_STUDENT_ID")
	private StudentEntity student;

	@ManyToOne
	@JoinColumn(name = "R_CLASSES_ID")
	private ClassesEntity classes;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CREATEAT")
	private Date createAt;

	//状态：未报到、正常、转学或转班
	@Column(name = "C_STATUS")
	private int status;

	public StudentEntity getStudent() {
		return student;
	}

	public void setStudent(StudentEntity student) {
		this.student = student;
	}

	public ClassesEntity getClasses() {
		return classes;
	}

	public void setClasses(ClassesEntity classes) {
		this.classes = classes;
	}

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}
}
