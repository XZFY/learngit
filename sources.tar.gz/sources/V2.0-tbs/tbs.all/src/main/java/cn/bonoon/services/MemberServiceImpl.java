package cn.bonoon.services;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.ILoginEditor;
import cn.bonoon.core.MemberService;
import cn.bonoon.core.configs.AccountSettingConfig;
import cn.bonoon.core.configs.CashExchangeConfig;
import cn.bonoon.core.configs.HelperMessageConfig;
import cn.bonoon.entities.CurrencyType;
import cn.bonoon.entities.ExchangeEntity;
import cn.bonoon.entities.HelperMessageEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.MemberGradeEntity;
import cn.bonoon.entities.MemberSettingEntity;
import cn.bonoon.entities.RechargeEntity;
import cn.bonoon.entities.TransactionEntity;
import cn.bonoon.entities.TransactionType;
import cn.bonoon.entities.plugins.FlagType;
import cn.bonoon.entities.plugins.PlaceEntity;
import cn.bonoon.entities.plugins.Sex;
import cn.bonoon.kernel.events.OperateEvent;
import cn.bonoon.kernel.io.FileInfo;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.PasswordVerifier;
import cn.bonoon.kernel.support.services.AbstractService;
import cn.bonoon.kernel.util.MD5Util;
import cn.bonoon.kernel.util.StringHelper;
import cn.bonoon.kernel.web.ConfigManager;

@Service
@Transactional(readOnly = true)
public class MemberServiceImpl extends AbstractService<MemberEntity> implements MemberService{
	private final PasswordVerifier passwordVerifier;

	private ConfigManager configManager;
	
	@Autowired
	public MemberServiceImpl(PasswordVerifier passwordVerifier){
		this.passwordVerifier = passwordVerifier;
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		super.afterPropertiesSet();
		configManager = ConfigManager.getManager();
	}
	
	@Override
	public boolean hasMember(String key) {
		return __exsit("select count(x) from MemberEntity x where x.deleted=false and x.key=?", key);
	}
	
	@Override
	public MemberGradeEntity next(MemberGradeEntity mge) {		
		String ql = "select x from MemberGradeEntity x where x.pointsLine>? and x.id<>? order by x.pointsLine asc";
		return __first(MemberGradeEntity.class, ql, mge.getPointsLine(), mge.getId());
	}
	
	@Override
	@Transactional
	public MemberGradeEntity getGrade(MemberEntity member) {
		if(null == member){
			return null;
		}
		MemberGradeEntity mge = __first(MemberGradeEntity.class, "select x from MemberGradeEntity x where x.pointsLine<=? order by x.pointsLine desc", member.getLevelPoints());
		if(null != mge){
			member.setGrade(mge.getId());
			entityManager.merge(member);
		}
		return mge;
	}
	
	@Override
	public List<MemberEntity> myIntroduces(String my) {
		return __list(MemberEntity.class, "select x from MemberEntity x where x.deleted=false and x.introducer=?", my);
	}
	
	@Override
	@Transactional
	public MemberSettingEntity getFunctionMapping(IOperator user) {
		MemberSettingEntity fme = __first(MemberSettingEntity.class, "select x from MemberSettingEntity x where x.member.id=?", user.getId());
		if(null == fme){
			fme = new MemberSettingEntity();
			fme.setMember(entityManager.find(MemberEntity.class, user.getId()));
			entityManager.persist(fme);
		}
		return fme;
	}
	
	@Override
	@Transactional
	public void update(MemberSettingEntity fm) {
		entityManager.merge(fm);
	}
	
	@Override
	@Transactional
	public void update(MemberSettingEntity fm, Date now, int cost, boolean costCash, String remark) {
		MemberEntity member = fm.getMember();
		
		TransactionEntity tpe = new TransactionEntity();
		tpe.setCreateAt(now);
		tpe.setDeduct(true);
		tpe.setTransactionType(TransactionType.DEDUCT);
		tpe.setRemark(remark);
		tpe.setUserId(member.getId());
		tpe.setAmount(cost);
		
		if(costCash){
			long ac = member.getAvailableCash() - cost;
			member.setAvailableCash(ac);
			tpe.setAvailable(ac);
			tpe.setTotal(member.getTotalCash());
			tpe.setCurrencyType(CurrencyType.DIAMOND);
		}else{
			long ap = member.getAvailablePoints() - cost;
			member.setAvailablePoints(ap);
			tpe.setAvailable(ap);
			tpe.setTotal(member.getTotalPoints());
			tpe.setCurrencyType(CurrencyType.POINTS);
		}
		
		entityManager.merge(fm);
		entityManager.merge(member);
		entityManager.persist(tpe);
	}
	
	@Override
	@Transactional
	public void register(String loginName, String userName, String loginPassword, String confirmPassword, String introducekey){
		if(StringHelper.isEmpty(loginName) || loginName.length() < 3){
			throw new RuntimeException("登录名不正确！");
		}
		if(__exsit("select count(x) from MemberEntity x where x.loginName=?", loginName)){
			throw new RuntimeException("登录名已经存在！");
		}
		Date now = new Date();
		MemberEntity member = new MemberEntity();
		member.setLoginName(loginName);
		
		member.setName(userName);
		member.setCreateAt(now);
		member.setCreatorId(0L);
		member.setOwnerId(0);
		
		AccountSettingConfig apc = __member(member, loginName, loginPassword, confirmPassword);
		
		HelperMessageConfig hmc = __message();
		if(StringHelper.isNotEmpty(introducekey)){
			//有介绍人的情况
			MemberEntity introducer = __first(MemberEntity.class, "select x from MemberEntity x where x.key=?", introducekey);
			if(null != introducer){
				member.setIntroducer(introducekey);
				int introducePoints = apc.getIntroducePoints();
				if(introducePoints > 0){
					__points(introducer, introducePoints, "介绍送积分", now);
					entityManager.merge(introducer);
					String content = hmc.getMessage_11();
					if(StringHelper.isNotEmpty(content)){
						content = content.replace("{用户名}", introducer.getName());
						content = content.replace("{好友}", member.getName());
						content = content.replace("{积分}", String.valueOf(introducePoints));
						HelperMessageEntity hm1 = new HelperMessageEntity();
						hm1.setContent(content);
						hm1.setCreateAt(now);
						hm1.setMember(introducer);
						entityManager.persist(hm1);
					}
				}
			}
		}
		
		entityManager.persist(member);
		//注册成功，给一定的积分，再扣回一定有积分
		if(StringHelper.isNotEmpty(hmc.getMessage_3())){
			HelperMessageEntity hm1 = new HelperMessageEntity();
			hm1.setContent(hmc.getMessage_3());
			hm1.setCreateAt(now);
			hm1.setMember(member);
			entityManager.persist(hm1);
		}
	}
	
	@Override
	@Transactional
	public List<String> tips(MemberEntity member) {
		String ql = "select x.content from HelperMessageEntity x where x.member.id=? and x.read=false order by x.createAt desc";
		List<String> ts = entityManager.createQuery(ql, String.class).setParameter(1, member.getId()).getResultList();
		entityManager.createNativeQuery("update T_HELPERMESSAGE set C_READ=1 where R_MEMBER_ID=?").setParameter(1, member.getId()).executeUpdate();
		return ts;
	}
	
	private HelperMessageConfig __message(){
		HelperMessageConfig hmc = new HelperMessageConfig();
		try{
			configManager.read(applicationContext, entityManager, hmc);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return hmc;
	}
	
	private AccountSettingConfig __config(){
		AccountSettingConfig apc = new AccountSettingConfig();
		try{
			configManager.read(applicationContext, entityManager, apc);
		}catch(Exception ex){ }
		return apc;
	}
	
	private AccountSettingConfig __member(MemberEntity member, String loginName, String loginPassword, String confirmPassword){
		passwordVerifier.setLoginName(member, loginName);
		passwordVerifier.setPassword(member, loginPassword, confirmPassword);

		AccountSettingConfig apc = __config();
		
		int registerPoints = apc.getRegisterPoints();
		
		member.setFlag(FlagType.CUSTOM);
		member.setStatus(MemberEntity.NORMAL);
		member.setKey(MD5Util.randomMD5String());
		if(registerPoints > 0){
			//积分增加的记录
			__points(member, registerPoints, "注册送积分", member.getCreateAt());
		}
		return apc;
	}
	
	private void __points(MemberEntity member, int points, String remark, Date now){
		TransactionEntity tpe = new TransactionEntity();
		tpe.setUserId(member.getId());
		tpe.setCreateAt(now);
		tpe.setTransactionAt(now);
		tpe.setDeduct(false);
		tpe.setCurrencyType(CurrencyType.POINTS);
		tpe.setTransactionType(TransactionType.INCREASE);
		tpe.setRemark(remark);
		
		tpe.setAmount(points);
		long lp = member.getLevelPoints() + points;
		long tp = member.getTotalPoints() + points;
		long ap = member.getAvailablePoints() + points;
		tpe.setTotal(tp);
		tpe.setAvailable(ap);
		tpe.setLevelPoints(points);
		
		member.setLevelPoints(lp);
		member.setTotalPoints(tp);
		member.setAvailablePoints(ap);
		
		entityManager.persist(tpe);
	}
	
	@Override
	protected MemberEntity __save(OperateEvent event, MemberEntity entity) {
		ILoginEditor pe = (ILoginEditor)event.getSource();
//		entity.setLoginName(pe.getLoginName());
//		passwordVerifier.set(entity, pe);
		
		__member(entity, pe.getLoginName(), pe.getLoginPwd(), pe.getConfimPwd());
		
		return super.__save(event, entity);
	}

	@Override
	@Transactional
	public MemberEntity loginSuccess(IOperator user) {
		MemberEntity me = entityManager.find(MemberEntity.class, user.getId());
		if(null != me){
			//当前登录的账号是会员账号
			if(null == me.getLastLogonAt()){
				//表示第一次登录，给积分
				_loginPoints(me);
			}else{
				long t1 = me.getCurrentLogonAt().getTime() / (1000 * 60 * 60 * 24);
				long t2 = me.getLastLogonAt().getTime() / (1000 * 60 * 60 * 24);
				//如果相同，则表示同一天  8169  -- 
				if(t1 != t2){
					_loginPoints(me);
				}
			}
		}
		return me;
	}
	
	private void _loginPoints(MemberEntity me){
		AccountSettingConfig apc = __config();
		int lp = apc.getLoginPoints();
		if(lp > 0){
			__points(me, lp, "每天登录积分", new Date());
			entityManager.merge(me);
		}
	}
	
	@Override
	@Transactional
	public MemberEntity update(Long id, String name, Sex sex, Long place,
			String introduction, String phone, String homeTel, String qq,
			String email, String homeAddress, String companyName,
			String companyTel, String companyAddress, String trainingOrg, String remark, FileInfo fi) {
		MemberEntity me = entityManager.find(MemberEntity.class, id);
		String ql = "select x from MemberSettingEntity x where x.member.id=?";
		MemberSettingEntity mse = __first(MemberSettingEntity.class, ql, id);
		if(null == mse){
			mse = new MemberSettingEntity();
			entityManager.persist(mse);
		}
		PlaceEntity pe = null;
		if(null != place && place > 0){
			pe = entityManager.find(PlaceEntity.class, place);
		}
		me.setName(name);
		me.setSex(sex);
		Date now = new Date();
		int points = 0;
		String pointDes = "";
		AccountSettingConfig asi = __config();
		if(!mse.isHasPhone() && StringHelper.isNotEmpty(phone)){
			mse.setHasPhone(true);
			points = asi.getFinshPhonePoints();
			pointDes = "手机[" + asi.getFinshPhonePoints() + "],";
		}
		if(!mse.isHasEmail() && StringHelper.isNotEmpty(phone)){
			mse.setHasEmail(true);
			points += asi.getFinshEmailPoints();
			pointDes += "电子邮箱[" + asi.getFinshEmailPoints() + "],";
		}
		if(!mse.isHasPlace() && null != pe){
			mse.setHasPlace(true);
			points += asi.getFinshPlacePoints();
			pointDes += "地区[" + asi.getFinshPlacePoints() + "],";
		}
		if(!mse.isHasCompany() && StringHelper.isNotEmpty(companyName)){
			//增加积分
			mse.setHasCompany(true);
			points += asi.getFinshCompanyPoints();
			pointDes += "公司信息[" + asi.getFinshCompanyPoints() + "],";
		}
		if(!mse.isHasInstitution() && StringHelper.isNotEmpty(trainingOrg)){
			mse.setHasInstitution(true);
			points += asi.getFinshInstitiutionPoints();
			pointDes += "培训机构[" + asi.getFinshInstitiutionPoints() + "],";
		}
		if(!mse.isHasIntroduction() && StringHelper.isNotEmpty(introduction)){
			mse.setHasIntroduction(true);
			points += asi.getFinshIntroductionPoints();
			pointDes += "个人简介[" + asi.getFinshIntroductionPoints() + "],";
		}
//		if(!me.isFinish()
//				&&StringHelper.isNotEmpty(companyName) 
//				&& StringHelper.isNotEmpty(email)
//				&& StringHelper.isNotEmpty(homeAddress)
//				&& StringHelper.isNotEmpty(phone)
//				&& null != place && place > 0){
//			//需要计算积分，是否完成看几个主要关键的数据项：公司名、个人地址、地区、手机、email
//			me.setFinish(true);
//			//增加积分
//			int points = .getCompletePoints();
//		}
		if(points > 0){
			__points(me, points, "完善个人信息积分奖励：" + pointDes, now);
		}
		me.setPlace(pe);
		me.setCompanyTel(companyTel);
		me.setCompanyAddress(companyAddress);
		me.setCompanyName(companyName);
		
		me.setEmail(email);
		me.setHomeAddress(homeAddress);
		me.setHomeTel(homeTel);
		me.setIntroduction(introduction);
		me.setPhone(phone);
		me.setQq(qq);
		me.setTrainingOrg(trainingOrg);
		
		me.setRemark(remark);
		me.setUpdateAt(now);
		me.setUpdaterId(id);
		me.setUpdaterName(me.getLoginName());
		if(null != fi){
			me.setPic(fi.getRelativePath());
		}
		entityManager.merge(mse);
		//以下是可用于检测是否进行积分的项
		return me;
	}

	@Override
	public MemberEntity getMember(IOperator user) {
		return __get(user.getId());
	}

	@Override
	@Transactional
	public void saveRecharge(RechargeEntity entity) {
		entityManager.persist(entity);
	}
	
	@Override
	@Transactional
	public void updateRecharge(RechargeEntity entity, CashExchangeConfig config) {
		// TODO 如果是充值成功，则需要进行积分奖励等
		//充值成功了这么多的钱，这个用来兑换钻石
		double oamount = entity.getOrderAmount();
		//到账的钱，可能使用优惠券、代金券等，这个用来计算等级积分
		double pamount = entity.getPayAmount();
		
		int bonus = config.bonus().parseBonus(oamount);
		MemberEntity member = entity.getMember();
		long addlp = (long)(pamount * config.getCashPoints());
		long addcash = (long)((oamount + bonus) * config.getCashRate());
		long addap = (long)(oamount * config.getAvailablePoints());
		member.setAvailableCash(member.getAvailableCash() + addcash);
		member.setTotalCash(member.getTotalCash() + addcash);
		member.setLevelPoints(member.getLevelPoints() + addlp);
		member.setAvailablePoints(member.getAvailablePoints() + addap);
		member.setTotalPoints(member.getTotalPoints() + addap);
		entityManager.merge(member);
		entityManager.merge(entity);
	}

	@Override
	public <R extends RechargeEntity> R getRecharge(String oid, Class<R> entityClass) {
		String ql = "select x from " + entityClass.getName() + " x where x.orderId=?";
		return __first(entityClass, ql, oid);
	}

	@Override
	@Transactional
	public void saveExchange(MemberEntity member, ExchangeEntity ee) {
		entityManager.merge(member);
		entityManager.merge(ee);
	}
	
	@Override
	public MemberEntity get(String loginName) {
		String ql = "select x from MemberEntity x where x.loginName=?";
		return __single(MemberEntity.class, ql, loginName);
	}
	
	@Override
	@Transactional
	public void update(MemberEntity member, String pwd) {
		member.setLoginPwd(passwordVerifier.encodePassword(pwd));
		entityManager.merge(member);
	}
}
