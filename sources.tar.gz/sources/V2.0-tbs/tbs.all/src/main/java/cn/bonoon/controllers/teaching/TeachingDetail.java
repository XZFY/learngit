package cn.bonoon.controllers.teaching;

import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.web.annotations.form.FormDetail;
import cn.bonoon.kernel.web.annotations.form.PropertyDetail;

@FormDetail
public class TeachingDetail implements TeachingDefine{

	@PropertyDetail(0)
	@TransformField("teacher.name")
	private String teacher;

	@PropertyDetail(10)
	@TransformField("classes.name")
	private Long classes;
	
	@PropertyDetail(11)
	private String status;

	@PropertyDetail(20)
	private String courseName;

	@PropertyDetail(30)
	private String remark;

	public String getTeacher() {
		return teacher;
	}

	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}

	public Long getClasses() {
		return classes;
	}

	public void setClasses(Long classes) {
		this.classes = classes;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
