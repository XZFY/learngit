package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.entities.plugins.AccountEntity;

@Entity
@Table(name = "T_TEACHER")
public class TeacherEntity extends AccountEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4153326520198061805L;

	public TeacherEntity(){
		this.typeName = "教师";
	}

	@Column(name = "C_COURSENAMES")
	private String courseNames;
//
//	@ManyToOne
//	@JoinColumn(name = "R_INSTITUTION_ID")
//	private TrainingInstitutionEntity institution;

	//教师简介
	@Column(name = "C_INTRODUCTION", columnDefinition="TEXT")
	@Basic(fetch = FetchType.LAZY)
	private String introduction;
	
	//入职时间
	@Temporal(TemporalType.DATE)
	@Column(name = "C_ENTRYAT")
	private Date entryAt;

	@Column(name = "C_TEL")
	private String tel;

	@Column(name = "C_PHONE")
	private String phone;

//	public TrainingInstitutionEntity getInstitution() {
//		return institution;
//	}
//
//	public void setInstitution(TrainingInstitutionEntity institution) {
//		this.institution = institution;
//	}

	public String getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

	public Date getEntryAt() {
		return entryAt;
	}

	public void setEntryAt(Date entryAt) {
		this.entryAt = entryAt;
	}

	public String getCourseNames() {
		return courseNames;
	}

	public void setCourseNames(String courseNames) {
		this.courseNames = courseNames;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
}
