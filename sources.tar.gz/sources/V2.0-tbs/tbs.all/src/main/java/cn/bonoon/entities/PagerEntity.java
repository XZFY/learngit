package cn.bonoon.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import cn.bonoon.kernel.support.entities.AbstractEntity;
import cn.bonoon.kernel.support.entities.EntityStatus;

/**
 * 试卷
 * @author jackson
 *
 */
@Entity
@Table(name = "T_PAGER")
public class PagerEntity extends AbstractEntity implements EntityStatus{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4102816168170668516L;

	@Enumerated
	@Column(name = "C_TYPE")
	private PagerType type;
	
	/**
	 * <pre>
	 * 购买该试卷所需要的积分，如果为0则表示不需要积分
	 * 如果是现金购买，则充值的时候把现金转为相应的积分再进行扣除
	 * </pre>
	 */
	@Column(name = "C_AMOUNT")
	private int amount;
	
	@Column(name = "C_DIAMOND")
	private boolean diamond;
	
	/**
	 * 试卷的状态
	 */
	@Column(name = "C_STATUS")
	private int status;
	
	/**
	 * 题目的数量
	 */
	@Column(name = "C_COUNT")
	private int count;
	
	/**
	 * <pre>
	 * 该席卷是否允许试用，如果是，则在未登录或者席卷功能没有开通的情况下，可以进行试用
	 * 普通试卷和真题都允许试用，但一种类型(如：试卷或真题)只允许有一份试用的试卷
	 * 
	 * 如果需要不允许某一份试卷的试用，则可以修改这个属性或者修改席卷的状态太为非正常的状态即可
	 * </pre>
	 */
	@Column(name = "C_TRIAL")
	private boolean trial;

	@Column(name = "C_MAXDIFFICULTY")
	private double maxDifficulty;
	
	@Column(name = "C_MINDIFFICULTY")
	private double minDifficulty;
	
	@Column(name = "C_AVGDIFFICULTY")
	private double avgDifficulty;
	
	@Column(name = "C_TOTALDIFFICULTY")
	private double totalDifficulty;
	
	//对试卷的一些战略信息的统计
	@Column(name = "C_USEDCOUNT")
	private long usedCount;//被做过的次数，即有效完成的次数
	
	@Column(name = "C_MAXSCORE")
	private double maxScore;
	
	@Column(name = "C_MINSCORE")
	private double minScore;
	
	@Column(name = "C_AVGSCORE")
	private double avgScore;//平均得分
	
	@Column(name = "C_TOTALSCORE")
	private double totalScore;
	
	public double getMaxDifficulty() {
		return maxDifficulty;
	}

	public void setMaxDifficulty(double maxDifficulty) {
		this.maxDifficulty = maxDifficulty;
	}

	public double getMinDifficulty() {
		return minDifficulty;
	}

	public void setMinDifficulty(double minDifficulty) {
		this.minDifficulty = minDifficulty;
	}

	public double getAvgDifficulty() {
		return avgDifficulty;
	}

	public void setAvgDifficulty(double avgDifficulty) {
		this.avgDifficulty = avgDifficulty;
	}

	public double getTotalDifficulty() {
		return totalDifficulty;
	}

	public void setTotalDifficulty(double totalDifficulty) {
		this.totalDifficulty = totalDifficulty;
	}

	public long getUsedCount() {
		return usedCount;
	}

	public void setUsedCount(long usedCount) {
		this.usedCount = usedCount;
	}

	public double getMaxScore() {
		return maxScore;
	}

	public void setMaxScore(double maxScore) {
		this.maxScore = maxScore;
	}

	public double getMinScore() {
		return minScore;
	}

	public void setMinScore(double minScore) {
		this.minScore = minScore;
	}

	public double getAvgScore() {
		return avgScore;
	}

	public void setAvgScore(double avgScore) {
		this.avgScore = avgScore;
	}

	public double getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(double totalScore) {
		this.totalScore = totalScore;
	}

	public PagerType getType() {
		return type;
	}
	
	public void setType(PagerType type) {
		this.type = type;
	}
	
//	public int getPoints() {
//		return points;
//	}
//	
//	public void setPoints(int points) {
//		this.points = points;
//	}
	
	public int getStatus() {
		return status;
	}
	
	public void setStatus(int status) {
		this.status = status;
	}
	
	public int getCount() {
		return count;
	}
	
	public void setCount(int count) {
		this.count = count;
	}

	public boolean isTrial() {
		return trial;
	}

	public void setTrial(boolean trial) {
		this.trial = trial;
	}

	public boolean isDiamond() {
		return diamond;
	}

	public void setDiamond(boolean diamond) {
		this.diamond = diamond;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
}
