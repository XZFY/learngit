package cn.bonoon.core.infos;

public abstract class AbstractResult {
	private int total;
	/**
	 * 正确的数量
	 */
	private int right;
	/**
	 * 错误的数量
	 */
	private int wrong;
	/**
	 * 放弃的，没有做的题目数量
	 */
	private int giveUp;
	
	private int score;
	
	public void increaseRight(){
		total++;
		right++;
	}
	
	public void increaseWrong(){
		total++;
		wrong++;
	}
	
	public void increaseGiveUp(){
		total++;
		giveUp++;
	}

	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getRight() {
		return right;
	}
	public void setRight(int right) {
		this.right = right;
	}
	public int getGiveUp() {
		return giveUp;
	}
	public void setGiveUp(int giveUp) {
		this.giveUp = giveUp;
	}
	public int getWrong() {
		return wrong;
	}
	public void setWrong(int wrong) {
		this.wrong = wrong;
	}

	public int getScore() {
		score = right * 100 / total;
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
}
