package cn.bonoon.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.MemberGradeService;
import cn.bonoon.entities.MemberGradeEntity;
import cn.bonoon.kernel.support.services.AbstractService;

@Service
@Transactional(readOnly = true)
public class MemberGradeServiceImpl extends AbstractService<MemberGradeEntity> implements MemberGradeService{

}
