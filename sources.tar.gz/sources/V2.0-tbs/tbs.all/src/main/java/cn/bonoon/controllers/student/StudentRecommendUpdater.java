package cn.bonoon.controllers.student;

import cn.bonoon.core.IStudentRecommend;
import cn.bonoon.entities.ClassesEntity;
import cn.bonoon.kernel.annotations.Transform;
import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.annotations.WriteModel;
import cn.bonoon.kernel.web.annotations.AutoDataLoader;
import cn.bonoon.kernel.web.annotations.components.AsComboBox;
import cn.bonoon.kernel.web.annotations.form.FormUpdate;
import cn.bonoon.kernel.web.annotations.form.PropertyInsert;

@Transform
@FormUpdate(2)
public class StudentRecommendUpdater extends StudentUpdater implements IStudentRecommend{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4507426621274727082L;

	@AsComboBox
	@AutoDataLoader(ClassesEntity.class)
	@TransformField(readable = false, writable = WriteModel.NONE)
	@PropertyInsert(6)
	private Long classes;

	@TransformField(readable = false, writable = WriteModel.NONE)
	@PropertyInsert(6)
	private int seatNumber;

	public Long getClasses() {
		return classes;
	}

	public void setClasses(Long classes) {
		this.classes = classes;
	}

	public int getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}
}
