package cn.bonoon.core.infos;

import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.util.StringHelper;

public class TopicInfo {
	
	private Long id;
	private String key;
	private String content;
	private String optionA;
	private String optionB;
	private String optionC;
	private String optionD;
	private String err;
	private String picture;
	
	public TopicInfo(TopicEntity te, Boolean isen){
		id = te.getId();
		key = te.getKey();
		if(null != isen && isen.booleanValue()){
			content = te.getEnContent();
			if(StringHelper.isEmpty(content)){
				content = te.getCnContent();
				picture = te.getCnPicture();
				optionA = te.getCnOptionA();
				optionB = te.getCnOptionB();
				optionC = te.getCnOptionC();
				optionD = te.getCnOptionD();
				
				err = "本题目没有英文的描述！";
			}else{
				picture = te.getEnPicture();
				optionA = te.getEnOptionA();
				optionB = te.getEnOptionB();
				optionC = te.getEnOptionC();
				optionD = te.getEnOptionD();
			}
		}else{
			content = te.getCnContent();
			picture = te.getCnPicture();
			optionA = te.getCnOptionA();
			optionB = te.getCnOptionB();
			optionC = te.getCnOptionC();
			optionD = te.getCnOptionD();
		}
		if(StringHelper.isEmpty(content)){
			err = "题目有异常，无法继续做题，请关闭做题的界面！";
		}
		if(StringHelper.isEmpty(picture)){
			picture = null;
		}
	}
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getOptionA() {
		return optionA;
	}
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}
	public String getOptionB() {
		return optionB;
	}
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}
	public String getOptionC() {
		return optionC;
	}
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}
	public String getOptionD() {
		return optionD;
	}
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}

	public String getErr() {
		return err;
	}

	public void setErr(String err) {
		this.err = err;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}
	
	
}
