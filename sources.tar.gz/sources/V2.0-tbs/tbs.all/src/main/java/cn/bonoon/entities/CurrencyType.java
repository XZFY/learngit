package cn.bonoon.entities;

public enum CurrencyType {
	POINTS("金币"),
	DIAMOND("钻石"),
	/**
	 * 现金
	 */
	CASH("现金");
	private final String title;
	private CurrencyType(String title){
		this.title = title;
	}
	public String getTitle() {
		return title;
	}
}
