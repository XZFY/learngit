package cn.bonoon.core.infos;

import cn.bonoon.entities.AnswerStatisticsItem;

public class AssistantCell {

	private final Long tid;
	private final String key;
	private final String value;
	
	public AssistantCell(AnswerStatisticsItem asi, boolean percent) {
		tid = asi.getTid();
		key = asi.getType().toKey(tid);
		value = asi.getRight() + "/" + asi.getRight();
	}

	public void render(StringBuilder html){
		html.append(value);
	}

	public String getKey() {
		return key;
	}
}
