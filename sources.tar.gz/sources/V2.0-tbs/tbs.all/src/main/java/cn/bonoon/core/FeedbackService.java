package cn.bonoon.core;

import cn.bonoon.entities.FeedbackEntity;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.services.SearchService;

public interface FeedbackService extends SearchService<FeedbackEntity>{
	void save(IOperator user, String name, String phone, String email, String content);
}
