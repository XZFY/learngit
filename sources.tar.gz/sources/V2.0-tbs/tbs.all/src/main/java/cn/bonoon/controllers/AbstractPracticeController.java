package cn.bonoon.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;

import cn.bonoon.core.PracticeService;
import cn.bonoon.core.configs.PracticeConfig;
import cn.bonoon.core.infos.TopicCollection;
import cn.bonoon.core.infos.TopicItem;
import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.kernel.events.BaseEvent;

/**
 * 可以进行题目练习的都可以继承这个父类
 * @author jackson
 *
 */
public abstract class AbstractPracticeController extends AbstractTrialableController{

	@Autowired
	protected PracticeService topicService;
	
	protected PracticeConfig practiceConfig(){
		PracticeConfig opc = new PracticeConfig();
		configService.read(new BaseEvent(opc), PracticeConfig.class);
		return opc;
	}
	
	protected String showProactice(Model model){
		model.addAttribute("layout", "layout-empty.vm");
		return "practices/panel-topics";
	}
	
	protected void __parse(Model model, AnswerEntity ae){
		TopicCollection pi = new TopicCollection(ae);
		model.addAttribute("topics", pi);
			
		TopicItem item = pi.getItems().get(0);
		
		model.addAttribute("topicNumber", 1);
		model.addAttribute("topic", topicService.topic(item.getKey(), null));
		model.addAttribute("answer", item.getAnswer());
		model.addAttribute("importantMark", item.getImptMark() == '1');
	}
	
	/**
	 * 在弹出做题练习界面时，显示在 panel-topics.vm 模板上面的提示信息
	 * @param model
	 * @param ex
	 */
	protected void warning(Model model, Exception ex){
		model.addAttribute("topicMsg", ex.getMessage());
	}
	
	/**
	 * 在动态加载练习、试卷等list的时候，如果有什么异常的提示信息，则可以通过这个方法通知用户；
	 * 针对 xxx-items.vm 模板里的 warningMsg 提示属性
	 * @param model
	 * @param ex
	 */
	protected void loadWarning(Model model, Exception ex){
		model.addAttribute("warningMsg", ex.getMessage());
	}
	
	/**
	 * 是否在 panel-topics.vm 模板上显示这套练习(试卷等)的台头信息
	 * @param model
	 * @param title
	 */
	protected void showHead(Model model, String title){
		model.addAttribute("showTopicHead", true);
		model.addAttribute("topicTitle", title);
	}
	
//	protected void showHead(Model model, String title, String arg){
//		model.addAttribute("showTopicHead", true);
//		model.addAttribute("topicTitle", "<span style='font-size: 18px; font-family: Arial;padding-left:15px;'>" + title + "</span>" + arg);
//	}
}
