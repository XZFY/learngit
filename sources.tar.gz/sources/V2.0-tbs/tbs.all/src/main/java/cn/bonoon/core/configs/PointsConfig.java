package cn.bonoon.core.configs;

import cn.bonoon.kernel.web.annotations.components.AsCheckbox;
import cn.bonoon.kernel.web.annotations.components.AsNumberBox;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

@FormEditor(value = 2, headWidth = 100, width = 320)
public class PointsConfig {
	
	@AsNumberBox
	@PropertyEditor(name = "真题积分", value = 10, width = 60)
	@PropertyHelper(value = "完成一次真题考试对应的积分", type = HelperType.DIRECT)
	private int realPoints;
	
	@AsCheckbox("是")
	@PropertyEditor(name = "真题百分比", value = 11)
	@PropertyHelper(value = "按得分百分比计算积分", type = HelperType.DIRECT)
	private boolean realPercent;

	@AsNumberBox
	@PropertyEditor(name = "试卷积分", value = 20, width = 60)
	@PropertyHelper(value = "完成一次试卷考试对应的积分", type = HelperType.DIRECT)
	private int pagerPoints;
	
	@AsCheckbox("是")
	@PropertyEditor(name = "试卷百分比", value = 21)
	@PropertyHelper(value = "按得分百分比计算积分", type = HelperType.DIRECT)
	private boolean pagerPercent;

	@AsNumberBox
	@PropertyEditor(name = "练习积分", value = 30, width = 60)
	@PropertyHelper(value = "完成一次练习对应的积分", type = HelperType.DIRECT)
	private int praxisPoints;
	
	@AsCheckbox("是")
	@PropertyEditor(name = "练习百分比", value = 31)
	@PropertyHelper(value = "按得分百分比计算积分", type = HelperType.DIRECT)
	private boolean praxisPercent;

	public int getRealPoints() {
		return realPoints;
	}

	public void setRealPoints(int realPoints) {
		this.realPoints = realPoints;
	}

	public boolean isRealPercent() {
		return realPercent;
	}

	public void setRealPercent(boolean realPercent) {
		this.realPercent = realPercent;
	}

	public int getPagerPoints() {
		return pagerPoints;
	}

	public void setPagerPoints(int pagerPoints) {
		this.pagerPoints = pagerPoints;
	}

	public boolean isPagerPercent() {
		return pagerPercent;
	}

	public void setPagerPercent(boolean pagerPercent) {
		this.pagerPercent = pagerPercent;
	}

	public int getPraxisPoints() {
		return praxisPoints;
	}

	public void setPraxisPoints(int praxisPoints) {
		this.praxisPoints = praxisPoints;
	}

	public boolean isPraxisPercent() {
		return praxisPercent;
	}

	public void setPraxisPercent(boolean praxisPercent) {
		this.praxisPercent = praxisPercent;
	}

}
