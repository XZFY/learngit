package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

/**
 * <pre>
 * 我的试卷，如果没有授权则不能访问该试卷；
 * 如果可以拿到试卷的授权，可以通过购买，也可以通过积分来换取
 * </pre>
 * @author jackson
 *
 */
@Entity
@Table(name = "T_MEMBERPAGER")
public class MemberPagerEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8962211272657209903L;
	
	/**
	 * 会员
	 */
	@ManyToOne
	@JoinColumn(name = "R_MEMBER_ID")
	private MemberEntity member;
	
	/**
	 * 可以访问的试卷
	 */
	@ManyToOne
	@JoinColumn(name = "R_PAGER_ID")
	private PagerEntity pager;
	
	/**
	 * 该授权的过期时间
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "C_EXPIREDAT")
	private Date expiredAt;
	
	/**
	 * 是否长期有效，如果为true则expiredAt属性无效
	 */
	@Column(name = "C_TIMELESS")
	private boolean timeless;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "C_CREATEAT")
	private Date createAt;

	@Column(name = "C_USEDCOUNT")
	private long usedCount;//被做过的次数，即有效完成的次数
	
	@Column(name = "C_MAXSCORE")
	private double maxScore;
	
	@Column(name = "C_MINSCORE")
	private double minScore;
	
	@Column(name = "C_AVGSCORE")
	private double avgScore;//平均得分
	
	@Column(name = "C_TOTALSCORE")
	private double totalScore;
	
	public long getUsedCount() {
		return usedCount;
	}

	public void setUsedCount(long usedCount) {
		this.usedCount = usedCount;
	}

	public double getMaxScore() {
		return maxScore;
	}

	public void setMaxScore(double maxScore) {
		this.maxScore = maxScore;
	}

	public double getMinScore() {
		return minScore;
	}

	public void setMinScore(double minScore) {
		this.minScore = minScore;
	}

	public double getAvgScore() {
		return avgScore;
	}

	public void setAvgScore(double avgScore) {
		this.avgScore = avgScore;
	}

	public double getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(double totalScore) {
		this.totalScore = totalScore;
	}

	public MemberEntity getMember() {
		return member;
	}
	
	public void setMember(MemberEntity member) {
		this.member = member;
	}
	public PagerEntity getPager() {
		return pager;
	}
	public void setPager(PagerEntity pager) {
		this.pager = pager;
	}
	public Date getExpiredAt() {
		return expiredAt;
	}
	public void setExpiredAt(Date expiredAt) {
		this.expiredAt = expiredAt;
	}
	public boolean isTimeless() {
		return timeless;
	}
	public void setTimeless(boolean timeless) {
		this.timeless = timeless;
	}
	public Date getCreateAt() {
		return createAt;
	}
	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}
}
