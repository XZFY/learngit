package cn.bonoon.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.bonoon.core.MediaContentService;
import cn.bonoon.entities.BrowseRecordEntity;
import cn.bonoon.entities.MediaContentEntity;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.util.StringHelper;

@Controller
public class VideoPlayerController extends AbstractConfigurableController {
	
	private static final Map<String, String> supplieds;
	
	static{
		supplieds = new HashMap<>();
		supplieds.put(".m4v", "m4v");
		supplieds.put(".flv", "flv");
		supplieds.put(".fla", "fla");
		supplieds.put(".mp4", "mp4");
		supplieds.put(".asf", "asf");
	}
	
	private final MediaContentService mediaContentService;
	
	@Autowired
	public VideoPlayerController(MediaContentService mediaContentService){
		this.mediaContentService = mediaContentService;
	}
	
	@RequestMapping(value = "pmp/video/{id}!player.do2", method = RequestMethod.GET)
	public String player(Model model, @PathVariable("id") Long id){
		LogonUser user = getUser();
		if(null != user){
			model.addAttribute("layout", "master-frame.vm");
			MediaContentEntity media = mediaContentService.browse(user, id);
			if(null != media){
				return __player(model, media);
			}
		}
		model.addAttribute("layout", "layout-empty.vm");
		model.addAttribute("error", "不允许观看该视频！");
		return "tbs-error";
	}
	
	@RequestMapping(value = "pmp/video/{id}!player.do", method = RequestMethod.GET)
	public String get(Model model, HttpServletRequest request, @PathVariable("id") Long id){
		model.addAttribute("mainMenu", "video-list.vm");
		model.addAttribute("sysTitle", "观看视频");
		model.addAttribute("layout", "master.vm");
		LogonUser user = getUser();
		if(null == user){
			//未登录
			nologinConfig(model, request);
			//不允许看
			
			model.addAttribute("error", "不允许观看该视频！");
			return "tbs-error";
		}else{
			loginConfig(model, request, funMapping(model, user));
//			if(!media.isShare() && !user.getId().equals(media.getCreatorId())){
//				//不允许看
//				return "tbs-error";
//			}
		}
		MediaContentEntity media = mediaContentService.browse(user, id);
		if(null == media){
			//不允许看
			model.addAttribute("error", "不允许观看该视频！");
			return "tbs-error";
		}
		List<BrowseRecordEntity> records = mediaContentService.browseRecords(user, id);
		model.addAttribute("records", records).addAttribute("showSubject", true);
		return __player(model, media);
	}

	private String __player(Model model, MediaContentEntity media) {
		String path = media.getPath();
		String ext = media.getFilesuffix(), supplied = null;
		if(StringHelper.isNotEmpty(ext)){
			supplied = supplieds.get(ext);
		}
		if(null == supplied){
			int p = path.lastIndexOf('.');
			ext = path.substring(p);
			supplied = supplieds.get(ext);
		}
		model.addAttribute("media", media);
		model.addAttribute("supplied", supplied);
		return "video-player";
	}
}
