package cn.bonoon.core;

import java.util.List;

import cn.bonoon.core.configs.EvaluationConfig;
import cn.bonoon.core.infos.EvaluationItemInfo;
import cn.bonoon.entities.CapabilityEvaluationEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.kernel.support.services.SearchService;

public interface CapabilityEvaluationService extends SearchService<CapabilityEvaluationEntity>{

	List<CapabilityEvaluationEntity> evaluations(MemberEntity member);

	List<EvaluationItemInfo> evaluation(CapabilityEvaluationEntity item);

	List<CapabilityEvaluationEntity> evaluate(MemberEntity member, EvaluationConfig config);
}
