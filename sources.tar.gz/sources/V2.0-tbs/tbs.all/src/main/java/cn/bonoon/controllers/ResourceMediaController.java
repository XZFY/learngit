package cn.bonoon.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.kernel.support.models.Page;

@Controller
@RequestMapping("pmp/share/media")
public class ResourceMediaController extends AbstractResourceController{

	@Override
	protected void init() {
		functionTitle 	= "资源库-共享视频";
		vmName 			= "doc/share-video";
		menuSelected 	= "media";
		vmPaging 		= "doc/share-video-page";
		super.init();
	}
	
	@Override
	protected int __size() {
		return __pageSize().getShareVideoSize();
	}
	
	@Override
	protected Page readResource(int pageIndex, int pageSize, String name) {
		return resourceService.shareVideos(pageIndex, pageSize, name);
	}
}
