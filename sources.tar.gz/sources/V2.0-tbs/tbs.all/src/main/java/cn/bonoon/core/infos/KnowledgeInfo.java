package cn.bonoon.core.infos;

import cn.bonoon.entities.ImprovePracticeItem;
import cn.bonoon.entities.KnowledgePointEntity;

public class KnowledgeInfo{
	
	private final KnowledgePointEntity knowledge;
	private int total;
	private int right;
	
	public KnowledgeInfo(KnowledgePointEntity knowledge){
		this.knowledge = knowledge;
	}
	
	public Long getId(){
		return knowledge.getId();
	}
	
	public void answer(String ta, String answer){
		total ++;
		if(ta.equals(answer)){
			right ++;
		}
	}

	public void set(ImprovePracticeItem ip) {
		ip.setTotal(ip.getTotal() + total);
		ip.setRight(ip.getRight() + right);
		int score = right / total;
		ip.setScore(score);
		if(score > ip.getPriority()){
			ip.setPriority(score);
		}
		ip.setFinish(score >= ip.getUpperLimit());
	}
}
