package cn.bonoon.core.configs;

import cn.bonoon.kernel.web.annotations.components.AsNumberBox;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

@FormEditor(value = 2, headWidth = 120, width = 300)
public class AccountSettingConfig {
	
	/**
	 * 主机的地址
	 */
	@PropertyEditor(name = "主机地址", value = 0, colspan = 1, width = 300)
	@PropertyHelper(value = "服务器的地址或IP，如：http://www.server.com", type = HelperType.DIRECT)
	private String address;

	@AsNumberBox
	@PropertyEditor(name = "注册积分", value = 10, width = 80)
	private int registerPoints;
	
	@AsNumberBox
	@PropertyEditor(name = "介绍用户积分", value = 11, width = 80)
	@PropertyHelper(value = "介绍新用户注册的积分奖励", type = HelperType.DIRECT)
	private int introducePoints;

	@AsNumberBox
	@PropertyEditor(name = "登录积分", value = 20, width = 80, colspan = 1)
	@PropertyHelper(value = "每天登录可得积分", type = HelperType.DIRECT)
	private int loginPoints;

	@AsNumberBox
	@PropertyEditor(name = "填写手机积分", value = 30, width = 80)
	@PropertyHelper(value = "完善用户资料可得到的积分", type = HelperType.DIRECT)
	private int finshPhonePoints;

	@AsNumberBox
	@PropertyEditor(name = "填写培训机构积分", value = 31, width = 80)
	@PropertyHelper(value = "完善用户资料可得到的积分", type = HelperType.DIRECT)
	private int finshInstitiutionPoints;

	@AsNumberBox
	@PropertyEditor(name = "填写就职公司积分", value = 40, width = 80)
	@PropertyHelper(value = "完善用户资料可得到的积分", type = HelperType.DIRECT)
	private int finshCompanyPoints;

	@AsNumberBox
	@PropertyEditor(name = "填写电子邮箱积分", value = 41, width = 80)
	@PropertyHelper(value = "完善用户资料可得到的积分", type = HelperType.DIRECT)
	private int finshEmailPoints;

	@AsNumberBox
	@PropertyEditor(name = "填写地区积分", value = 50, width = 80)
	@PropertyHelper(value = "完善用户资料可得到的积分", type = HelperType.DIRECT)
	private int finshPlacePoints;

	@AsNumberBox
	@PropertyEditor(name = "填写个人简介积分", value = 51, width = 80)
	@PropertyHelper(value = "完善用户资料可得到的积分", type = HelperType.DIRECT)
	private int finshIntroductionPoints;
	
	@AsNumberBox
	@PropertyEditor(name = "分享文档积分", value = 60, width = 80)
	@PropertyHelper(value = "分享文档可得到的积分", type = HelperType.DIRECT)
	private int documentPoints;

	@AsNumberBox
	@PropertyEditor(name = "分享视频积分", value = 61, width = 80)
	@PropertyHelper(value = "分享视频可得到的积分", type = HelperType.DIRECT)
	private int videoPoints;

	public int getRegisterPoints() {
		return registerPoints;
	}

	public void setRegisterPoints(int registerPoints) {
		this.registerPoints = registerPoints;
	}

	public int getIntroducePoints() {
		return introducePoints;
	}

	public void setIntroducePoints(int introducePoints) {
		this.introducePoints = introducePoints;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getLoginPoints() {
		return loginPoints;
	}

	public void setLoginPoints(int loginPoints) {
		this.loginPoints = loginPoints;
	}

//	public int getCompletePoints() {
//		return completePoints;
//	}
//
//	public void setCompletePoints(int completePoints) {
//		this.completePoints = completePoints;
//	}

	public int getFinshPhonePoints() {
		return finshPhonePoints;
	}

	public void setFinshPhonePoints(int finshPhonePoints) {
		this.finshPhonePoints = finshPhonePoints;
	}

	public int getFinshInstitiutionPoints() {
		return finshInstitiutionPoints;
	}

	public void setFinshInstitiutionPoints(int finshInstitiutionPoints) {
		this.finshInstitiutionPoints = finshInstitiutionPoints;
	}

	public int getFinshCompanyPoints() {
		return finshCompanyPoints;
	}

	public void setFinshCompanyPoints(int finshCompanyPoints) {
		this.finshCompanyPoints = finshCompanyPoints;
	}

	public int getFinshEmailPoints() {
		return finshEmailPoints;
	}

	public void setFinshEmailPoints(int finshEmailPoints) {
		this.finshEmailPoints = finshEmailPoints;
	}

	public int getFinshPlacePoints() {
		return finshPlacePoints;
	}

	public void setFinshPlacePoints(int finshPlacePoints) {
		this.finshPlacePoints = finshPlacePoints;
	}

	public int getFinshIntroductionPoints() {
		return finshIntroductionPoints;
	}

	public void setFinshIntroductionPoints(int finshIntroductionPoints) {
		this.finshIntroductionPoints = finshIntroductionPoints;
	}

	public int getVideoPoints() {
		return videoPoints;
	}

	public void setVideoPoints(int videoPoints) {
		this.videoPoints = videoPoints;
	}

	public int getDocumentPoints() {
		return documentPoints;
	}

	public void setDocumentPoints(int documentPoints) {
		this.documentPoints = documentPoints;
	}

}
