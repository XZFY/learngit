package cn.bonoon.controllers.teacher;

import cn.bonoon.core.IAccountEditor;
import cn.bonoon.entities.plugins.RoleEntity;
import cn.bonoon.kernel.annotations.Transform;
import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.annotations.Unique;
import cn.bonoon.kernel.annotations.WriteModel;
import cn.bonoon.kernel.util.BoolType;
import cn.bonoon.kernel.web.annotations.AutoDataLoader;
import cn.bonoon.kernel.web.annotations.components.AsComboBox;
import cn.bonoon.kernel.web.annotations.components.AsPassword;
import cn.bonoon.kernel.web.annotations.components.ComboMultipleChecker;
import cn.bonoon.kernel.web.annotations.form.FormInsert;
import cn.bonoon.kernel.web.annotations.form.PropertyInsert;

@Transform
@FormInsert(2)
public class TeacherInserter extends TeacherEditor implements IAccountEditor{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6438640128365559997L;
	
	@TransformField(writable = WriteModel.INSERTONLY)
	@PropertyInsert(required = BoolType.TRUE, value = 0)
	@Unique
	private String loginName;
	
	@TransformField(readable = false, writable = WriteModel.NONE)
	@PropertyInsert(value = 2, name = "密码", required = BoolType.TRUE)
	@AsPassword
	private String loginPwd;
	
	@TransformField(readable = false, writable = WriteModel.NONE)
	@PropertyInsert(value = 3, name = "确认密码", required = BoolType.TRUE)
	@AsPassword
	private String confimPwd;

	@PropertyInsert(name = "角色", value = 4, colspan = 1)
	@ComboMultipleChecker
	@AsComboBox
	@AutoDataLoader(RoleEntity.class)
	private Long[] roles;

	public String getLoginName() {
		return loginName;
	}
	
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	
	public String getLoginPwd() {
		return loginPwd;
	}
	
	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}
	public String getConfimPwd() {
		return confimPwd;
	}
	
	public void setConfimPwd(String confimPwd) {
		this.confimPwd = confimPwd;
	}
	
	@Override
	public Long[] getRoles() {
		return roles;
	}
	
	public void setRoles(Long[] roles) {
		this.roles = roles;
	}
}
