package cn.bonoon.core;

import cn.bonoon.entities.ProcessEntity;
import cn.bonoon.kernel.support.services.GenericService;

public interface ProcessService extends GenericService<ProcessEntity>{

	String getName(Long id);

}
