package cn.bonoon.controllers;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.bonoon.Util;
import cn.bonoon.core.KnowledgeAreaService;
import cn.bonoon.core.PracticeService;
import cn.bonoon.core.configs.HelperMessageConfig;
import cn.bonoon.core.infos.ResultInfo;
import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.events.BaseEvent;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.util.StringHelper;
import cn.bonoon.kernel.web.models.JsonResult;

@Controller
@RequestMapping
public class IndexController extends AbstractConfigurableController{
	private final KnowledgeAreaService knowledgeAreaService;
	private final PracticeService topicService;
	
	@Autowired
	public IndexController(KnowledgeAreaService knowledgeAreaService, PracticeService topicService){
		this.knowledgeAreaService = knowledgeAreaService;
		this.topicService = topicService;
	}
	
	@RequestMapping
	public String get(Model model, HttpServletRequest request){
		__make(model, request, "首页");
		return "index";
	}

	@RequestMapping("pmp/{key}!introduce")
	public String introduce(Model model, HttpServletRequest request, @PathVariable("key") String key){
		//需要判断一下是否存在这个会员
		if(memberService.hasMember(key)){
			request.getSession().setAttribute("introducekey", key);
			model.addAttribute("autoOpen", true);
		}
		__make(model, request, "介绍同学");
		return "index";
	}

	@RequestMapping("pmp/about.do")
	public String about(HttpServletRequest request, Model model){
		__make(model, request, "about", "关于我们");
		return "about";
	}

	@RequestMapping("pmp/help.do")
	public String help(HttpServletRequest request, Model model){
		__make(model, request, "help", "帮助说明");
		return "help";
	}

	@ResponseBody
	@RequestMapping("pmp/message/remove.do")
	public JsonResult message(HttpServletRequest request, String content){
		try{
			HttpSession hs = request.getSession();
			Object hms = hs.getAttribute("helperMessages");
			if(hms instanceof List){
				((List<?>) hms).remove(content);
			}
			return JsonResult.result();
		}catch (Exception e) {
			return JsonResult.error(e);
		}
	}
	
	private void __make(Model model, HttpServletRequest request, String title){
		__make(model, request, "summary", title);
	}
	
	private void __make(Model model, HttpServletRequest request, String selected, String title){
		model.addAttribute("mainMenu", "menus/menu-home.vm");
		model.addAttribute("menuSelected", selected);
		model.addAttribute("sysTitle", title);
		__channel(model, request);
	}
	
	private boolean __channel(Model model, HttpServletRequest request){
		LogonUser user = getUser();
		if(null == user){
			//未登录
			nologinConfig(model, request);
			return false;
		}
		loginConfig(model, request, funMapping(model, user));
		return true;
	}
	
	private boolean topics(Model model, KnowledgeAreaEntity ka){
		List<String> topics = topicService.freeFastRandom(ka.getId());
		if(topics.isEmpty()){return false;}
		model.addAttribute("showAnother", true);
		model.addAttribute("showTopicHead", true);
		model.addAttribute("topicTitle", "<span style='font-size: 18px; font-family: Arial;padding-left:15px;'>章节：" + ka.getName() + "</span>");
		model.addAttribute("selectedId", ka.getId());
		model.addAttribute("topics", topics);
		return true;
	}
	
	@RequestMapping("pmp/free/fast.do")
	public String fast(HttpServletRequest request, Model model, Long selectedId){
		//章节的选择
		List<KnowledgeAreaEntity> kas = knowledgeAreaService.find(" order by x.id asc");
		if(!kas.isEmpty()){
			FINDED : if(selectedId != null){
				Long chapterId = selectedId;
				for(int i = 0, l = kas.size() - 1; i < l && chapterId.equals(kas.get(i).getId()); i++){
					for(; i < l; i++){
						if(topics(model, kas.get(i + 1))){
							break FINDED;
						}
					}
				}
				for(KnowledgeAreaEntity ka : kas){
					if(topics(model, ka)){
						break;
					}
				}
			}else{
				for(KnowledgeAreaEntity ka : kas){
					if(topics(model, ka)){
						break;
					}
				}
			}
		}
		return __free(request, model, "免费测-快战", "fast");
	}
	
	@RequestMapping("pmp/free/combat.do")
	public String combat(HttpServletRequest request, Model model){
		//章节的选择
		model.addAttribute("topics", topicService.freeCombatRandom());
		
		return __free(request, model, "免费测-实战", "combat");
	}
	
	private String __free(HttpServletRequest request, Model model, String title, String selected){
		JiathisInfo ji = new JiathisInfo(request, getUser());

		ji.setSummary("亲，我正在TB为PMP奋斗呢，你来试试吧。");
		ji.setTitle("PMP测试");
		ji.setTopical("PMP测试");
		
		model.addAttribute("jiathis", ji);
		if(!__channel(model, request)){
			//提示
			HttpSession hs = request.getSession();
			if(hs.getAttribute("no-first-access-free") == null){
				hs.setAttribute("no-first-access-free", OBJECT);
				HelperMessageConfig hmc = new HelperMessageConfig();
				configService.read(new BaseEvent(hmc), HelperMessageConfig.class);
				if(StringHelper.isNotEmpty(hmc.getMessage_1())){
					addMessage(model, request, hmc.getMessage_1());
				}
			}
		}
		model.addAttribute("mainMenu", "menus/menu-free.vm");
		model.addAttribute("channelSelected", "free");
		model.addAttribute("menuSelected", selected);
		model.addAttribute("sysTitle", title);
		
		return "practices/free";
	}
	
	@RequestMapping("pmp/free/topic.do")
	public String topic(Model model, Integer topicNumber, String key, String answer, boolean imptMark, Boolean isen){
		//真应该有
		model.addAttribute("topic", topicService.topic(key, isen));
		model.addAttribute("topicNumber", topicNumber);
		model.addAttribute("answer", answer);
		model.addAttribute("importantMark", imptMark);
		model.addAttribute("layout", "layout-empty.vm");
		return "topics/topic";
	}
	
	@RequestMapping("pmp/free/answer.do")
	public String answer(Model model, String key, Boolean isen){
		model.addAttribute("answer", topicService.explanation(key, isen));
		return "topics/answer";
	}
	
	@RequestMapping("pmp/free/result.do")
	public String result(HttpServletRequest request, Model model, int timeSpent, String[] keys){
		//完成练习
		if(null != keys && keys.length > 0){
			List<TopicEntity> topics = topicService.find(keys);
			ResultInfo result = new ResultInfo();
			int total = 0, right = 0;
			for(TopicEntity te : topics){
				String answer = request.getParameter(te.getKey() + "-answer");
				if(result.parse(te, answer)){
					right++;
				}
				total++;
			}
			result.setTimeSpent(Util.timeSpent(timeSpent));
			model.addAttribute("result", result);
			
			String now = StringHelper.date2String(new Date());
			JiathisInfo ji = new JiathisInfo(request, getUser());
			int s = right / total;
			ji.setSummary("亲，本人于" + now + "时刻在TB的PMP战斗中获得" + s + "分哦。");
			ji.setTitle("PMP测试");
			ji.setTopical("PMP测试");
			
			model.addAttribute("jiathis", ji);
			
			if(null == getUser()){
				//未登录的情况下
				HelperMessageConfig hmc = new HelperMessageConfig();
				configService.read(new BaseEvent(hmc), HelperMessageConfig.class);
				HttpSession hs = request.getSession();
				Object oco = hs.getAttribute("free-topic-count");
				int tco = total;
				if(null != oco){
					tco += (int)oco;
				}
				if(hmc.getFreeCount() > tco){
					String content = hmc.getMessage_2();
					if(StringHelper.isNotEmpty(content)){
						content = content.replace("{N}", String.valueOf(tco));
						addMessage(model, request, content);
					}
				}
			}
		}
		
		return "topics/result";
	}
}
