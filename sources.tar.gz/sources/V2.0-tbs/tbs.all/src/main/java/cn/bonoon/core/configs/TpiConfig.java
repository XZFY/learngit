package cn.bonoon.core.configs;

import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

@FormEditor(headWidth = 140, width = 600)
public class TpiConfig {

	@PropertyEditor(name = "比例", value = 0)
	@PropertyHelper(value = "最后一次的做题练习所占的比例，默认为60%", type = HelperType.DIRECT)
	private int percentage;	

	@PropertyEditor(name = "及格线", value = 0)
	@PropertyHelper(value = "计算出来的用户的分数，到达这个分值以上则认为可以及格；默认为60分", type = HelperType.DIRECT)
	private int passLine;	

	@PropertyEditor(name = "安全线", value = 0)
	@PropertyHelper(value = "学员分数在安全线以上的，则认为正常情况下可以通过考试；默认为75分", type = HelperType.DIRECT)
	private int secureLine;

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	public int getPassLine() {
		return passLine;
	}

	public void setPassLine(int passLine) {
		this.passLine = passLine;
	}

	public int getSecureLine() {
		return secureLine;
	}

	public void setSecureLine(int secureLine) {
		this.secureLine = secureLine;
	}	
}
