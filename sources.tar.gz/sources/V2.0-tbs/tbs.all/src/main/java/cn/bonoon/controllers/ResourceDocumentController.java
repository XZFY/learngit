package cn.bonoon.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.kernel.support.models.Page;

@Controller
@RequestMapping("pmp/share/document")
public class ResourceDocumentController extends AbstractResourceController{

	@Override
	protected void init() {
		functionTitle 	= "资源库-共享文档";
		vmName 			= "doc/share-document";
		menuSelected 	= "document";
		vmPaging 		= "doc/share-document-page";
		super.init();
	}
	
	@Override
	protected int __size() {
		return __pageSize().getShareDocumentSize();
	}
	
	@Override
	protected Page readResource(int pageIndex, int pageSize, String name) {
		return resourceService.shareDocuments(pageIndex, pageSize, name);
	}
}
