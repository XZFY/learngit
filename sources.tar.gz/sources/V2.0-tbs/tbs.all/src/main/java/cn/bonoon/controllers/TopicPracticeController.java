package cn.bonoon.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.bonoon.Util;
import cn.bonoon.core.PracticeService;
import cn.bonoon.core.TopicService;
import cn.bonoon.core.infos.ExplanationInfo;
import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.kernel.web.controllers.AbstractController;
import cn.bonoon.kernel.web.models.JsonResult;

/**
 * 所有做题的过程都会被统一到这里来处理
 * @author jackson
 *
 */
@Controller
@RequestMapping("pmp/topic")
public class TopicPracticeController extends AbstractController{

	private final PracticeService practiceService;
	private final TopicService topicService;
	
	@Autowired
	public TopicPracticeController(PracticeService practiceService, TopicService topicService){
		this.practiceService = practiceService;
		this.topicService = topicService;
	}
	
	@RequestMapping("answer.do")
	public String answer(Model model, String key, Boolean isen){
		ExplanationInfo ei = practiceService.explanation(key, isen);
		String path = ei.getPath();
		if(null != path){
			path = toUrl(path);
			model.addAttribute("video", Util.videoParse(path, ei.getExt()));
		}
		model.addAttribute("answer", ei);
		return "topics/answer";
	}
	
	@ResponseBody
	@RequestMapping("refresh.do")
	public JsonResult refresh(Long id){
		practiceService.refresh(id);
		return JsonResult.result();
	}

	@ResponseBody
	@RequestMapping("save.do")
	public JsonResult save(Long id, String fromKey, String answer, Boolean imptMark){
		practiceService.refresh(id, fromKey, answer, imptMark);
		return JsonResult.result();
	}
	
	@RequestMapping("topic.do")
	public String topic(Model model, Long id, String fromKey, String answer, Boolean imptMark, Integer topicNumber, String toKey, Boolean isen){
		//真应该有
		AnswerEntity ae = practiceService.refresh(id, fromKey, answer, imptMark);
		String content = ae.getContent();
		int point = content.indexOf(toKey);
		model.addAttribute("topicNumber", topicNumber);
		model.addAttribute("topic", practiceService.topic(toKey, isen));
		model.addAttribute("answer", content.charAt(point-2));
		model.addAttribute("importantMark", content.charAt(point-1) == '1');
		model.addAttribute("layout", "layout-empty.vm");
		return "topics/topic";
	}
	
	//专门用于中文和英文之间的转换
	@RequestMapping("{id}!topic.do")
	public String topic(Model model, @PathVariable("id") String key, String answer, Boolean imptMark, Integer topicNumber, Boolean isen){
		model.addAttribute("topicNumber", topicNumber);
		model.addAttribute("topic", practiceService.topic(key, isen));
		model.addAttribute("answer", answer);
		model.addAttribute("importantMark", imptMark);
		model.addAttribute("layout", "layout-empty.vm");
		return "topics/topic";
	}
	
	@RequestMapping("finish.do")
	public String finish(Model model, Long id, String fromKey, String answer, Boolean imptMark){
		model.addAttribute("result", practiceService.finish(getUser().getId(), id, fromKey, answer, imptMark));
		return "topics/result";
	}
	
	@ResponseBody
	@RequestMapping("giveup.do")
	public Object giveup(Long id){
		try{
			practiceService.giveup(id);
		}catch(Exception ex){
			return ex.getMessage();
		}
		return true;
	}

	@RequestMapping("study/{key}!index.do")
	public String study(Model model, Boolean media, @PathVariable("key") String key, Long id){
		model.addAttribute("key", key);
		boolean m = media != null && media.booleanValue();
		model.addAttribute("media", m);
		if(m){
			model.addAttribute("info", topicService.getStudyMedia(key, id));
			model.addAttribute("otherType", false);
			model.addAttribute("currentName", "视频");
			model.addAttribute("switchName", "文档");
		}else{
			model.addAttribute("info", topicService.getStudyContent(key, id));
			model.addAttribute("otherType", true);
			model.addAttribute("currentName", "文档");
			model.addAttribute("switchName", "视频");
		}
		model.addAttribute("layout", "layout-empty.vm");
		return "topics/study";
	}

	@RequestMapping("comment/{key}!index.do")
	public String comment(Model model, @PathVariable("key") String key){
		model.addAttribute("items", topicService.getComments(key, Long.MAX_VALUE));
		model.addAttribute("key", key);
		model.addAttribute("maxid", Long.MAX_VALUE);
		model.addAttribute("layout", "layout-empty.vm");
		return "topics/comment";
	}

	@ResponseBody
	@RequestMapping("comment/{key}!{nid}!more.do")
	public JsonResult comment(@PathVariable("key") String key, @PathVariable("nid") Long nid){
		try{
			if(null == nid || nid < 0){
				nid = Long.MAX_VALUE;
			}
			return JsonResult.result(topicService.getComments(key, nid));
		}catch(Exception ex){
			return JsonResult.error(ex);
		}
	}

	@ResponseBody
	@RequestMapping("comment/{key}!save.do")
	public JsonResult comment(@PathVariable("key") String key, String content, int score){
		try{
			return JsonResult.result(topicService.commentSave(getUser(), key, content, score));
		}catch(Exception ex){
			return JsonResult.error(ex);
		}
	}
}
