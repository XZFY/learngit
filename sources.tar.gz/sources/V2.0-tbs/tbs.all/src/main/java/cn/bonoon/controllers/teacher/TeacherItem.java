package cn.bonoon.controllers.teacher;

import cn.bonoon.kernel.support.models.AbstractItem;
import cn.bonoon.kernel.web.annotations.grid.AsColumn;
import cn.bonoon.kernel.web.annotations.grid.AsDataGrid;

@AsDataGrid(condition = TeacherCondition.class)
public class TeacherItem extends AbstractItem implements TeacherDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1862204382426465179L;

	@AsColumn(width = 120, ordinal = 0)
	private String name;

	@AsColumn(width = 100, ordinal = 1)
	private String tel;

	@AsColumn(width = 100, ordinal = 2)
	private String phone;
//
//	@AsColumn(width = 120, ordinal = 20)
//	private String institution;

	@AsColumn(width = 150, ordinal = 40)
	private String courseNames;

	@AsColumn(width = 100, ordinal = 30)
	private String entryAt;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

//	public String getInstitution() {
//		return institution;
//	}
//
//	public void setInstitution(String institution) {
//		this.institution = institution;
//	}

	public String getCourseNames() {
		return courseNames;
	}

	public void setCourseNames(String courseNames) {
		this.courseNames = courseNames;
	}
	
	public String getEntryAt() {
		return entryAt;
	}

	public void setEntryAt(String entryAt) {
		this.entryAt = entryAt;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

}
