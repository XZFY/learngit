package cn.bonoon.core.configs;

import cn.bonoon.kernel.web.annotations.components.AsCheckbox;
import cn.bonoon.kernel.web.annotations.components.AsNumberBox;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

//功能开通的积分及配置信息对象
@FormEditor(value = 2, headWidth = 120, width = 300)
public class OpenedPointsConfig {
	//可以开通该功能需要达到的总的积分值
	@AsNumberBox
	@PropertyEditor(name = "练习积分线", value = 0, width = 80)
	@PropertyHelper(value = "开通练习功能需达到的积分线", type = HelperType.DIRECT)
	private int praxisReach;
	//开通该功能需要花费的积分值
	@AsNumberBox
	@PropertyEditor(name = "练习开通费用", value = 2, width = 80)
	@PropertyHelper(value = "开通练习功能需花费的费用", type = HelperType.DIRECT)
	private int praxisCost;
	@AsCheckbox("现金")
	@PropertyEditor(name = "费用类型", value = 4)
	@PropertyHelper(value = "开通练习功能是花费积分还是现金", type = HelperType.DIRECT)
	private boolean praxisCostCash;
	//如果用户还没有达到要求的总积分值，这里配置是否显示该功能给用户看；如果显示，也是不可操作的，只显示功能的名称而已
	@AsCheckbox("是")
	@PropertyEditor(name = "练习显示", value = 1)
	@PropertyHelper(value = "没达到积分线时是否显示", type = HelperType.DIRECT)
	private boolean praxisShow;
	
	@AsNumberBox
	@PropertyEditor(name = "提高积分线", value = 5, width = 80)
	@PropertyHelper(value = "开通提高功能需达到的积分线", type = HelperType.DIRECT)
	private int improveReach;
	//开通该功能需要花费的积分值
	@AsNumberBox
	@PropertyEditor(name = "提高开通积分", value = 7, width = 80)
	@PropertyHelper(value = "开通提高功能需花费的积分", type = HelperType.DIRECT)
	private int improveCost;
	@AsCheckbox("现金")
	@PropertyEditor(name = "费用类型", value = 8)
	@PropertyHelper(value = "开通提高功能是花费积分还是现金", type = HelperType.DIRECT)
	private boolean improveCostCash;
	//如果用户还没有达到要求的总积分值，这里配置是否显示该功能给用户看；如果显示，也是不可操作的，只显示功能的名称而已
	@AsCheckbox("是")
	@PropertyEditor(name = "提高显示", value = 6)
	@PropertyHelper(value = "没达到积分线时是否显示", type = HelperType.DIRECT)
	private boolean improveShow;


	@AsNumberBox
	@PropertyEditor(name = "试卷积分线", value = 10, width = 80)
	@PropertyHelper(value = "开通练习功能需达到的积分线", type = HelperType.DIRECT)
	private int examReach;

	@AsNumberBox
	@PropertyEditor(name = "试卷开通积分", value = 12, width = 80)
	@PropertyHelper(value = "开通试卷功能需花费的积分", type = HelperType.DIRECT)
	private int examCost;
	@AsCheckbox("现金")
	@PropertyEditor(name = "费用类型", value = 13)
	@PropertyHelper(value = "开通试卷功能是花费积分还是现金", type = HelperType.DIRECT)
	private boolean examCostCash;

	@AsCheckbox("是")
	@PropertyEditor(name = "试卷显示", value = 11)
	@PropertyHelper(value = "没达到积分线时是否显示", type = HelperType.DIRECT)
	private boolean examShow;

	@AsNumberBox
	@PropertyEditor(name = "班级积分线", value = 20, width = 80)
	@PropertyHelper(value = "开通班级功能需达到的积分线", type = HelperType.DIRECT)
	private int classReach;

	@AsNumberBox
	@PropertyEditor(name = "班级开通积分", value = 22, width = 80)
	@PropertyHelper(value = "开通班级功能需花费的积分", type = HelperType.DIRECT)
	private int classCost;
	@AsCheckbox("现金")
	@PropertyEditor(name = "费用类型", value = 23)
	@PropertyHelper(value = "开通班级功能是花费积分还是现金", type = HelperType.DIRECT)
	private boolean classCostCash;
	
	@AsCheckbox("是")
	@PropertyEditor(name = "班级显示", value = 21)
	@PropertyHelper(value = "没达到积分线时是否显示", type = HelperType.DIRECT)
	private boolean classShow;

	@AsNumberBox
	@PropertyEditor(name = "资源库积分线", value = 30, width = 80)
	@PropertyHelper(value = "开通资源库功能需达到的积分线", type = HelperType.DIRECT)
	private int resourceReach;

	@AsNumberBox
	@PropertyEditor(name = "资源库开通积分", value = 32, width = 80)
	@PropertyHelper(value = "开通资源库功能需花费的积分", type = HelperType.DIRECT)
	private int resourceCost;
	@AsCheckbox("现金")
	@PropertyEditor(name = "费用类型", value = 33)
	@PropertyHelper(value = "开通资源库功能是花费积分还是现金", type = HelperType.DIRECT)
	private boolean resourceCostCash;
	
	@AsCheckbox("是")
	@PropertyEditor(name = "资源库显示", value = 31)
	@PropertyHelper(value = "没达到积分线时是否显示", type = HelperType.DIRECT)
	private boolean resourceShow;
	
	//达到开通考试助手的积分线
	@AsNumberBox
	@PropertyEditor(name = "助手积分线", value = 40, width = 80)
	@PropertyHelper(value = "开通考试助手功能需达到的积分线", type = HelperType.DIRECT)
	private int assistantReach;

	@AsCheckbox("是")
	@PropertyEditor(name = "助手显示", value = 41)
	@PropertyHelper(value = "没达到积分线时是否显示", type = HelperType.DIRECT)
	private boolean assistantShow;

	@AsNumberBox
	@PropertyEditor(name = "助手开通积分", value = 42, width = 80)
	@PropertyHelper(value = "开通助手功能需花费的积分", type = HelperType.DIRECT)
	private int assistantCost;
	@AsCheckbox("现金")
	@PropertyEditor(name = "费用类型", value = 43)
	@PropertyHelper(value = "开通助手功能是花费积分还是现金", type = HelperType.DIRECT)
	private boolean assistantCostCash;
	
	public int getPraxisReach() {
		return praxisReach;
	}

	public void setPraxisReach(int praxisReach) {
		this.praxisReach = praxisReach;
	}

	public int getPraxisCost() {
		return praxisCost;
	}

	public void setPraxisCost(int praxisCost) {
		this.praxisCost = praxisCost;
	}

	public boolean isPraxisShow() {
		return praxisShow;
	}

	public void setPraxisShow(boolean praxisShow) {
		this.praxisShow = praxisShow;
	}

	public int getExamReach() {
		return examReach;
	}

	public void setExamReach(int examReach) {
		this.examReach = examReach;
	}

	public int getExamCost() {
		return examCost;
	}

	public void setExamCost(int examCost) {
		this.examCost = examCost;
	}

	public boolean isExamShow() {
		return examShow;
	}

	public void setExamShow(boolean examShow) {
		this.examShow = examShow;
	}

//	public int getRealReach() {
//		return realReach;
//	}
//
//	public void setRealReach(int realReach) {
//		this.realReach = realReach;
//	}
//
//	public boolean isRealShow() {
//		return realShow;
//	}
//
//	public void setRealShow(boolean realShow) {
//		this.realShow = realShow;
//	}

	public int getClassReach() {
		return classReach;
	}

	public void setClassReach(int classReach) {
		this.classReach = classReach;
	}

	public boolean isClassShow() {
		return classShow;
	}

	public void setClassShow(boolean classShow) {
		this.classShow = classShow;
	}

	public int getClassCost() {
		return classCost;
	}

	public void setClassCost(int classCost) {
		this.classCost = classCost;
	}

	public int getResourceReach() {
		return resourceReach;
	}

	public void setResourceReach(int resourceReach) {
		this.resourceReach = resourceReach;
	}

	public int getResourceCost() {
		return resourceCost;
	}

	public void setResourceCost(int resourceCost) {
		this.resourceCost = resourceCost;
	}

	public boolean isResourceShow() {
		return resourceShow;
	}

	public void setResourceShow(boolean resourceShow) {
		this.resourceShow = resourceShow;
	}

	public int getAssistantReach() {
		return assistantReach;
	}

	public void setAssistantReach(int assistantReach) {
		this.assistantReach = assistantReach;
	}

	public boolean isAssistantShow() {
		return assistantShow;
	}

	public void setAssistantShow(boolean assistantShow) {
		this.assistantShow = assistantShow;
	}

	public int getAssistantCost() {
		return assistantCost;
	}

	public void setAssistantCost(int assistantCost) {
		this.assistantCost = assistantCost;
	}

	public boolean isPraxisCostCash() {
		return praxisCostCash;
	}

	public void setPraxisCostCash(boolean praxisCostCash) {
		this.praxisCostCash = praxisCostCash;
	}

	public int getImproveReach() {
		return improveReach;
	}

	public void setImproveReach(int improveReach) {
		this.improveReach = improveReach;
	}

	public int getImproveCost() {
		return improveCost;
	}

	public void setImproveCost(int improveCost) {
		this.improveCost = improveCost;
	}

	public boolean isImproveCostCash() {
		return improveCostCash;
	}

	public void setImproveCostCash(boolean improveCostCash) {
		this.improveCostCash = improveCostCash;
	}

	public boolean isImproveShow() {
		return improveShow;
	}

	public void setImproveShow(boolean improveShow) {
		this.improveShow = improveShow;
	}

	public boolean isExamCostCash() {
		return examCostCash;
	}

	public void setExamCostCash(boolean examCostCash) {
		this.examCostCash = examCostCash;
	}

	public boolean isClassCostCash() {
		return classCostCash;
	}

	public void setClassCostCash(boolean classCostCash) {
		this.classCostCash = classCostCash;
	}

	public boolean isResourceCostCash() {
		return resourceCostCash;
	}

	public void setResourceCostCash(boolean resourceCostCash) {
		this.resourceCostCash = resourceCostCash;
	}

	public boolean isAssistantCostCash() {
		return assistantCostCash;
	}

	public void setAssistantCostCash(boolean assistantCostCash) {
		this.assistantCostCash = assistantCostCash;
	}
	
}
