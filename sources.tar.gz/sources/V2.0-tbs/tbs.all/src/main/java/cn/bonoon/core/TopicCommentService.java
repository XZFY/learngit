package cn.bonoon.core;

import cn.bonoon.entities.TopicComment;
import cn.bonoon.kernel.support.services.GenericService;

public interface TopicCommentService extends GenericService<TopicComment>{
	int UNAUDITED = 0;
	int NORMAL = 1;
	
}
