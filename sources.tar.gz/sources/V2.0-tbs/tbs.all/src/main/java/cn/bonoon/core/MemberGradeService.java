package cn.bonoon.core;

import cn.bonoon.entities.MemberGradeEntity;
import cn.bonoon.kernel.support.services.GenericService;

public interface MemberGradeService extends GenericService<MemberGradeEntity>{

}
