package cn.bonoon.services;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.MediaContentService;
import cn.bonoon.entities.BrowseRecordEntity;
import cn.bonoon.entities.MediaContentEntity;
import cn.bonoon.kernel.events.OperateEvent;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.services.AbstractService;

@Service
@Transactional(readOnly = true)
public class MediaContentServiceImpl extends AbstractService<MediaContentEntity> implements MediaContentService{

	@Override
	public List<BrowseRecordEntity> browseRecords(IOperator user, Long id) {
		String ql = "select x from BrowseRecordEntity x where x.uid=? and x.type=0 and x.tid<>? order by x.lastAt desc";
		return __top(10, BrowseRecordEntity.class, ql, user.getId(), id);
	}
	
	@Override
	protected void onDelete(OperateEvent event, MediaContentEntity entity) {
		super.onDelete(event, entity);
		String ql = "delete from BrowseRecordEntity where x.type=0 and x.tid=?";
		__exec(ql, entity.getId());
	}
	
	@Override
	@Transactional
	public MediaContentEntity browse(IOperator user, Long id) {
		MediaContentEntity mc = __get(id);
		if(mc != null && (mc.isShare() || mc.getCreatorId().equals(user.getId()))){
			String ql = "select x from BrowseRecordEntity x where x.uid=? and x.tid=? and x.type=0 order by x.lastAt desc";
			BrowseRecordEntity bre = __first(BrowseRecordEntity.class, ql, user.getId(), id);
			Date now = new Date();
			if(null == bre){
				bre = new BrowseRecordEntity();
				bre.setCount(1);
				bre.setCreateAt(now);
				bre.setLastAt(now);
				bre.setName(mc.getName());
				bre.setTid(mc.getId());
				bre.setType(0);
				bre.setUid(user.getId());
				entityManager.persist(bre);
			}else{
				bre.setCount(bre.getCount() + 1);
				bre.setLastAt(now);
				entityManager.merge(bre);
			}
			mc.setBrowseCount(mc.getBrowseCount() + 1);
			entityManager.merge(mc);
			return mc;
		}
		return null;
	}

}
