package cn.bonoon.services;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.AnswerStatus;
import cn.bonoon.core.CapabilityEvaluationService;
import cn.bonoon.core.configs.EvaluationConfig;
import cn.bonoon.core.infos.EvaluationItemInfo;
import cn.bonoon.entities.BaseEntity;
import cn.bonoon.entities.CapabilityEvaluationEntity;
import cn.bonoon.entities.CapabilityEvaluationItem;
import cn.bonoon.entities.KnowledgePointEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.entities.TransactionEntity;
import cn.bonoon.kernel.support.services.AbstractSearchService;

@Service
@Transactional(readOnly = true)
public class CapabilityEvaluationServiceImpl extends AbstractSearchService<CapabilityEvaluationEntity> implements CapabilityEvaluationService {

//	private ConfigManager configManager;
//	@Override
//	public void afterPropertiesSet() throws Exception {
//		super.afterPropertiesSet();
////		configManager = ConfigManager.getManager();
//	}
//	
//	private EvaluationConfig __config(){
//		EvaluationConfig cc = new EvaluationConfig();
//		try{
//			configManager.read(applicationContext, entityManager, cc);
//		}catch(Exception ex){
//		}
//		return cc;
//	}
	
	@Override
	public List<CapabilityEvaluationEntity> evaluations(MemberEntity member) {
		return __evaluations(member);
	}
	
	private List<CapabilityEvaluationEntity> __evaluations(MemberEntity member){
		String ql = "select x from CapabilityEvaluationEntity x where x.member.id=? order by x.createAt desc";
		return __list(CapabilityEvaluationEntity.class, ql, member.getId());
	}

	@Override
	public List<EvaluationItemInfo> evaluation(CapabilityEvaluationEntity cee) {
		List<EvaluationItemInfo> eiis = new ArrayList<EvaluationItemInfo>();
		String ql = "select x from CapabilityEvaluationItem x where x.evaluation.id=?";
		List<CapabilityEvaluationItem> items = __list(CapabilityEvaluationItem.class, ql, cee.getId());
		for(KnowledgePointEntity kpe : __list(KnowledgePointEntity.class, "from KnowledgePointEntity x where x.deleted=false")){
			CapabilityEvaluationItem cei = null;
			for(CapabilityEvaluationItem it : items){
				if(it.getKnowledge().equals(kpe.getId())){
					cei = it;
					break;
				}
			}
//			items.remove(cei);
			eiis.add(new EvaluationItemInfo(kpe, cei));
		}
		return eiis;
	}

	//进行一次评估
	@Override
	@Transactional
	public List<CapabilityEvaluationEntity> evaluate(MemberEntity member, EvaluationConfig config) {
		// TODO Auto-generated method stub
//		EvaluationConfig config = __config();
		List<CapabilityEvaluationEntity> items = __evaluations(member);
		int points;
		if(config.isFirstFree() && items.isEmpty()){
			//第一次是免费的
			points = 0;
		}else{
			points = config.getEvaluateCost();
		}
		Calendar cal = Calendar.getInstance();
		Date now = cal.getTime();
		if(points > 0){
			long ap = member.getAvailablePoints();
			if(points < ap){
				throw new RuntimeException("进行能力评估需要花费" + points + "积分，您账户只有" + ap + "积分，无法进行评估；");
			}
			ap -= points;
			member.setAvailablePoints(ap);
			//需要花费积分的情况
			TransactionEntity tpe = new TransactionEntity();
			tpe.setCreateAt(now);
			tpe.setDeduct(true);
//			tpe.setType(TransactionType.DEDUCT);
//			tpe.setRemark("进行能力评估");
//			tpe.setUserId(member.getId());
//			
//			tpe.setPoints(points);
//			tpe.setAvailablePoints(ap);
//			tpe.setTotalPoints(member.getTotalPoints());
			
			entityManager.persist(tpe);
			
			entityManager.merge(member);
		}
		int vp = config.getValidPeriod();
		TypedQuery<String> query;
		Date beginAt = null;
		if(vp > 0){
			cal.add(Calendar.MONTH, -vp);
			beginAt = cal.getTime();
			String ql = "select x.content from AnswerEntity x where x.status=? and x.creatorId=? and x.finishAt>=?";
			query = entityManager.createQuery(ql, String.class);
			query.setParameter(1, AnswerStatus.ANSWER_STATUS_FINISH);
			query.setParameter(2, member.getId());
			query.setParameter(3, beginAt);
		}else{
			String ql = "select x.content from AnswerEntity x where x.status=? and x.creatorId=?";
			query = entityManager.createQuery(ql, String.class);
			query.setParameter(1, AnswerStatus.ANSWER_STATUS_FINISH);
			query.setParameter(2, member.getId());
		}
		
		int dl = config.getDifficultyLevel();
		String tql = "select x from TopicEntity x where x.key=? and x.difficulty>=?";
		int tc = 0, rc = 0;
		Map<Long, CapabilityEvaluationItem> mcei = new HashMap<Long, CapabilityEvaluationItem>();
		Map<Long, AnswerStatistics> marea = new HashMap<Long, AnswerStatistics>(),
				mprocess = new HashMap<Long, AnswerStatistics>(),
				mgroup = new HashMap<Long, AnswerStatistics>();
		
		for(String content : query.getResultList()){
			for(String awr : content.split(";")){
				TopicEntity te = __first(TopicEntity.class, tql, awr.substring(2), dl);
				if(null != te){
					String ans = te.getAnswer();
					if(null != ans){
						ans = ans.trim().toUpperCase();
					}
					boolean right = awr.startsWith(ans);
					
					KnowledgePointEntity kp = te.getKnowledge();
					CapabilityEvaluationItem cei = null;
					if(null != kp){
						cei = mcei.get(kp.getId());
						if(null == cei){
							cei = new CapabilityEvaluationItem();
							cei.setKnowledge(kp.getId());
							cei.setWeight(kp.getWeight());
							mcei.put(kp.getId(), cei);
						}
						cei.setTotalCount(cei.getTotalCount() + 1);
						if(right){
							cei.setRightCount(cei.getRightCount() + 1);
						}
					}
					
					__cal(te.getArea(), marea, right);
					__cal(te.getGroup(), mgroup, right);
					__cal(te.getProcess(), mprocess, right);

					tc++;
					if(right){
						rc++;
					}
				}
			}
		}
		int ve = config.getValidEntry();
		if(ve > 0 && ve > tc){
			//总的题目数少
			throw new RuntimeException("要求您至少要做过" + ve + "道有效题目，而您只做了" + tc + "道！");
		}
		
		CapabilityEvaluationEntity cee = new CapabilityEvaluationEntity();
		cee.setMember(member);
		cee.setBeginAt(beginAt);
		cee.setAreaStatistics(__cal(marea));
		cee.setGroupStatistics(__cal(mgroup));
		cee.setProcessStatistics(__cal(mprocess));
		cee.setTotalCount(tc);
		cee.setRightCount(rc);
		cee.setCreateAt(now);
		cee.setPicketLine(config.getPicketLine());
		cee.setSecureLine(config.getSecureLine());
		cee.setSuggestLine(config.getSuggestLine());
		
		entityManager.persist(cee);
		
//		List<CapabilityEvaluationItem> ces = new ArrayList<CapabilityEvaluationItem>();
		for(CapabilityEvaluationItem cei : mcei.values()){
			double wt = cei.getWeight();
			if(wt > 0){
				tc += cei.getTotalCount() * wt;
				rc += cei.getRightCount() * wt;
			}
			cei.setCapability(cei.getRightCount() / cei.getTotalCount());
			cei.setEvaluation(cee);
			entityManager.persist(cei);
		}
		
		cee.setCapability(rc / tc);
		entityManager.merge(cee);
		return null;
	}
	
	private String __cal(Map<Long, AnswerStatistics> map){
		StringBuilder sb = new StringBuilder();
		
		for(AnswerStatistics as : map.values()){
			sb.append(';').append(as.id).append(',').append(as.total).append(',').append(as.right);
		}
		
		return sb.substring(1);
	}
	
	private void __cal(BaseEntity be, Map<Long, AnswerStatistics> map, boolean right){
		if(null != be){
			Long id = be.getId();
			AnswerStatistics as = map.get(id);
			if(null == as){
				as = new AnswerStatistics();
//				as.name = be.getName();
				as.id = id;
				map.put(id, as);
			}
			as.total++;
			if(right){
				as.right++;
			}
		}
	}
	
	private class AnswerStatistics{
		private int total;
		private int right;
//		private String name;
		private Long id;
	}
}
