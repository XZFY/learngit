package cn.bonoon.core.handlers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;

import cn.bonoon.core.MemberService;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.handler.LoginSuccessHandler;
import cn.bonoon.kernel.security.LogonUser;

public class TbsLoginSuccessHandler implements LoginSuccessHandler {
	@Autowired
	private MemberService memberService;
	
	@Override
	public void onSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication, LogonUser user) {
		MemberEntity me = memberService.loginSuccess(user);
		if(null != me){
			user.set("user-key", me.getKey());
			user.set("user-member", "true");
		}
	}

}
