package cn.bonoon.entities;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Table;

@Entity
@Table(name = "T_DOCCONTENT")
public class DocContentEntity extends BaseContentEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6336230232431838030L;

	@Column(name = "C_CONTENT", columnDefinition="TEXT")
	@Basic(fetch = FetchType.LAZY)
	private String content;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}
