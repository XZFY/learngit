package cn.bonoon.core.infos;

import cn.bonoon.entities.BaseContentEntity;
import cn.bonoon.entities.MediaContentEntity;

public class TopicContentItem {

	private Long id;
	
	private String name;
	
	private String content;
	
	private String path;
	
	private String attrs = "";
	
	private boolean outterLink;
	
	TopicContentItem(MediaContentEntity entity){
		id = entity.getId();
		name = entity.getName();
		path = entity.getPath();
		outterLink = entity.isOutterLink();
		if(null != entity.getArea()){
			attrs = "," + entity.getArea().getName();
		}
		if(null != entity.getGroup()){
			attrs += "," + entity.getGroup().getName();
		}
		if(null != entity.getProcess()){
			attrs += "," + entity.getProcess().getName();
		}
		if(!attrs.isEmpty()){
			attrs = attrs.substring(1);
		}
	}
	TopicContentItem(BaseContentEntity entity){
		id = entity.getId();
		name = entity.getName();
		path = entity.getPath();
		if(null != entity.getArea()){
			attrs = "," + entity.getArea().getName();
		}
		if(null != entity.getGroup()){
			attrs += "," + entity.getGroup().getName();
		}
		if(null != entity.getProcess()){
			attrs += "," + entity.getProcess().getName();
		}
		if(!attrs.isEmpty()){
			attrs = attrs.substring(1);
		}
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getAttrs() {
		return attrs;
	}

	public void setAttrs(String attrs) {
		this.attrs = attrs;
	}

	public boolean isOutterLink() {
		return outterLink;
	}

	public void setOutterLink(boolean outterLink) {
		this.outterLink = outterLink;
	}
}
