package cn.bonoon.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.bonoon.core.PracticeService;
import cn.bonoon.core.infos.KnowledgeInfo;
import cn.bonoon.entities.KnowledgePointEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.util.StringHelper;

@Controller
@RequestMapping("pmp/sister")
public class MemberSisterController extends AbstractAssistantController{
	private final PracticeService topicService;
	private String imgRight, imgWrong;
	
	@Autowired
	public MemberSisterController(PracticeService topicService){
		this.topicService = topicService;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		super.afterPropertiesSet();
		imgRight = toUrl("/r/images/right.png");
		imgWrong = toUrl("/r/images/wrong.png");
	}
	
	@Override
	protected void init() {
		functionTitle 	= "学习助手-小师妹";
		vmName 			= "assistant/sister";
		menuSelected 	= "sister";
		super.init();
	}

	@Override
	protected String render(HttpServletRequest request, Model model, MemberEntity member, LogonUser user) {
		//生成界面
		assistantService.sister(user).render(model);
		return super.render(request, model, member, user);
	}
	
	@RequestMapping("topic.do")
	public String topic(Model model, Long id, String fromKey, String answer, Boolean imptMark, Integer topicNumber, String toKey, Boolean isen){
		//真应该有
		model.addAttribute("topicNumber", topicNumber);
		model.addAttribute("topic", topicService.topic(toKey, isen));
		model.addAttribute("answer", answer);
		model.addAttribute("importantMark", imptMark);
		model.addAttribute("layout", "layout-empty.vm");
		return "topics/topic";
	}
	
	@RequestMapping("{id}!result.do")
	public String result(HttpServletRequest request, Model model, @PathVariable("id") Long id, String[] keys, Boolean isen){
		if(null != keys && keys.length > 0){
			StringBuilder html = new StringBuilder();
			List<TopicEntity> topics = topicService.find(keys);
			int i = 1;
			Map<Long, KnowledgeInfo> maps = new HashMap<>();
			for(TopicEntity te : topics){
				String answer = request.getParameter(te.getKey() + "-answer");
//				String ta = te.getAnswer();
				String ta = te.getAnswer();
				if(null != ta){
					ta = ta.trim().toUpperCase();
				}
				KnowledgePointEntity knowledge = te.getKnowledge();
				if(null != knowledge){
					KnowledgeInfo pi = maps.get(knowledge.getId());
					if(null == pi){
						pi = new KnowledgeInfo(knowledge);
						maps.put(knowledge.getId(), pi);
					}
					pi.answer(ta, answer);
				}
				html.append("<thead><tr><th style='width:40px;'>").append(i++).append("</th><th colspan='2'>");
				html.append(te.getCnContent()).append("</th></thead><tbody><tr><td></td>");
				blue(html, ta, "A", answer).append(te.getCnOptionA()).append("</td>");
				blue(html, ta, "B", answer).append(te.getCnOptionB()).append("</td></tr><tr><td></td>");
				blue(html, ta, "C", answer).append(te.getCnOptionC()).append("</td>");
				blue(html, ta, "D", answer).append(te.getCnOptionD()).append("</td></tr>");
				if(StringHelper.isNotEmpty(te.getCnExplanation())){
					html.append("<tr><td></td><td>").append(te.getCnExplanation()).append("</td></tr>");
				}
				html.append("</tbody>");
			}
			model.addAttribute("html", html);
			model.addAttribute("id", id);
			model.addAttribute("next", assistantService.sister(getUser(), id, maps.values()));
		}
		return "assistant/sister-result";
	}
	
	private StringBuilder blue(StringBuilder html, String s, String t, String a){
		if(s.equals(t)){
			//这是正确的答案，如果选中的也是这个，则表示你选择正确
			html.append("<td style='color:blue;'>");
			if(t.equals(a)){
				html.append("<img src='").append(imgRight).append("'>");
			}
		}else{
			html.append("<td>");
			if(t.equals(a)){
				html.append("<img src='").append(imgWrong).append("'>");
			}
		}
		return html.append(t).append(". ");
	}
	
	@RequestMapping(value = "{id}!next.do", method = RequestMethod.POST)
	public String next(HttpServletRequest request, Model model, @PathVariable("id") Long id){
		LogonUser user = getUser();
		assistantService.sister(user, id).render(model);
		return super.render(request, model, null, user);
	}
}
