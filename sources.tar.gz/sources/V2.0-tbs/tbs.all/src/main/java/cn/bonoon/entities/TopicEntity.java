package cn.bonoon.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import cn.bonoon.kernel.support.entities.AbstractEntity;
import cn.bonoon.kernel.support.entities.EntityStatus;

@Entity
@Table(name = "T_TOPIC")
public class TopicEntity extends AbstractEntity implements EntityStatus{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7765392710125286392L;
	
	/**
	 * 每一个题目都有一个唯一的key
	 */
	@Column(name = "C_KEY", length = 50)
	private String key;

	@Column(name = "C_STATUS")
	private int status;
	
	@Column(name = "C_CODE", length = 50)
	private String code;

	/**
	 * 章节
	 */
	@ManyToOne
	@JoinColumn(name = "R_CHAPTER_ID")
	private ChapterEntity chapter;
	/**
	 * 领域
	 */
	@ManyToOne
	@JoinColumn(name = "R_AREA_ID")
	private KnowledgeAreaEntity area;
	/**
	 * 知识点
	 */
	@ManyToOne
	@JoinColumn(name = "R_KNOWLEDGE_ID")
	private KnowledgePointEntity knowledge;
	/**
	 * 过程
	 */
	@ManyToOne
	@JoinColumn(name = "R_PROCESS_ID")
	private ProcessEntity process;
	/**
	 * 过程组
	 */
	@ManyToOne
	@JoinColumn(name = "R_GROUP_ID")
	private ProcessGroupEntity group;
	/**
	 * 难度系数
	 */
	@Column(name = "C_DIFFICULTY")
	private int difficulty;
	/**
	 * 该题目是否可以免费测试，即是否公开；快战
	 */
	@Column(name = "C_FREEFAST")
	private boolean freeFast;
	//实战
	@Column(name = "C_FREECOMBAT")
	private boolean freeCombat;
	/**
	 * 是否出现在练习题里
	 */
	@Column(name = "C_PRAXIS")
	private boolean praxis;
	//技能提高
	@Column(name = "C_IMPROVE")
	private boolean improve;
	/**
	 * 该题目是否出现在考试练习里
	 */
	@Column(name = "C_EXAM")
	private boolean exam;
	/**
	 * 该题目是否属于真题考试
	 */
	@Column(name = "C_REAL")
	private boolean real;
	/**
	 * 题目的内容描述
	 */
	@Column(name = "C_CNCONTENT", length = 2048)
	private String cnContent;

	/**
	 * 答案选项A
	 */
	@Column(name = "C_CNOPTIONA", length = 1024)
	private String cnOptionA;
	/**
	 * 答案选项B
	 */
	@Column(name = "C_CNOPTIONB", length = 1024)
	private String cnOptionB;
	/**
	 * 答案选项C
	 */
	@Column(name = "C_CNOPTIONC", length = 1024)
	private String cnOptionC;
	/**
	 * 答案选项D
	 */
	@Column(name = "C_CNOPTIOND", length = 1024)
	private String cnOptionD;
	
	/**
	 * 答案解释
	 */
	@Column(name = "C_CNEXPLANATION", length = 2048)
	private String cnExplanation;

	/**
	 * 题目的内容描述-英文
	 */
	@Column(name = "C_ENCONTENT", length = 2048)
	private String enContent;

	/**
	 * 答案选项A-英文
	 */
	@Column(name = "C_ENOPTIONA", length = 1024)
	private String enOptionA;
	/**
	 * 答案选项B-英文
	 */
	@Column(name = "C_ENOPTIONB", length = 1024)
	private String enOptionB;
	/**
	 * 答案选项C-英文
	 */
	@Column(name = "C_ENOPTIONC", length = 1024)
	private String enOptionC;
	/**
	 * 答案选项D-英文
	 */
	@Column(name = "C_ENOPTIOND", length = 1024)
	private String enOptionD;
	
	/**
	 * 答案解释-英文
	 */
	@Column(name = "C_ENEXPLANATION", length = 2048)
	private String enExplanation;

	/**
	 * 答案
	 */
	@Column(name = "C_ANSWER", length = 10)
	private String answer;
	/**
	 * 总的得分
	 */
	@Column(name = "C_TOTALSCORE")
	private int totalScore;
	/**
	 * 平均得分
	 */
	@Column(name = "C_AVERAGESCORE")
	private double averageScore;
	/**
	 * 评分的总人数
	 */
	@Column(name = "C_SCORETIMES")
	private int scoreTimes;
	
	//这个题目被做过多少次，正确的次数是多少次，用于题目的评估
	@Column(name = "C_TOTALCOUNT")
	private long totalCount;
	
	@Column(name = "C_RIGHTCOUNT")
	private long rightCount;

	@Column(name = "C_CNPICTURE")
	private String cnPicture;

	@Column(name = "C_ENPICTURE")
	private String enPicture;

	@Column(name = "C_VIDEOPATH")
	private String videoPath;

	@Column(name = "C_VIDEOEXT")
	private String videoExt;

	public boolean isFreeFast() {
		return freeFast;
	}

	public void setFreeFast(boolean freeFast) {
		this.freeFast = freeFast;
	}

	public boolean isFreeCombat() {
		return freeCombat;
	}

	public void setFreeCombat(boolean freeCombat) {
		this.freeCombat = freeCombat;
	}

	public boolean isImprove() {
		return improve;
	}

	public void setImprove(boolean improve) {
		this.improve = improve;
	}

	public long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}

	public long getRightCount() {
		return rightCount;
	}

	public void setRightCount(long rightCount) {
		this.rightCount = rightCount;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public ChapterEntity getChapter() {
		return chapter;
	}

	public void setChapter(ChapterEntity chapter) {
		this.chapter = chapter;
	}

	public KnowledgePointEntity getKnowledge() {
		return knowledge;
	}

	public void setKnowledge(KnowledgePointEntity knowledge) {
		this.knowledge = knowledge;
	}

	public int getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(int difficulty) {
		this.difficulty = difficulty;
	}

	public boolean isPraxis() {
		return praxis;
	}

	public void setPraxis(boolean praxis) {
		this.praxis = praxis;
	}

	public boolean isExam() {
		return exam;
	}

	public void setExam(boolean exam) {
		this.exam = exam;
	}

	public boolean isReal() {
		return real;
	}

	public void setReal(boolean real) {
		this.real = real;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

//	public boolean isFree() {
//		return free;
//	}
//
//	public void setFree(boolean free) {
//		this.free = free;
//	}

	public KnowledgeAreaEntity getArea() {
		return area;
	}

	public void setArea(KnowledgeAreaEntity area) {
		this.area = area;
	}

	public ProcessEntity getProcess() {
		return process;
	}

	public void setProcess(ProcessEntity process) {
		this.process = process;
	}

	public ProcessGroupEntity getGroup() {
		return group;
	}

	public void setGroup(ProcessGroupEntity group) {
		this.group = group;
	}

	public String getCnContent() {
		return cnContent;
	}

	public void setCnContent(String cnContent) {
		this.cnContent = cnContent;
	}

	public String getCnOptionA() {
		return cnOptionA;
	}

	public void setCnOptionA(String cnOptionA) {
		this.cnOptionA = cnOptionA;
	}

	public String getCnOptionB() {
		return cnOptionB;
	}

	public void setCnOptionB(String cnOptionB) {
		this.cnOptionB = cnOptionB;
	}

	public String getCnOptionC() {
		return cnOptionC;
	}

	public void setCnOptionC(String cnOptionC) {
		this.cnOptionC = cnOptionC;
	}

	public String getCnOptionD() {
		return cnOptionD;
	}

	public void setCnOptionD(String cnOptionD) {
		this.cnOptionD = cnOptionD;
	}

	public String getCnExplanation() {
		return cnExplanation;
	}

	public void setCnExplanation(String cnExplanation) {
		this.cnExplanation = cnExplanation;
	}

	public String getEnContent() {
		return enContent;
	}

	public void setEnContent(String enContent) {
		this.enContent = enContent;
	}

	public String getEnOptionA() {
		return enOptionA;
	}

	public void setEnOptionA(String enOptionA) {
		this.enOptionA = enOptionA;
	}

	public String getEnOptionB() {
		return enOptionB;
	}

	public void setEnOptionB(String enOptionB) {
		this.enOptionB = enOptionB;
	}

	public String getEnOptionC() {
		return enOptionC;
	}

	public void setEnOptionC(String enOptionC) {
		this.enOptionC = enOptionC;
	}

	public String getEnOptionD() {
		return enOptionD;
	}

	public void setEnOptionD(String enOptionD) {
		this.enOptionD = enOptionD;
	}

	public String getEnExplanation() {
		return enExplanation;
	}

	public void setEnExplanation(String enExplanation) {
		this.enExplanation = enExplanation;
	}

	public int getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}

	public double getAverageScore() {
		return averageScore;
	}

	public void setAverageScore(double averageScore) {
		this.averageScore = averageScore;
	}

	public int getScoreTimes() {
		return scoreTimes;
	}

	public void setScoreTimes(int scoreTimes) {
		this.scoreTimes = scoreTimes;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getCnPicture() {
		return cnPicture;
	}

	public void setCnPicture(String cnPicture) {
		this.cnPicture = cnPicture;
	}

	public String getEnPicture() {
		return enPicture;
	}

	public void setEnPicture(String enPicture) {
		this.enPicture = enPicture;
	}

	public String getVideoPath() {
		return videoPath;
	}

	public void setVideoPath(String videoPath) {
		this.videoPath = videoPath;
	}

	public String getVideoExt() {
		return videoExt;
	}

	public void setVideoExt(String videoExt) {
		this.videoExt = videoExt;
	}

}
