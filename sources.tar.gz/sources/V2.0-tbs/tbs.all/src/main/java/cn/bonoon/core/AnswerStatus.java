package cn.bonoon.core;

/**
 * 
 * 对状态的定义：
 * 0-错题
 * 1-已经做对了
 * 2-做对过，但又错了
 * 3-不在错题库里显示
 * 
 * @author jackson
 *
 */
public interface AnswerStatus {
	int WRONG_STATUS_WRONG = 0;
	int WRONG_STATUS_RIGHT = 1;
	int WRONG_STATUS_TOO = 2;
	int WRONG_STATUS_ALLRIGHT = 3;
	

	int ANSWER_STATUS_DOING = 0;
	int ANSWER_STATUS_FINISH = 1;
	int ANSWER_STATUS_GIVEUP = 2;
}
