package cn.bonoon.entities;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "T_PROCESSGROUP")
public class ProcessGroupEntity extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8763894698854328330L;

}
