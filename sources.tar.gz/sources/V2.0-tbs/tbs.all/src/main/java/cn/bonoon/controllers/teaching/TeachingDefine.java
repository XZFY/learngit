package cn.bonoon.controllers.teaching;

import cn.bonoon.kernel.annotations.OptionArray;
import cn.bonoon.kernel.annotations.ResetProperties;
import cn.bonoon.kernel.annotations.ResetProperty;

@ResetProperties({
	@ResetProperty(value = "teacher", name = "教师名称"),
	@ResetProperty(value = "tel", name = "电话"),
	@ResetProperty(value = "phone", name = "手机"),
	@ResetProperty(value = "classes", name = "班级"),
	@ResetProperty(value = "createAt", name = "任课时间"),
	@ResetProperty(value = "courseName", name = "课程"),
	@ResetProperty(value = "remark", name = "备注"),
	@ResetProperty(value = "status", name = "状态", options = @OptionArray({"未审", "任课中", "临时", "结束"}))
})
public interface TeachingDefine {

}
