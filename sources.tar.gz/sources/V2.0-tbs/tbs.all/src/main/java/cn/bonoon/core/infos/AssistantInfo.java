package cn.bonoon.core.infos;

import java.util.ArrayList;
import java.util.List;

import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.entities.AnswerStatisticsItem;
import cn.bonoon.entities.AnswerStatisticsType;
import cn.bonoon.entities.BaseEntity;
import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.entities.ProcessEntity;
import cn.bonoon.entities.ProcessGroupEntity;


public class AssistantInfo {
	
	private final StringBuilder heads = new StringBuilder();
	private final List<String> mapped = new ArrayList<>();
	private final List<AssistantItem> items;
	private int width = 302;
	private final boolean tpi;
	private final List<ProcessGroupEntity> groups;
	
	public AssistantInfo(int size, boolean tpi, List<KnowledgeAreaEntity> kas, List<ProcessEntity> ps, List<ProcessGroupEntity> gs){
		this.items = new ArrayList<>(size);
		this.tpi = tpi;
		this.groups = gs;
		
		read(AnswerStatisticsType.AREA, kas);
		read(AnswerStatisticsType.PROCESS, ps);
		read(AnswerStatisticsType.GROUP, gs);
	}
	
	public int getWidth() {
		return width;
	}
	
	private void read(AnswerStatisticsType type, List<? extends BaseEntity> bs){
		for(BaseEntity k : bs){
			mapped.add(type.toKey(k.getId()));
			heads.append("<th style='width:60px;'>").append(k.getName()).append("</th>");
			width += 60;
		}
	}
	
	@Override
	public String toString() {
		StringBuilder html = new StringBuilder();
		html.append("<thead><tr><th style='width:40px;'>序号</th><th style='width:200px;'></th><th style='width:100px;'>时间</th>").append(heads);
		html.append("</tr></thead><tbody>");
		int i = 1;
		for(AssistantItem ai : items){
			html.append("<tr><td>").append(i++).append("</td>");
			ai.render(html, mapped);
			html.append("</tr>");
		}
		int size = mapped.size() + 2;
		for(; i <= 10; i++){
			html.append("<tr><td>").append(i).append("</td><td colspan='").append(size).append("'></td></tr>");
		}
		if(tpi){
			html.append("<tr><td>预测</td><td colspan='").append(size).append("'>");
			if(null != groups && null != answer && null != asItems){
				double total = 0d, right = 0d;
				for(AnswerStatisticsItem asi : asItems){
					if(asi.getType() == AnswerStatisticsType.GROUP){
						Long tid = asi.getTid();
						for(ProcessGroupEntity g : groups){
							if(tid.equals(g.getId())){
								double weight = g.getWeight();
								if(weight > 0){
									weight *= 100;
								}else{
									weight = 100d;
								}
								total += asi.getTotal() * weight;
								right += asi.getRight() * weight;
								break;
							}
						}
					}
				}
				int s = (int)(right / total);
				String r = s < 70 ? "可能通不过考试" : "可以通过考试";
				html.append(r);
			}
			html.append("</td></tr>");
		}
		html.append("</tbody>");
		return html.toString();
	}
	
	private AssistantItem lastItem;
	private AnswerEntity answer;
	private List<AnswerStatisticsItem> asItems;
	
	public void add(AnswerEntity answer, List<AnswerStatisticsItem> asItems) {
		lastItem = new AssistantItem(answer, asItems, tpi);
		items.add(lastItem);
		if(lastItem.isCanTpi()){
			this.answer = answer;
			this.asItems = asItems;
		}
	}
}
