package cn.bonoon.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.IAccountEditor;
import cn.bonoon.core.TeacherService;
import cn.bonoon.entities.TeacherEntity;
import cn.bonoon.entities.plugins.FlagType;
import cn.bonoon.entities.plugins.RoleAssignEntity;
import cn.bonoon.entities.plugins.RoleEntity;
import cn.bonoon.kernel.events.OperateEvent;
import cn.bonoon.kernel.support.PasswordVerifier;
import cn.bonoon.kernel.support.services.AbstractService;

@Service
@Transactional(readOnly = true)
public class TeacherServiceImpl extends AbstractService<TeacherEntity> implements TeacherService {

	@Autowired
	private PasswordVerifier passwordVerifier;
	
	@Override
	protected TeacherEntity __save(OperateEvent event, TeacherEntity entity) {
		IAccountEditor pe = (IAccountEditor)event.getSource();
		passwordVerifier.set(entity, pe);
		entity.setFlag(FlagType.USER);
		
		TeacherEntity _entity = super.__save(event, entity);
		Long[] roles = pe.getRoles();
		if (null != roles && roles.length > 0) {
			for (Long role : roles) {
				RoleAssignEntity rae = new RoleAssignEntity();
				rae.setAccount(_entity);
				rae.setRole(entityManager.find(RoleEntity.class, role));
				rae.setCreateAt(event.now());
				rae.setCreatorId(event.getId());
				entityManager.persist(rae);
			}
		}
		return _entity;
	}
}
