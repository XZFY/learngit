package cn.bonoon.controllers.teacher;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.core.TeacherService;
import cn.bonoon.entities.TeacherEntity;
import cn.bonoon.kernel.web.annotations.grid.GridStandardDefinition;
import cn.bonoon.kernel.web.controllers.AbstractGridController;

@Controller
@RequestMapping("s/tms/teacher")
public class TeacherController extends AbstractGridController<TeacherEntity, TeacherItem>{
	private final TeacherService service;
	@Autowired
	public TeacherController(TeacherService service) {
		super(service);
		this.service = service;
	}

	@Override
	protected Class<TeacherItem> itemClass() {
		return TeacherItem.class;
	}

	@Override
	@GridStandardDefinition(
			insertClass = TeacherInserter.class, 
			updateClass = TeacherUpdater.class, 
			detailClass = TeacherDetail.class)
	protected TeacherService initLayoutGrid(LayoutGridRegister register) throws Exception {
		return service;
	}
}
