package cn.bonoon.controllers.pager;

import cn.bonoon.controllers.topic.TopicDefine;
import cn.bonoon.kernel.query.PageCondition;
import cn.bonoon.kernel.web.annotations.condition.ConditionContent;
import cn.bonoon.kernel.web.annotations.condition.ConditionStyle;

@ConditionStyle(2)
public class PagerTopicCondition extends PageCondition implements TopicDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2902416768439305901L;
	@ConditionContent(ordinal = 10)
	private Boolean searchExam;
	@ConditionContent(ordinal = 11)
	private Boolean searchReal;
	@ConditionContent(ordinal = 0)
	private String searchContent;
	@ConditionContent(ordinal = 1)
	private Integer searchDifficulty;
	
	public Boolean getSearchExam() {
		return searchExam;
	}
	public void setSearchExam(Boolean searchExam) {
		this.searchExam = searchExam;
	}
	public Boolean getSearchReal() {
		return searchReal;
	}
	public void setSearchReal(Boolean searchReal) {
		this.searchReal = searchReal;
	}
	public String getSearchContent() {
		return searchContent;
	}
	public void setSearchContent(String searchContent) {
		this.searchContent = searchContent;
	}
	public Integer getSearchDifficulty() {
		return searchDifficulty;
	}
	public void setSearchDifficulty(Integer searchDifficulty) {
		this.searchDifficulty = searchDifficulty;
	}
	
}
