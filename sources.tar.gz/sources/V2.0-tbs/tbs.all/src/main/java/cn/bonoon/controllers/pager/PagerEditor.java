package cn.bonoon.controllers.pager;

import cn.bonoon.kernel.annotations.Transform;
import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.support.models.ObjectEditor;
import cn.bonoon.kernel.web.annotations.components.AsNumberBox;
import cn.bonoon.kernel.web.annotations.components.AsSelector;
import cn.bonoon.kernel.web.annotations.components.AsTextArea;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;

@Transform
@FormEditor(headWidth = 120, width = 250)
public class PagerEditor extends ObjectEditor implements PagerDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3971724844142106883L;

	@TransformField
	@PropertyEditor(0)
	private String name;
	
	@TransformField
	@PropertyEditor(10)
	@AsSelector
	private int type;

	@TransformField
	@PropertyEditor(20)
	@AsNumberBox
	private int amount;

	@TransformField
	@PropertyEditor(21)
	private boolean diamond;

	@TransformField
	@PropertyEditor(30)
	@AsSelector
	private int status;

	@TransformField
	@PropertyEditor(31)
	private boolean trial;

	@TransformField
	@PropertyEditor(40)
	@AsTextArea
	private String remark;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

//	public int getPoints() {
//		return points;
//	}
//
//	public void setPoints(int points) {
//		this.points = points;
//	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public boolean isTrial() {
		return trial;
	}

	public void setTrial(boolean trial) {
		this.trial = trial;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public boolean isDiamond() {
		return diamond;
	}

	public void setDiamond(boolean diamond) {
		this.diamond = diamond;
	}
	
}
