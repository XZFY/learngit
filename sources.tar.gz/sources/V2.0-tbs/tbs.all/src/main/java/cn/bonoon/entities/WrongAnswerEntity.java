package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

/**
 * <pre>
 * 答错的题目，会在我的错题集里出现
 * 
 * 对状态的定义：{@link cn.bonoon.core.AnswerStatus}
 * </pre>
 * @author jackson
 *
 */
@Entity
@Table(name = "T_WRONGANSWER")
public class WrongAnswerEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1180123918559846167L;

	/**
	 * 会员的key值
	 */
	@Column(name = "C_KEY")
	private String key;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CREATEAT")
	private Date createAt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_PRACTICEAT")
	private Date practiceAt;
	
	@ManyToOne
	@JoinColumn(name = "R_TOPIC_ID")
	private TopicEntity topic;

	@Column(name = "C_REMARK", length = 50)
	private String remark;
	
	@Column(name = "C_ANSWER", length = 10)
	private String answer;
	
//
//	@Column(name = "C_WRONGCOUNT")
//	private int wrongCount;
//
//	@Temporal(TemporalType.TIMESTAMP)
//	@Column(name = "C_LASTUPDATEAT")
//	private Date lastUpdateAt;
//	
//	/**
//	 * 以前回答的历史记录
//	 */
//	@Column(name = "C_ANSWERHISTORY")
//	private String answerHistory;
//	@Temporal(TemporalType.TIMESTAMP)
//	@Column(name = "C_LASTANSWERAT")
//	private Date lastAnswerAt;
//	
//	@Column(name = "C_STATUS")
//	private int status;
//	
	public TopicEntity getTopic() {
		return topic;
	}
	
	public void setTopic(TopicEntity topic) {
		this.topic = topic;
	}
	
	public Date getCreateAt() {
		return createAt;
	}
	
	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}


	public String getAnswer() {
		return answer;
	}
	
	public void setAnswer(String answer) {
		this.answer = answer;
	}


	public String getKey() {
		return key;
	}
	
	public void setKey(String key) {
		this.key = key;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getPracticeAt() {
		return practiceAt;
	}

	public void setPracticeAt(Date practiceAt) {
		this.practiceAt = practiceAt;
	}
	
}
