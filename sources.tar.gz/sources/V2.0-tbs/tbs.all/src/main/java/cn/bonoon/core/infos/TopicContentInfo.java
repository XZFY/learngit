package cn.bonoon.core.infos;

import java.util.ArrayList;
import java.util.List;

import cn.bonoon.entities.DocContentEntity;
import cn.bonoon.entities.MediaContentEntity;

/**
 * 用于题目相关知识学习的对象
 * @author jackson
 *
 */
public class TopicContentInfo {
	
	private List<TopicContentItem> items = new ArrayList<>();

	public void add(MediaContentEntity entity) {
		items.add(new TopicContentItem(entity));
	}

	public void add(DocContentEntity entity) {
		items.add(new TopicContentItem(entity));
	}
	
	public List<TopicContentItem> getItems() {
		return items;
	}

	public void setItems(List<TopicContentItem> items) {
		this.items = items;
	}
//
//	public static class IdValue{
//		
//		private Long id;
//		
//		private String value;
//		
//		public IdValue(Long id, String value){
//			this.id = id;
//			this.value = value;
//		}
//		
//		public String getValue() {
//			return value;
//		}
//		
//		public void setValue(String value) {
//			this.value = value;
//		}
//
//		public Long getId() {
//			return id;
//		}
//
//		public void setId(Long id) {
//			this.id = id;
//		}
//		
//	}

}
