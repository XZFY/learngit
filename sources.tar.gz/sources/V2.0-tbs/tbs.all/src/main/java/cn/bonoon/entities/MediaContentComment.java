package cn.bonoon.entities;

import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name = "CT_MEDIACONTENT")
public class MediaContentComment extends AbstractComment<MediaContentEntity>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7669098032806363535L;
}
