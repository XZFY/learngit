package cn.bonoon.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.ProcessService;
import cn.bonoon.entities.ProcessEntity;
import cn.bonoon.kernel.support.services.AbstractService;

@Service
@Transactional(readOnly = true)
public class ProcessServiceImpl extends AbstractService<ProcessEntity> implements ProcessService{

	@Override
	public String getName(Long id) {
		String ql = "select x.name from ProcessEntity x where x.id=?";
		return __first(String.class, ql, id);
	}

}
