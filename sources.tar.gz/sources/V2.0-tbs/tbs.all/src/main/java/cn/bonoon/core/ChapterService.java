package cn.bonoon.core;

import cn.bonoon.entities.ChapterEntity;
import cn.bonoon.kernel.support.services.GenericService;

public interface ChapterService extends GenericService<ChapterEntity>{

}
