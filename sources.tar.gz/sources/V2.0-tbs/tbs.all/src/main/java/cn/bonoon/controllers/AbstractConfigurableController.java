package cn.bonoon.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import cn.bonoon.core.ConfigService;
import cn.bonoon.core.MemberService;
import cn.bonoon.core.configs.HelperMessageConfig;
import cn.bonoon.core.configs.OpenedPointsConfig;
import cn.bonoon.core.configs.SitSettingConfig;
import cn.bonoon.core.configs.TouristChannelConfig;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.MemberGradeEntity;
import cn.bonoon.entities.MemberSettingEntity;
import cn.bonoon.kernel.events.BaseEvent;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.util.StringHelper;
import cn.bonoon.kernel.web.controllers.AbstractController;

/**
 * 这个父为类可以用于统一的读取当前会员的配置信息
 * @author jackson
 *
 */
public abstract class AbstractConfigurableController extends AbstractController{
	
	@Autowired
	protected ConfigService configService;
	
	@Autowired
	protected MemberService memberService;
	
	protected static final Object OBJECT = new Object();
	
	@Override
	@ModelAttribute("logon")
	public LogonUser getUser(){
		LogonUser user = super.getUser();
		if(null != user && "true".equals(user.get("user-member"))){
			return user;
		}
		return null;
	}
	
	/**
	 * 在master母板页面上显示提示信息
	 * @param model
	 * @param msg
	 */
	protected void tooltip(Model model, String msg){
		model.addAttribute("msgTooltip", msg);
	}
	
	/**
	 * 在加载完当前页面后，自动弹出提示对话框
	 * @param model
	 * @param msg
	 */
	protected void alert(Model model, String msg){
		model.addAttribute("alertMessage", "alert('" + msg + "');");
	}

	protected OpenedPointsConfig config(){
		OpenedPointsConfig opc = new OpenedPointsConfig();
		configService.read(new BaseEvent(opc), OpenedPointsConfig.class);
		return opc;
	}
	
	//未登录的都会进到这里来的
	protected TouristChannelConfig nologinConfig(Model model, HttpServletRequest request){
		TouristChannelConfig csc = new TouristChannelConfig();
		configService.read(new BaseEvent(csc), TouristChannelConfig.class);
		model.addAttribute("channelConfig", csc);

		//客服
		SitSettingConfig ssc = new SitSettingConfig();
		configService.read(new BaseEvent(ssc), SitSettingConfig.class);
		model.addAttribute("ssc", ssc);
		
		HttpSession hs = request.getSession();
		if(ssc.isOpenEnrollment() || hs.getAttribute("introducekey") != null){
			//可以开放注册
			model.addAttribute("canEnrollment", true);
		}
		
		if(hs.getAttribute("no-first-access") == null){
			HelperMessageConfig hmc = new HelperMessageConfig();
			configService.read(new BaseEvent(hmc), HelperMessageConfig.class);
			if(StringHelper.isNotEmpty(hmc.getMessage_0())){
				addMessage(model, request, hmc.getMessage_0());
			}
			hs.setAttribute("no-first-access", OBJECT);
		}
		
		return csc;
	}
	
	//登录后的都会进到这里来的
	protected OpenedPointsConfig loginConfig(Model model, HttpServletRequest request, MemberSettingEntity fm){
		//所有的提示
		MemberEntity member = fm.getMember();
		List<String> tips = addMessage(model, request, memberService.tips(member));
		Long oldGrade = member.getGrade();
		OpenedPointsConfig opc = config();
		MemberGradeEntity mge = memberService.getGrade(member);
		if(null != mge){//找得到会员相应的级别
			model.addAttribute("gradeName", mge.getName());
			
			HelperMessageConfig hmc = new HelperMessageConfig();
			configService.read(new BaseEvent(hmc), HelperMessageConfig.class);
			if(!mge.getId().equals(oldGrade)){
				//不一样则表示已经升级
				String cnt = hmc.getMessage_7();
				if(StringHelper.isNotEmpty(cnt)){
					cnt = cnt.replace("{用户名}", member.getName());
					cnt = cnt.replace("{等级分}", String.valueOf(member.getLevelPoints()));
					cnt = cnt.replace("{等级名}", mge.getName());
					tips.add(cnt);
				}
			}
//			long lp = member.getLevelPoints();//当前用户的等级积分
//			long ap = member.getAvailablePoints();//当前用户的可兑换积分
//			long ac = member.getAvailableCash();//可用的钻石，即相当于现金
//			//是否还有功能未打开
//			if(!fm.isAssistantOpened() && lp > opc.getAssistantReach()){
//				
//			}
//			
//			//关于升级的定期提示
//			String cm9 = hmc.getMessage_9();
//			String rttype = hmc.getRechargeTips();
//			if(StringHelper.isNotEmpty(cm9) && StringHelper.isNotEmpty(rttype)){
//				HttpSession hs = request.getSession();
//				switch (rttype) {
//				case "登录时":
//					if(hs.getAttribute("no-first-recharge-tips") == null){
//						//进行一次的提示
//						hs.setAttribute("no-first-recharge-tips", OBJECT);
//						//MemberGradeEntity nexm = memberService.next(mge);
//						if(null != nexm){
//							//
//							CashExchangeConfig cec = new CashExchangeConfig();
//							configService.read(new BaseEvent(cec), CashExchangeConfig.class);
//							int cp = cec.getCashPoints();
//							if(cp > 0){
//								long dt = nexm.getPointsLine() - member.getLevelPoints() + cp - 1;
//								//差额
//								long tm = dt / cp;
//								cm9 = cm9.replace("{用户名}", member.getName());
//								cm9 = cm9.replace("{等级名}", mge.getName());
//								cm9 = cm9.replace("{功能}", mge.getName());
//							}
//						}
//					}
//					break;
//				case "每次请求":
//					
//					break;
//				case "每半小时后":
//					
//					break;
//				case "每小时后":
//					
//					break;
//				}
//			}
		}else{
			model.addAttribute("gradeName", "无");
		}
		if(StringHelper.isNotEmpty(member.getPic())){
			model.addAttribute("personalHead", toUrl(member.getPic()));
		}else{
			model.addAttribute("personalHead", toUrl("/r/images/user-empty.png"));
		}
		model.addAttribute("myPoints", member.getAvailablePoints());
		model.addAttribute("myCash", member.getAvailableCash());
		model.addAttribute("config", opc);
		//客服
		SitSettingConfig ssc = new SitSettingConfig();
		configService.read(new BaseEvent(ssc), SitSettingConfig.class);
		model.addAttribute("ssc", ssc);
		return opc;
	}
	
	protected MemberSettingEntity funMapping(Model model, LogonUser user){
		MemberSettingEntity fm = memberService.getFunctionMapping(user);
		model.addAttribute("funMapping", fm);
		return fm;
	}
	
	protected List<String> addMessage(Model model, HttpServletRequest request, String... msg){
		List<String> msgs = __message(model, request);
		for(String m : msg){
			msgs.add(m);
		}
		return msgs;
	}

	@SuppressWarnings("unchecked")
	private List<String> __message(Model model, HttpServletRequest request) {
		List<String> msgs;
		if(model.containsAttribute("helperMessages")){
			msgs = (List<String>)model.asMap().get("helperMessages");
		}else{
			HttpSession hs = request.getSession();
			Object hms = hs.getAttribute("helperMessages");
			if(hms instanceof List){
				msgs = (List<String>)hms;
			}else{
				msgs = new ArrayList<>();
				hs.setAttribute("helperMessages", msgs);
			}
			model.addAttribute("helperMessages", msgs);
		}
		return msgs;
	}
	
	protected List<String> addMessage(Model model, HttpServletRequest request, List<String> msg){
		List<String> msgs = __message(model, request);
		msgs.addAll(msg);
		return msgs;
	}
}
