package cn.bonoon.core.configs;

import cn.bonoon.kernel.web.annotations.components.AsNumberBox;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

//当有效完成的人数大于3的情况下，则正常；大于1小于等于3则只有一个第一名，其他人都是参与奖；只有一个人完成的情况下，只有参与奖
@FormEditor(value = 2, headWidth = 140, width = 280)
public class CompetitionConfig {

	@AsNumberBox
	@PropertyEditor(name = "第一名", value = 0)
	@PropertyHelper(value = "对练得第一名的奖励积分", type = HelperType.WRAP)
	private int firstAward;//第一名奖励的积分

	@AsNumberBox
	@PropertyEditor(name = "第二名", value = 1)
	@PropertyHelper(value = "对练得第二名的奖励积分", type = HelperType.WRAP)
	private int secondAward;

	@AsNumberBox
	@PropertyEditor(name = "第三名", value = 2)
	@PropertyHelper(value = "对练得第三名的奖励积分", type = HelperType.WRAP)
	private int thirdAward;

	@AsNumberBox
	@PropertyEditor(name = "参与奖", value = 3)
	@PropertyHelper(value = "参与对练并完成比较的会员的积分奖励", type = HelperType.WRAP)
	private int participationAward;//参与奖

	@AsNumberBox
	@PropertyEditor(name = "发起对练", value = 10)
	@PropertyHelper(value = "会员发起一次对练需要消耗的积分", type = HelperType.WRAP)
	private int launchCost;//发起对练需要消费的积分

	public int getFirstAward() {
		return firstAward;
	}

	public void setFirstAward(int firstAward) {
		this.firstAward = firstAward;
	}

	public int getSecondAward() {
		return secondAward;
	}

	public void setSecondAward(int secondAward) {
		this.secondAward = secondAward;
	}

	public int getThirdAward() {
		return thirdAward;
	}

	public void setThirdAward(int thirdAward) {
		this.thirdAward = thirdAward;
	}

	public int getParticipationAward() {
		return participationAward;
	}

	public void setParticipationAward(int participationAward) {
		this.participationAward = participationAward;
	}

	public int getLaunchCost() {
		return launchCost;
	}

	public void setLaunchCost(int launchCost) {
		this.launchCost = launchCost;
	}
	
}
