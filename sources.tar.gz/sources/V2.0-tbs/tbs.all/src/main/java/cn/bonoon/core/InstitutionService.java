package cn.bonoon.core;

import cn.bonoon.entities.TrainingInstitutionEntity;
import cn.bonoon.kernel.support.services.GenericService;

public interface InstitutionService extends GenericService<TrainingInstitutionEntity>{

}
