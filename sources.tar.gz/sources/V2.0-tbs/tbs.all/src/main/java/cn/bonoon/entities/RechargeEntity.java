package cn.bonoon.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

@Entity
@Table(name = "T_RECHARGE")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class RechargeEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6649456121332066008L;

	@ManyToOne
	@JoinColumn(name = "R_MEMBER_ID")
	private MemberEntity member;

	@Column(name = "C_TYPENAME")
	protected String typeName;

	@Column(name = "C_ORDERAMOUNT")
	private double orderAmount;

	@Column(name = "C_ORDERID")
	private String orderId;

	@Column(name = "C_ORDERTIME")
	private String orderTime;
	//交易ID
	@Column(name = "C_DEALID")
	private String dealId;
	
	@Column(name = "C_DEALTIME")
	private String dealTime;
	
	@Column(name = "C_PAYTYPE")
	private String payType;
	
	@Column(name = "C_BANKDEALID")
	private String bankDealId;

	@Column(name = "C_PAYAMOUNT")
	private double payAmount;

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public double getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(double orderAmount) {
		this.orderAmount = orderAmount;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}

	public String getDealId() {
		return dealId;
	}

	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	public String getDealTime() {
		return dealTime;
	}

	public void setDealTime(String dealTime) {
		this.dealTime = dealTime;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public String getBankDealId() {
		return bankDealId;
	}

	public void setBankDealId(String bankDealId) {
		this.bankDealId = bankDealId;
	}

	public double getPayAmount() {
		return payAmount;
	}

	public void setPayAmount(double payAmount) {
		this.payAmount = payAmount;
	}

	public MemberEntity getMember() {
		return member;
	}

	public void setMember(MemberEntity member) {
		this.member = member;
	}
}
