package cn.bonoon.controllers.teaching;

import cn.bonoon.entities.ClassesEntity;
import cn.bonoon.entities.TeacherEntity;
import cn.bonoon.kernel.annotations.Transform;
import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.support.models.ObjectEditor;
import cn.bonoon.kernel.web.annotations.AutoDataLoader;
import cn.bonoon.kernel.web.annotations.components.AsComboBox;
import cn.bonoon.kernel.web.annotations.components.AsSelector;
import cn.bonoon.kernel.web.annotations.components.AsTextArea;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;

@Transform
@FormEditor
public class TeachingEditor extends ObjectEditor implements TeachingDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8482319549753844751L;

	@TransformField
	@PropertyEditor(0)
	@AsComboBox
	@AutoDataLoader(TeacherEntity.class)
	private Long teacher;

	@TransformField
	@PropertyEditor(10)
	@AsComboBox
	@AutoDataLoader(ClassesEntity.class)
	private Long classes;

	@TransformField
	@PropertyEditor(20)
	private String courseName;

	@TransformField
	@PropertyEditor(20)
	@AsSelector
	private int status;

	@TransformField
	@PropertyEditor(40)
	@AsTextArea
	private String remark;

	public Long getTeacher() {
		return teacher;
	}

	public void setTeacher(Long teacher) {
		this.teacher = teacher;
	}

	public Long getClasses() {
		return classes;
	}

	public void setClasses(Long classes) {
		this.classes = classes;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
}
