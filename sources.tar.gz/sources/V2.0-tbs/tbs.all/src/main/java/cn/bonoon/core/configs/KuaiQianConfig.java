package cn.bonoon.core.configs;

import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

@FormEditor(headWidth = 120, width = 720)
public class KuaiQianConfig {
	@PropertyEditor(name = "商户账户号", value = 0, width = 250)
	@PropertyHelper(value = "商户的人民币账户号", type = HelperType.DIRECT)
	private String pkiCode;
	@PropertyEditor(name = "商户密钥", value = 10, width = 250)
	@PropertyHelper(value = "密钥区分大小写", type = HelperType.DIRECT)
	private String pkiKey;
	@PropertyEditor(name = "密钥别名", value = 20, width = 250)
	@PropertyHelper(value = "加载时使用", type = HelperType.DIRECT)
	private String pkiKeyAlias;
	@PropertyEditor(name = "提交地址", value = 30, width = 400)
	@PropertyHelper(value = "快钱接受处理的地址", type = HelperType.DIRECT)
	private String pkiUrl;
	@PropertyEditor(name = "pfx文件", value = 40, width = 300)
	@PropertyHelper(value = "加密/解密", type = HelperType.DIRECT)
	private String pkipfxPath;
	@PropertyEditor(name = "cer文件", value = 50, width = 300)
	@PropertyHelper(value = "加密/解密", type = HelperType.DIRECT)
	private String pkicerPath;
	@PropertyEditor(name = "签名类型", value = 51, width = 100)
	@PropertyHelper(value = "1 代表MD5加密签名方式；4 代表PKI证书签名方式", type = HelperType.DIRECT)
	private String pkisignType;
	public String getPkiCode() {
		return pkiCode;
	}
	public void setPkiCode(String pkiCode) {
		this.pkiCode = pkiCode;
	}
	public String getPkiKey() {
		return pkiKey;
	}
	public void setPkiKey(String pkiKey) {
		this.pkiKey = pkiKey;
	}
	public String getPkiKeyAlias() {
		return pkiKeyAlias;
	}
	public void setPkiKeyAlias(String pkiKeyAlias) {
		this.pkiKeyAlias = pkiKeyAlias;
	}
	public String getPkiUrl() {
		return pkiUrl;
	}
	public void setPkiUrl(String pkiUrl) {
		this.pkiUrl = pkiUrl;
	}
	public String getPkipfxPath() {
		return pkipfxPath;
	}
	public void setPkipfxPath(String pkipfxPath) {
		this.pkipfxPath = pkipfxPath;
	}
	public String getPkicerPath() {
		return pkicerPath;
	}
	public void setPkicerPath(String pkicerPath) {
		this.pkicerPath = pkicerPath;
	}
	public String getPkisignType() {
		return pkisignType;
	}
	public void setPkisignType(String pkisignType) {
		this.pkisignType = pkisignType;
	}
}
