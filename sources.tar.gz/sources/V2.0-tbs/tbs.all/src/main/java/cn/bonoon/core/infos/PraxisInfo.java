package cn.bonoon.core.infos;

public class PraxisInfo extends AbstractRecord{
	private int times;//次数

	public int getTimes() {
		return times;
	}

	public void setTimes(int times) {
		this.times = times;
	}
}
