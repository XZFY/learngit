package cn.bonoon.controllers.student;

import cn.bonoon.kernel.annotations.Transform;
import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.annotations.WriteModel;
import cn.bonoon.kernel.util.BoolType;
import cn.bonoon.kernel.web.annotations.form.FormUpdate;
import cn.bonoon.kernel.web.annotations.form.PropertyUpdate;

@Transform
@FormUpdate(2)
public class StudentUpdater extends StudentEditor{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6811676856395765236L;

	@TransformField(writable = WriteModel.NONE, value = "member.")
	@PropertyUpdate(readonly = BoolType.TRUE, value = 1)
	private String loginName;

	@TransformField(writable = WriteModel.NONE, value = "member.")
	@PropertyUpdate(readonly = BoolType.TRUE, value = 2)
	private String name;
	
	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
