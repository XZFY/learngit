package cn.bonoon.controllers.member;

import cn.bonoon.entities.plugins.PlaceEntity;
import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.support.models.ObjectEditor;
import cn.bonoon.kernel.web.annotations.AutoDataLoader;
import cn.bonoon.kernel.web.annotations.components.AsTextArea;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;

public abstract class MemberEditor extends ObjectEditor implements MemberDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1263821334528696893L;

	@TransformField
	@PropertyEditor(1)
	private String name;
	
	@TransformField
	@PropertyEditor(10)
	private String phone;
	@TransformField
	@PropertyEditor(11)
	private String email;

	@TransformField
	@PropertyEditor(13)
	private String homeTel;
	@TransformField
	@PropertyEditor(12)
	private String qq;
	
	@TransformField
	@PropertyEditor(14)
	private String companyTel;
	@TransformField
	@PropertyEditor(15)
	@AutoDataLoader(PlaceEntity.class)
	private Long place;
	
	@TransformField
	@PropertyEditor(value = 20, colspan = 1)
	private String homeAddress;
	
	@TransformField
	@PropertyEditor(value = 21, colspan = 1)
	private String companyName;
	@TransformField
	@PropertyEditor(value = 23, colspan = 1)
	private String trainingOrg;
	@TransformField
	@PropertyEditor(value = 22, colspan = 1)
	private String companyAddress;
	
	@PropertyEditor(value = 100, colspan = 1)
	@AsTextArea
	private String remark;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getHomeTel() {
		return homeTel;
	}
	public void setHomeTel(String homeTel) {
		this.homeTel = homeTel;
	}
	public String getQq() {
		return qq;
	}
	public void setQq(String qq) {
		this.qq = qq;
	}
	public String getCompanyTel() {
		return companyTel;
	}
	public void setCompanyTel(String companyTel) {
		this.companyTel = companyTel;
	}
	public Long getPlace() {
		return place;
	}
	public void setPlace(Long place) {
		this.place = place;
	}
	public String getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getTrainingOrg() {
		return trainingOrg;
	}
	public void setTrainingOrg(String trainingOrg) {
		this.trainingOrg = trainingOrg;
	}
	public String getCompanyAddress() {
		return companyAddress;
	}
	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
}
