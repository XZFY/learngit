package cn.bonoon.controllers.studying;

import cn.bonoon.kernel.annotations.OptionArray;
import cn.bonoon.kernel.annotations.ResetProperties;
import cn.bonoon.kernel.annotations.ResetProperty;

@ResetProperties({
	@ResetProperty(value = "student", name = "学员名称"),
	@ResetProperty(value = "seatNumber", name = "座位号"),
	@ResetProperty(value = "phone", name = "手机"),
	@ResetProperty(value = "classes", name = "班级"),
	@ResetProperty(value = "createAt", name = "加入时间"),
	@ResetProperty(value = "status", name = "状态", options = @OptionArray({"未报到", "正常", "转学", "转班", "其它"}))
})
public interface StudyingDefine {

}
