//package cn.bonoon.controllers;
//
//import java.util.Date;
//
//import cn.bonoon.core.configs.OpenedPointsConfig;
//import cn.bonoon.entities.FunctionMappingEntity;
//
//public abstract class AbstractClassesController extends AbstractIndexController{
//
//	@Override
//	protected void init() {
//		functionName 	= "班级";
//		functionMenu 	= "menus/menu-classes.vm";
//		channelSelected = "classes";
//		vmTrial 		= "practices/free";
//		trialTitle 		= "<span style='font-size: 18px; font-family: Arial;padding-left:15px;'>试用</span>";
//	}
//
//	@Override
//	protected boolean hasOpened(FunctionMappingEntity fm) {
//		return fm.isClassOpened();
//	}
//	
//	@Override
//	protected int reachPoint(OpenedPointsConfig opc) {
//		return opc.getClassReach();
//	}
//	
//	@Override
//	protected int openCost(OpenedPointsConfig opc) {
//		return opc.getClassCost();
//	}
//	
//	@Override
//	protected void open(FunctionMappingEntity fm, int cost, Date now) {
//		fm.setClassAt(now);
//		fm.setClassOpened(true);
//		fm.setClassPoints(cost);
//	}
//}
