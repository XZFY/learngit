package cn.bonoon.controllers.topic.comment;

import cn.bonoon.kernel.annotations.ResetProperties;
import cn.bonoon.kernel.annotations.ResetProperty;

@ResetProperties({
	@ResetProperty(value = "content", name = "评论内容"),
	@ResetProperty(value = "createAt", name = "评论时间"),
	@ResetProperty(value = "creatorName", name = "评论人"),
	@ResetProperty(value = "enContent", name = "内容(英)"),
	@ResetProperty(value = "cnContent", name = "内容(中)")
})
public interface TopicCommentDefine {
//content
}
