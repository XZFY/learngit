package cn.bonoon.controllers;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.Util;
import cn.bonoon.core.KnowledgeAreaService;
import cn.bonoon.core.configs.OpenedPointsConfig;
import cn.bonoon.core.configs.PracticeConfig;
import cn.bonoon.entities.BaseEntity;
import cn.bonoon.entities.MemberSettingEntity;
import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.kernel.security.LogonUser;

@Controller
@RequestMapping("pmp/praxis")
public class MemberPraxisController extends AbstractPracticeController{
	@Autowired
	private KnowledgeAreaService knowledgeAreaService;
	
	@Override
	protected void init() {
		functionName 	= "练习";
		functionTitle 	= "练习";
		functionMenu 	= "menus/menu-praxis.vm";
		channelSelected = "praxis";
		vmName 			= "practices/praxis";
		vmTrial 		= "practices/free";
		trialTitle 		= "<span style='font-size: 18px; font-family: Arial;padding-left:15px;'>试用</span>";
	}
	
	@Override
	protected boolean hasOpened(MemberSettingEntity fm) {
		return fm.isPraxisOpened();
	}
	
	@Override
	protected int reachPoint(OpenedPointsConfig opc) {
		return opc.getPraxisReach();
	}
	
	@Override
	protected int openCost(OpenedPointsConfig opc) {
		return opc.getPraxisCost();
	}
	
	@Override
	protected boolean openCoseCash(OpenedPointsConfig opc) {
		return opc.isPraxisCostCash();
	}
	
	@Override
	protected void open(MemberSettingEntity fm, int cost, Date now) {
		fm.setPraxisAt(now);
		fm.setPraxisOpened(true);
		fm.setPraxisPoints(cost);
	}

	@Override
	protected String trial(HttpServletRequest request, Model model) {
		// TODO 提供试用的功能
		Long selectedId = getLong(request, "selectedId");
		List<KnowledgeAreaEntity> kas = knowledgeAreaService.find(" order by x.id asc");
		if(!kas.isEmpty()){
			selectedId = Util.find(kas, selectedId).getId();
				
			model.addAttribute("selectedId", selectedId);
			model.addAttribute("items", kas);
			model.addAttribute("topics", topicService.trialPraxis(selectedId));
		}
		return super.trial(request, model);
	}
	
	@Override
	protected String render(HttpServletRequest request, Model model, MemberEntity member, LogonUser user) {
		//章节的选择
		Long selectedId = getLong(request, "selectedId");
		__items(model, selectedId, user);
		return super.render(request, model, member, user);
	}
	
	@RequestMapping("items.do")
	public String items(Model model, Long selectedId){
		__items(model, selectedId, getUser());
		model.addAttribute("layout", "layout-empty.vm");
		return "practices/praxis-items";
	}
	
	private void __items(Model model, Long selectedId, LogonUser user){
		List<KnowledgeAreaEntity> kas = knowledgeAreaService.find(" order by x.id asc");
		if(!kas.isEmpty()){
			BaseEntity ka = Util.find(kas, selectedId);
			selectedId = ka.getId();
				
			model.addAttribute("items", kas);
			model.addAttribute("selectedId", selectedId);
			model.addAttribute("praxis", topicService.myPraxis(user, selectedId));
		}
	}
	
	@Override
	protected String showProactice(Model model){
		PracticeConfig pc = practiceConfig();
		model.addAttribute("showTopicAnswer", pc.isPraxisAnswer());
		model.addAttribute("topicComment", pc.isPraxisComment());
		model.addAttribute("topicStudy", pc.isPraxisStudy());
		return super.showProactice(model);
	}

	@RequestMapping("{chapterId}!start.do")
	public String start(HttpServletRequest request, Model model, @PathVariable("chapterId") Long chapterId, Integer cc){
		try{
			__title(request, model, chapterId);
			
			if(null == cc || cc < 0){
				cc = 0;
			}
			model.addAttribute("clickCount", cc + 1);
			
			__parse(model, topicService.startPraxis(getUser(), chapterId));
		}catch(Exception ex){
			warning(model, ex);
		}
		return showProactice(model);
	}
	
	@RequestMapping("{chapterId}/{id}!start.do")
	public String start(HttpServletRequest request, Model model, @PathVariable("chapterId") Long chapterId, @PathVariable("id") Long id){
		try{
			__title(request, model, chapterId);
			__parse(model, topicService.startPraxis(getUser(), chapterId, id));
		}catch(Exception ex){
			warning(model, ex);
		}
		return showProactice(model);
	}
	
	@RequestMapping("{chapterId}/{id}!restart.do")
	public String restart(HttpServletRequest request, Model model, @PathVariable("chapterId") Long chapterId, @PathVariable("id") Long id){
		try{	
			__title(request, model, chapterId);
			__parse(model, topicService.restartPraxis(getUser(), chapterId, id));
		}catch(Exception ex){
			warning(model, ex);
		}
		return showProactice(model);
	}
	
	private void __title(HttpServletRequest request, Model model, Long chapterId){
		if(!"p".equals(request.getParameter("in"))){
			model.addAttribute("moreUrl", chapterId + "!start.do");
		}
		showHead(model, knowledgeAreaService.getName(chapterId));
	}
}