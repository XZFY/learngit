package cn.bonoon.core;

import java.util.List;

import cn.bonoon.entities.DocContentEntity;
import cn.bonoon.entities.KnowledgeAreaEntity;
import cn.bonoon.entities.MediaContentEntity;
import cn.bonoon.entities.ProcessEntity;
import cn.bonoon.entities.ProcessGroupEntity;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.models.Page;

public interface MemberCenterService {

	Page wrongs(IOperator user, int page, int size, Boolean en);

	Page progresses(IOperator user, int page, int size);

	Page videos(IOperator user, int page, int size, String name);

	Page documents(IOperator user, int page, int size, String name);

	Page consumers(IOperator user, int page, int size);

	List<KnowledgeAreaEntity> areas();
	
	List<ProcessEntity> processes();
	
	List<ProcessGroupEntity> groups();

	DocContentEntity document(IOperator user, Long id);

	void saveDocument(IOperator user, Long id, String title, String content, String path, Long area, Long group, Long process, boolean share);

	void deleteDocument(IOperator user, Long id);

	MediaContentEntity video(IOperator user, Long id);

	void saveVideo(IOperator user, Long id, String title, String content, String path, Long area, Long group, Long process, boolean share, String ext);

	void deleteVideo(IOperator user, Long id);
}
