package cn.bonoon.controllers;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.io.Resource;

import pki.Pkipair;
import cn.bonoon.core.configs.KuaiQianConfig;
import cn.bonoon.entities.KuaiqianRechargeEntity;
import cn.bonoon.kernel.util.StringHelper;

public class KuaiQianInfo{

	private String kuaiqianUrl = "https://www.99bill.com/gateway/recvMerchantInfoAction.htm?";
	/**
	 * 1 UTF-8
	 * 2 GBK
	 * 3 GB2312
	 */
	private String inputCharset = "1";
	
	/**
	 * 
	 */
	private String pageUrl;
	
	/**
	 * 
	 */
	private String bgUrl;
	/**
	 * 固定值
	 */
	private String version = "v2.0";
	/**
	 * 固定值
	 */
	private String language = "1";
	/**
	 * 固定值：
	 * 1 MD5加密签名方式
	 * 4 PKI证书签名方式
	 */
	private String signType = "1";
	//-----------------------------买卖双方信息参数
	/**
	 * 不可空
	 * 数字串
	 * 用来指定接收款项的人民币账号
	 */
	private String merchantAcctId = "1001181333301";
	/**
	 * 支付人姓名
	 * 可为空
	 */
	private String payerName;
	/**
	 * 支付人联系方式类型
	 * 可为空
	 * 固定值：1
	 * 1 电子邮件方式
	 */
	private String payerContactType;
	/**
	 * 支付人联系方式
	 * 可为空
	 * 根据payerContactType的方式填写对应字符
	 */
	private String payerContact;
	
	//---------------------------业务参数
	/**
	 * 商户订单号
	 * 不可空
	 * 字符串
	 * 只允许使用字母、数字、-、——，并以字母或数字开头
	 * 每商户提交的订单号必须在自身账户交易中唯一
	 */
	private String orderId;
	/**
	 * 商户订单金额
	 * 不可空
	 * 整形数字
	 * 以分为单位，如：10元提交时金额应为：1000
	 */
	private String orderAmount;
	/**
	 * 商户订单提交时间
	 * 不可空
	 * 数字串，一共14位
	 * 格式为：年[4位]月[2位]日[2位]时[2位]分[2位]秒[2位]
	 */
	private String orderTime;
	/**
	 * 商品名称
	 * 可为空
	 * 256
	 * 英文或中文字符串
	 */
	private String productName = "";
	/**
	 * 商品数量
	 * 8
	 * 可为空
	 * 整型数字
	 */
	private String productNum = "1";
	/**
	 * 商品代码
	 * 20
	 * 可为空
	 * 字母、数字或-、_的组合
	 */
	private String productId = "";
	/**
	 * 商品描述
	 * 400
	 * 可为空
	 * 英文或中文字符串
	 */
	private String productDesc = "";
	/**
	 * 扩展字段1、2
	 * 128
	 * 可为空
	 * 英文或中文字符串
	 * 支付完成后按原样返回给商户
	 */
	private String ext1, ext2;
	/**
	 * 支付方式
	 * 2
	 * 不可空
	 * 固定选择值：
	 * 00：其它支付
	 * 01：银行卡网银支付
	 * 11：电话支付
	 * 12：快钱账户支付
	 * 13：线下支付
	 * 14：企业网银在线支付
	 * 15：信用卡在线支付
	 * 17：预付卡支付
	 */
	private String payType;
	/**
	 * 银行代码
	 * 8
	 * 可为空
	 * 仅在银行直连时使用
	 * 银行代码表见参考资料
	 */
	private String bankId;
	/**
	 * 同一订单禁止重复提交标志
	 * 可为空
	 * 固定选择值：
	 * 0 表示同一订单号在没有支付成功的前提下可重复提交多次。
	 * 1 表示同一订单号只允许提交1次
	 * 默认值：0
	 * 建议实物购物结算类商户采用0；虚拟产品类商户采用1；
	 */
	private String redoFlag = "1";
	/**
	 * 合作伙伴在快钱的用户编号
	 * 30
	 * 可为空
	 * 数字串
	 * 用户登录快钱首页后可查询到。仅适用于快钱合作伙伴中系统及平台提供商
	 */
	private String pid;
	/**
	 * 签名字符串
	 * 256
	 * 不可空
	 * 以上所有非空参数及其值与密钥组合、经MD5加密生成并转化为大写的32位字符串
	 */
	private String signMsg;
	
	final private String[] names = {"inputCharset", "pageUrl", "bgUrl", "version", "language", "signType", 
			"merchantAcctId", "payerName", "payerContactType", "payerContact", "orderId", "orderAmount", 
			"orderTime", "productName", "productNum", "productId", "productDesc", "ext1", "ext2", 
			"payType", "bankId", "redoFlag", "pid"};
	
	private final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	
	protected void parameter(HttpServletResponse response, HttpServletRequest request, Resource ksfis, KuaiQianConfig kqc) throws IOException{
		pageUrl = request.getRequestURL().toString();//http://www.xxxx.com/xxx/xxx/ddd.do
		//request.
		int p = pageUrl.lastIndexOf('/') + 1;
		pageUrl = pageUrl.substring(0, p) + "return.do";
		//pageUrl = pageUrl.replace(":", "%3A").replace("/", "%2F");
//		inputCharset = "2";
		orderTime = sdf.format(new Date());
		orderId = orderTime;//MD5Util.randomMD5String();
		signType = kqc.getPkisignType();
		payType = "00";
//		redoFlag = "";
		if(!"4".equals(signType)){
			signType = "1";
		}
		String[] values = {inputCharset, pageUrl, bgUrl, version, language, signType, //6
				merchantAcctId, payerName, payerContactType, payerContact, orderId, orderAmount, //12
				orderTime, productName, productNum, productId, productDesc, ext1, ext2, //19
				payType, bankId, redoFlag, pid};
		StringBuilder paras = new StringBuilder();
		for(int i = 0, l = values.length; i < l; i++){
			String value = values[i];
			if(StringHelper.isNotEmpty(value)){
				paras.append('&').append(names[i]).append('=').append(value);
			}
		}
		String kp = kqc.getPkiKey(), strParameter;
		if("4".equals(signType)){
			try(InputStream is = ksfis.getInputStream()){
				strParameter = paras.substring(1);
				Pkipair pki = new Pkipair();
				signMsg = pki.signMsg(strParameter, is, kp, kqc.getPkiKeyAlias());
			}
		}else{
			paras.append("&key=").append(kp);
			strParameter = paras.substring(1);
			signMsg = pki.MD5Util.md5Hex(strParameter.getBytes("UTF-8")).toUpperCase();
		}
		//paras.append("key=").append(kp);
//		signMsg = pki.MD5Util.md5Hex(paras.toString()).toUpperCase();
		
		System.out.println(strParameter);
//		signMsg = MD5Util.getMD5(strParameter).toUpperCase();
		//StringBuilder url = new StringBuilder(kuaiqianUrl);
		//url.append(strParameter).append("&signMsg=").append(signMsg);
		//return url.toString();
	}
	
	public KuaiqianRechargeEntity entity(){
		KuaiqianRechargeEntity kre = new KuaiqianRechargeEntity();
//		kre.setBankDealId(bankDealId)
		kre.setBankId(bankId);
		kre.setExt1(ext1);
		kre.setExt2(ext2);
		kre.setInputCharset(inputCharset);
		kre.setLanguage(language);
		kre.setMerchantAcctId(merchantAcctId);
		kre.setOrderId(orderId);
		kre.setOrderTime(orderTime);
		kre.setPayerContact(payerContact);
		kre.setPayerContactType(payerContactType);
		kre.setPayerName(payerName);
		kre.setPayType(payType);
		kre.setPid(pid);
		kre.setProductDesc(productDesc);
		kre.setProductId(productId);
		kre.setProductNum(productNum);
		kre.setProductName(productName);
		kre.setRedoFlag(redoFlag);
		kre.setSignMsgSend(signMsg);
		kre.setSignType(signType);
		kre.setVersion(version);
		return kre;
	}
	
	public String getKuaiqianUrl() {
		return kuaiqianUrl;
	}
	public void setKuaiqianUrl(String kuaiqianUrl) {
		this.kuaiqianUrl = kuaiqianUrl;
	}
	public String getInputCharset() {
		return inputCharset;
	}
	public void setInputCharset(String inputCharset) {
		this.inputCharset = inputCharset;
	}
	public String getPageUrl() {
		return pageUrl;
	}
	public void setPageUrl(String pageUrl) {
		this.pageUrl = pageUrl;
	}
	public String getBgUrl() {
		return bgUrl;
	}
	public void setBgUrl(String bgUrl) {
		this.bgUrl = bgUrl;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getSignType() {
		return signType;
	}
	public void setSignType(String signType) {
		this.signType = signType;
	}
	public String getMerchantAcctId() {
		return merchantAcctId;
	}
	public void setMerchantAcctId(String merchantAcctId) {
		this.merchantAcctId = merchantAcctId;
	}
	public String getPayerName() {
		return payerName;
	}
	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}
	public String getPayerContactType() {
		return payerContactType;
	}
	public void setPayerContactType(String payerContactType) {
		this.payerContactType = payerContactType;
	}
	public String getPayerContact() {
		return payerContact;
	}
	public void setPayerContact(String payerContact) {
		this.payerContact = payerContact;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrderAmount() {
		return orderAmount;
	}
	public void setOrderAmount(String orderAmount) {
		this.orderAmount = orderAmount;
	}
	public String getOrderTime() {
		return orderTime;
	}
	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductNum() {
		return productNum;
	}
	public void setProductNum(String productNum) {
		this.productNum = productNum;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public String getExt1() {
		return ext1;
	}
	public void setExt1(String ext1) {
		this.ext1 = ext1;
	}
	public String getExt2() {
		return ext2;
	}
	public void setExt2(String ext2) {
		this.ext2 = ext2;
	}
	public String getPayType() {
		return payType;
	}
	public void setPayType(String payType) {
		this.payType = payType;
	}
	public String getBankId() {
		return bankId;
	}
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}
	public String getRedoFlag() {
		return redoFlag;
	}
	public void setRedoFlag(String redoFlag) {
		this.redoFlag = redoFlag;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getSignMsg() {
		return signMsg;
	}
	public void setSignMsg(String signMsg) {
		this.signMsg = signMsg;
	}
	public String[] getNames() {
		return names;
	}
	public SimpleDateFormat getSdf() {
		return sdf;
	}
}