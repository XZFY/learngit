package cn.bonoon.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.PagerCommentService;
import cn.bonoon.entities.PagerComment;
import cn.bonoon.kernel.support.services.AbstractSearchService;

@Service
@Transactional(readOnly = true)
public class PagerCommentServiceImpl extends AbstractSearchService<PagerComment> implements PagerCommentService{

}
