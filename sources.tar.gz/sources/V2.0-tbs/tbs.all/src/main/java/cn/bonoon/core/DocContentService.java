package cn.bonoon.core;

import cn.bonoon.entities.DocContentEntity;
import cn.bonoon.kernel.support.services.GenericService;

public interface DocContentService extends GenericService<DocContentEntity>{

}
