package cn.bonoon.core;

import java.util.List;

import cn.bonoon.core.infos.ExplanationInfo;
import cn.bonoon.core.infos.PraxisInfo;
import cn.bonoon.core.infos.RedeemInfo;
import cn.bonoon.core.infos.ResultInfo;
import cn.bonoon.core.infos.TopicInfo;
import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.entities.PagerEntity;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.models.Page;

/**
 * <pre>
 * 做题练习的接口
 * </pre>
 * @author jackson
 *
 */
public interface PracticeService extends AnswerStatus{

	List<String> freeFastRandom(Long chapterId);

	List<String> freeCombatRandom();

	AnswerEntity refresh(Long id);

	AnswerEntity refresh(Long id, String fromKey, String answer, Boolean imptMark);

//	List<AnswerEntity> myPraxis(Long memId, Long chapterId);

	List<String> trialPraxis(Long selectedId);

	void giveup(Long id);

	ResultInfo finish(Long memId, Long id, String fromKey, String answer, Boolean imptMark);

	Page myReals(IOperator user, int pageIndex, int pageSize, String name, String type);
	Page myPagers(IOperator user, int pageIndex, int pageSize, String name, String type);

	RedeemInfo redeemReal(Long id, IOperator user, int pageSize);
	RedeemInfo redeemPager(Long id, IOperator user, int pageSize);

//	AnswerEntity startReal(IOperator user, Long realId, Long id);

	AnswerEntity startReal(IOperator user, Long realId);

	AnswerEntity startReal(IOperator user, Long realId, Long id);

	AnswerEntity startPager(IOperator user, Long id);

//	AnswerEntity startPager(IOperator user);

	AnswerEntity startPager(IOperator user, Long pid, Long aid);

	List<TopicEntity> find(String[] keys);

	//开始一个新的练习
	AnswerEntity startPraxis(IOperator user, Long chapterId);
	//继续某一个练习
	AnswerEntity startPraxis(IOperator user, Long chapterId, Long id);
	//中断某一个练习，重新开始一个新的练习
	AnswerEntity restartPraxis(IOperator user, Long chapterId, Long id);

	PraxisInfo myPraxis(IOperator user, Long chapterId);

	TopicInfo topic(String key, Boolean isen);

	TopicInfo topic(Long id, Boolean isen);

	ExplanationInfo explanation(String key, Boolean isen);

	List<String> trialArea(Long selectedId);

	List<String> trialProcess(Long selectedId);

	List<String> trialGroup(Long selectedId);

	PagerEntity trialPager();

	PagerEntity trialReal();
	
	List<String> trialPagerTopics(PagerEntity pe);

	PraxisInfo improveArea(IOperator user, Long id);
	PraxisInfo improveProcess(IOperator user, Long id);
	PraxisInfo improveGroup(IOperator user, Long id);

	AnswerEntity startImproveArea(IOperator user, Long tid);
	AnswerEntity startImproveProcess(IOperator user, Long tid);
	AnswerEntity startImproveGroup(IOperator user, Long tid);

	AnswerEntity startImproveArea(IOperator user, Long tid, Long id);
	AnswerEntity startImproveProcess(IOperator user, Long tid, Long id);
	AnswerEntity startImproveGroup(IOperator user, Long tid, Long id);

	AnswerEntity restartImproveArea(IOperator user, Long tid, Long id);
	AnswerEntity restartImproveProcess(IOperator user, Long tid, Long id);
	AnswerEntity restartImproveGroup(IOperator user, Long tid, Long id);
}
