package cn.bonoon.controllers;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.Resource;

import pki.Pkipair;
import cn.bonoon.entities.KuaiqianRechargeEntity;
import cn.bonoon.kernel.util.StringHelper;

public class KuaiQianReturn{
	private final HttpServletRequest request;
	/**
	 * 人民币账号
	 * 30
	 * 数字串
	 * 与提交订单时的快钱账号保持一致
	 */
	private String merchantAcctId;
	/**
	 * 网关版本
	 * 10
	 * 固定值：v2.0
	 * 与提交订单时的网关版本保持一致
	 */
	private String version;
	/**
	 * 签名类型
	 * 2
	 * 固定值：1
	 * 与提交订单时的签名类型保持一致
	 */
	private String signType = "1";
	
	private String payType;
	private String bankId;
	private String orderId;
	private String orderTime;
	private String orderAmount;
	/**
	 * 快钱交易号
	 * 30
	 * 数字串
	 * 该交易在快钱系统中对应的交易号
	 */
	private String dealId;
	/**
	 * 银行交易号
	 * 30
	 * 数字串
	 * 该交易在银行支付时对应的交易号，如果不是通过银行卡支付，则为空
	 */
	private String bankDealId;
	/**
	 * 快钱交易时间
	 * 14
	 * 数字串
	 * 快钱对交易进行处理的时间，格式为：年[4位]月[2位]日[2位]时[2位]分[2位]秒[2位]
	 */
	private String dealTime;
	/**
	 * 订单实际支付金额
	 * 10
	 * 整型数字
	 * 返回在使用优惠券等情况后，用户实际支付的金额；以分为单位。
	 * 如：10元，提交时金额应为1000
	 */
	private String payAmount;
	/**
	 * 费用
	 * 10
	 * 整型数字
	 * 快钱收取商户的手续费， 单位为分
	 */
	private String fee;
	private String ext1, ext2;
	/**
	 * 处理结果
	 * 2
	 * 10： 支付成功
	 * 11： 支付失败
	 * 00： 订单申请成功(仅对电话银行支付等需要多个过程才能完成支付的订单进行的订单申请成功信息返回)
	 * 01： 订单申请失败
	 */
	private String payResult;
	/**
	 * 错误代码
	 * 10
	 * 失败时返回的错误代码，可以为空。
	 * 详细资料见参考资料。
	 */
	private String errCode;
	/**
	 * 签名字符串
	 */
	private String signMsg;
	private String language;
//	private final String[] names = {"merchantAcctId", "version", "signType", "payType", "bankId", 
//			"orderId", "orderTime", "orderAmount", "dealId", "bankDealId", "dealTime", "payAmount", 
//			"fee", "ext1", "ext2", "payResult", "errCode"};
	public KuaiQianReturn(HttpServletRequest request){
		this.request = request;
		merchantAcctId = request.getParameter("merchantAcctId");
		version = request.getParameter("version");
		signType = request.getParameter("signType");
		payType = request.getParameter("payType");
		bankId = request.getParameter("bankId");
		orderId = request.getParameter("orderId");
		orderTime = request.getParameter("orderTime");
		orderAmount = request.getParameter("orderAmount");
		dealId = request.getParameter("dealId");
		bankDealId = request.getParameter("bankDealId");
		dealTime = request.getParameter("dealTime");
		payAmount = request.getParameter("payAmount");
		fee = request.getParameter("fee");
		ext1 = request.getParameter("ext1");
		ext2 = request.getParameter("ext2");
		payResult = request.getParameter("payResult");
		errCode = request.getParameter("errCode");
		signMsg = request.getParameter("signMsg");
		language = request.getParameter("language");
	}
	
	public void entity(KuaiqianRechargeEntity kre){
//		KuaiqianRechargeEntity kre = (KuaiqianRechargeEntity)re;
//		_entity(kre);
//	}
//	
//	private void _entity(KuaiqianRechargeEntity kre){
		kre.setBankDealId(bankDealId);
		kre.setDealId(dealId);
		kre.setDealTime(dealTime);
		kre.setErrCode(errCode);
		kre.setFee(fee);
		kre.setPayResult(payResult);
		kre.setSignMsgReturn(signMsg);
		//把以分为单位的转为以元为单位
		kre.setPayAmount(StringHelper.todouble(payAmount) / 100);
		
		//回传的值
		kre.setBankId(bankId);
		kre.setExt1(ext1);
		kre.setExt2(ext2);
//		kre.setInputCharset(inputCharset);
//		kre.setLanguage(language);
		kre.setMerchantAcctId(merchantAcctId);
		kre.setOrderId(orderId);
		kre.setOrderTime(orderTime);
//		kre.setPayerContact(payerContact);
//		kre.setPayerContactType(payerContactType);
//		kre.setPayerName(payerName);
		kre.setPayType(payType);
//		kre.setPid(pid);
//		kre.setProductDesc(productDesc);
//		kre.setProductId(productId);
//		kre.setProductNum(productNum);
//		kre.setProductName(productName);
//		kre.setRedoFlag(redoFlag);
		kre.setSignType(signType);
		kre.setVersion(version);
	}
	
	public KuaiqianRechargeEntity entity(){
		KuaiqianRechargeEntity kre = new KuaiqianRechargeEntity();
		entity(kre);
		return kre;
	}
	
	public String getMerchantAcctId() {
		return merchantAcctId;
	}
	public void setMerchantAcctId(String merchantAcctId) {
		this.merchantAcctId = merchantAcctId;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getSignType() {
		return signType;
	}
	public void setSignType(String signType) {
		this.signType = signType;
	}
	public String getPayType() {
		return payType;
	}
	public void setPayType(String payType) {
		this.payType = payType;
	}
	public String getBankId() {
		return bankId;
	}
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrderTime() {
		return orderTime;
	}
	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}
	public String getOrderAmount() {
		return orderAmount;
	}
	public void setOrderAmount(String orderAmount) {
		this.orderAmount = orderAmount;
	}
	public String getDealId() {
		return dealId;
	}
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}
	public String getBankDealId() {
		return bankDealId;
	}
	public void setBankDealId(String bankDealId) {
		this.bankDealId = bankDealId;
	}
	public String getDealTime() {
		return dealTime;
	}
	public void setDealTime(String dealTime) {
		this.dealTime = dealTime;
	}
	public String getPayAmount() {
		return payAmount;
	}
	public void setPayAmount(String payAmount) {
		this.payAmount = payAmount;
	}
	public String getFee() {
		return fee;
	}
	public void setFee(String fee) {
		this.fee = fee;
	}
	public String getExt1() {
		return ext1;
	}
	public void setExt1(String ext1) {
		this.ext1 = ext1;
	}
	public String getExt2() {
		return ext2;
	}
	public void setExt2(String ext2) {
		this.ext2 = ext2;
	}
	public String getPayResult() {
		return payResult;
	}
	public void setPayResult(String payResult) {
		this.payResult = payResult;
	}
	public String getErrCode() {
		return errCode;
	}
	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}
	public String getSignMsg() {
		return signMsg;
	}
	public void setSignMsg(String signMsg) {
		this.signMsg = signMsg;
	}
	public HttpServletRequest getRequest() {
		return request;
	}

	public boolean check(Resource ksfis) throws IOException{
		String merchantSignMsgVal="";
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"merchantAcctId",merchantAcctId);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"version",version);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"language",language);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"signType",signType);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"payType",payType);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"bankId",bankId);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"orderId",orderId);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"orderTime",orderTime);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"orderAmount",orderAmount);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"dealId",dealId);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"bankDealId",bankDealId);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"dealTime",dealTime);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"payAmount",payAmount);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"fee",fee);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"ext1",ext1);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"ext2",ext2);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"payResult",payResult);
		merchantSignMsgVal = appendParam(merchantSignMsgVal,"errCode",errCode);
		boolean flag;
		if("4".equals(signType)){
			
		  	Pkipair pki = new Pkipair();
		 
		  	try(InputStream is = ksfis.getInputStream()){
		  		flag = pki.enCodeByCer(merchantSignMsgVal, signMsg, is);
		  	}
		}else{
			String signMsg = pki.MD5Util.md5Hex(merchantSignMsgVal.getBytes("UTF-8")).toUpperCase();
			flag = signMsg.equals(this.signMsg);
		}
		return flag;
	}
	   public String appendParam(String returns, String paramId, String paramValue)
	    {
	        if (returns != "")
	        {
	            if (paramValue != "")
	            {

	                returns += "&" + paramId+"="+paramValue;
	            }

	        }
	        else
	        {

	            if (paramValue != "")
	            {
	                returns = paramId+"="+paramValue ;
	            }
	        }

	        return returns;
	    }
}