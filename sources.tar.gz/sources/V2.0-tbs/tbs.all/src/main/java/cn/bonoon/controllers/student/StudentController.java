package cn.bonoon.controllers.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.core.StudentService;
import cn.bonoon.entities.StudentEntity;
import cn.bonoon.kernel.web.annotations.grid.GridStandardDefinition;
import cn.bonoon.kernel.web.controllers.AbstractGridController;

@Controller
@RequestMapping("s/tms/student")
public class StudentController extends AbstractGridController<StudentEntity, StudentItem>{
	private final StudentService service;
	
	@Autowired
	public StudentController(StudentService service) {
		super(service);
		this.service = service;
	}

	@Override
	protected Class<StudentItem> itemClass() {
		return StudentItem.class;
	}

	@Override
	@GridStandardDefinition(
			insertClass = StudentInserter.class, 
			updateClass = StudentUpdater.class, 
			detailClass = StudentDetail.class)
	protected StudentService initLayoutGrid(LayoutGridRegister register) throws Exception {
		return service;
	}
}
