package cn.bonoon.core.configs;

import cn.bonoon.kernel.web.annotations.components.AsCheckbox;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

//在未登录的情况下，是否显示主要的频道信息
@FormEditor(headWidth = 140, width = 600)
public class TouristChannelConfig {

	@AsCheckbox("是")
	@PropertyEditor(name = "显示试卷", value = 2)
	@PropertyHelper(value = "在没有登录的情况下是否显示试卷频道", type = HelperType.DIRECT)
	private boolean examShow;

	@AsCheckbox("是")
	@PropertyEditor(name = "显示班级", value = 10)
	@PropertyHelper(value = "在没有登录的情况下是否显示班级频道", type = HelperType.DIRECT)
	private boolean classShow;

	@AsCheckbox("是")
	@PropertyEditor(name = "显示个人中心", value = 20)
	@PropertyHelper(value = "在没有登录的情况下是否显示个人中心频道", type = HelperType.DIRECT)
	private boolean centerShow;

	@AsCheckbox("是")
	@PropertyEditor(name = "显示资源库", value = 30)
	@PropertyHelper(value = "在没有登录的情况下是否显示资源库频道", type = HelperType.DIRECT)
	private boolean resourceShow;

	@AsCheckbox("是")
	@PropertyEditor(name = "显示练习", value = 0)
	@PropertyHelper(value = "在没有登录的情况下是否显示练习频道", type = HelperType.DIRECT)
	private boolean praxisShow;

	@AsCheckbox("是")
	@PropertyEditor(name = "显示提高", value = 1)
	@PropertyHelper(value = "在没有登录的情况下是否显示提高频道", type = HelperType.DIRECT)
	private boolean improveShow;

	@AsCheckbox("是")
	@PropertyEditor(name = "显示学习助手", value = 3)
	@PropertyHelper(value = "在没有登录的情况下是否显示学习助手频道", type = HelperType.DIRECT)
	private boolean assistantShow;

	public boolean isPraxisShow() {
		return praxisShow;
	}

	public void setPraxisShow(boolean praxisShow) {
		this.praxisShow = praxisShow;
	}

	public boolean isAssistantShow() {
		return assistantShow;
	}

	public void setAssistantShow(boolean assistantShow) {
		this.assistantShow = assistantShow;
	}

	public boolean isExamShow() {
		return examShow;
	}

	public void setExamShow(boolean examShow) {
		this.examShow = examShow;
	}

	public boolean isClassShow() {
		return classShow;
	}

	public void setClassShow(boolean classShow) {
		this.classShow = classShow;
	}

	public boolean isCenterShow() {
		return centerShow;
	}

	public void setCenterShow(boolean centerShow) {
		this.centerShow = centerShow;
	}

	public boolean isResourceShow() {
		return resourceShow;
	}

	public void setResourceShow(boolean resourceShow) {
		this.resourceShow = resourceShow;
	}

	public boolean isImproveShow() {
		return improveShow;
	}

	public void setImproveShow(boolean improveShow) {
		this.improveShow = improveShow;
	}
}
