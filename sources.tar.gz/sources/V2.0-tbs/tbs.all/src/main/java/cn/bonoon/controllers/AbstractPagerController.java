package cn.bonoon.controllers;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.Util;
import cn.bonoon.core.configs.OpenedPointsConfig;
import cn.bonoon.core.configs.PageSizeConfig;
import cn.bonoon.core.infos.RedeemInfo;
import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.MemberSettingEntity;
import cn.bonoon.entities.PagerEntity;
import cn.bonoon.kernel.events.BaseEvent;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.support.models.Page;
import cn.bonoon.kernel.util.StringHelper;

public abstract class AbstractPagerController extends AbstractPracticeController{

	@Override
	protected boolean hasOpened(MemberSettingEntity fm) {
		return fm.isExamOpened();
	}
	
	@Override
	protected int reachPoint(OpenedPointsConfig opc) {
		return opc.getExamReach();
	}
	
	@Override
	protected int openCost(OpenedPointsConfig opc) {
		return opc.getExamCost();
	}

	@Override
	protected boolean openCoseCash(OpenedPointsConfig opc) {
		return opc.isExamCostCash();
	}
	
	@Override
	protected void open(MemberSettingEntity fm, int cost, Date now) {
		fm.setExamAt(now);
		fm.setExamOpened(true);
		fm.setExamPoints(cost);
	}

	protected PageSizeConfig __pageSize(){
		PageSizeConfig psc = new PageSizeConfig();
		try{
			configService.read(new BaseEvent(psc));
		}catch(Exception ex){}
		return psc;
	}
	
	@Override
	protected String trial(HttpServletRequest request, Model model) {
		// TODO 提供试用的功能
		PagerEntity pe = trial(model);
		String topicTitle;
		if(null != pe){
			List<String> topics = topicService.trialPagerTopics(pe);
			model.addAttribute("topics", topics);
			topicTitle = "<span style='font-size: 18px; font-family: Arial;padding-left:15px;'>试卷：" + pe.getName() + "</span>";
		}else{
			topicTitle = "<span style='font-size: 18px; font-family: Arial;padding-left:15px;'>没有可试用的试卷！</span>";
		}
		model.addAttribute("topicTitle", topicTitle);
		model.addAttribute("showTopicHead", true);
		return super.trial(request, model);
	}

	protected abstract PagerEntity trial(Model model);

//	protected String menuSelected;
	
	@Override
	protected void init() {
		functionName 	= "考试";
		functionMenu 	= "menus/menu-pager.vm";
		channelSelected = "pager";
		vmTrial 		= "practices/free";
		trialTitle 		= "<span style='font-size: 18px; font-family: Arial;padding-left:15px;'>试用</span>";
	}

	@RequestMapping("{id}!start.do")
	public String start(Model model, @PathVariable("id") Long id){
		try{
			AnswerEntity ae = start(id);
			__parse(model, ae);
			showHead(model, ae.getName());
		}catch(Exception ex){
			warning(model, ex);
		}
		return showProactice(model);
	}
	
	protected abstract AnswerEntity start(Long id);
	

	@RequestMapping("{id}!redeem.do")
	public String redeem(Model model, @PathVariable("id") Long id, int page, String name, String type){
		//使用积分进行兑换
		try{
			int size = __size();
			RedeemInfo ri = __redeem(id, size);
			__paging(model, page, name, type, size, ri.getPage());
			//把钻石和金币的值都改变一下
			MemberEntity me = ri.getMember();
			StringBuilder ext = new StringBuilder("<script t ype='text/javascript'>");
			ext.append("$('.member-available-cash').text(").append(me.getAvailableCash()).append(");");
			ext.append("$('.member-available-points').text(").append(me.getAvailablePoints()).append(");");
			ext.append("</script>");
			model.addAttribute("ext", ext);
		}catch(Exception ex){
			loadWarning(model, ex);
			__paging(model, getUser(), page, name, type);
		}
		model.addAttribute("layout", "layout-empty.vm");
		return "practices/pager-items";
	}

	protected abstract RedeemInfo __redeem(Long id, int size);
	
	protected abstract int __size();

	protected abstract Page __get(LogonUser user, int pageIndex, int pageSize, String name, String type);
	
	protected void __paging(Model model, LogonUser user){
		__paging(model, user, 0, "", "");
	}
	
	protected void __paging(Model model, LogonUser user, int pageIndex, String name, String type) {
		int size = __size();
		Page page = __get(user, pageIndex, size, name, type);
		__paging(model, pageIndex, name, type, size, page);
	}

	private void __paging(Model model, int pageIndex, String name, String type, int size, Page page) {
		String params = "";
		if(StringHelper.isNotEmpty(name)){
			params = "?name=" + name;
		}
		if(StringHelper.isNotEmpty(type)){
			if(params.isEmpty()){
				params = "?";
			}else{
				params += "&";
			}
			params += "type=" + type;
		}
		Util.paging(model, page, pageIndex, size, params);
		model.addAttribute("pagers", page);
	}

	@RequestMapping("{pageIndex}!index.do")
	public String items(Model model, @PathVariable("pageIndex") int pageIndex, String name, String type){
		//使用积分进行兑换
		try{
			__paging(model, getUser(), pageIndex, name, type);
		}catch(Exception ex){
			loadWarning(model, ex);
		}
		model.addAttribute("layout", "layout-empty.vm");
		return "practices/pager-items";
	}
	
}
