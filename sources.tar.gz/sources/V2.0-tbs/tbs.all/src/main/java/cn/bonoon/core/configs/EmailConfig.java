package cn.bonoon.core.configs;

import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

@FormEditor(headWidth = 180, width = 420)
public class EmailConfig {

	@PropertyEditor(name = "smtp服务器", value = 0, width = 180)
	private String smtpHost;
	@PropertyEditor(name = "smtp端口", value = 1, width = 80)
	private int smtpPort;
	@PropertyEditor(name = "是否加密", value = 2)
	private boolean smtpAuth;

	@PropertyEditor(name = "签名", value = 10, width = 180)
	@PropertyHelper(value = "将会显示在邮件里的签名", type = HelperType.DIRECT)
	private String signature;
	@PropertyEditor(name = "用户名", value = 11, width = 180)
	@PropertyHelper(value = "将会使用该账户来发送邮件", type = HelperType.DIRECT)
	private String username;
	@PropertyEditor(name = "密码", value = 12, width = 180)
	private String password;
	public String getSmtpHost() {
		return smtpHost;
	}
	public void setSmtpHost(String smtpHost) {
		this.smtpHost = smtpHost;
	}
	public int getSmtpPort() {
		return smtpPort;
	}
	public void setSmtpPort(int smtpPort) {
		this.smtpPort = smtpPort;
	}
	public boolean isSmtpAuth() {
		return smtpAuth;
	}
	public void setSmtpAuth(boolean smtpAuth) {
		this.smtpAuth = smtpAuth;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
