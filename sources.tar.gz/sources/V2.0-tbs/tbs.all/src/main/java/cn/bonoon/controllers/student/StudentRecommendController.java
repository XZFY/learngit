package cn.bonoon.controllers.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.core.StudentService;
import cn.bonoon.entities.StudentEntity;
import cn.bonoon.kernel.annotations.QueryExpression;
import cn.bonoon.kernel.web.annotations.grid.GridStandardDefinition;
import cn.bonoon.kernel.web.controllers.AbstractGridController;

@Controller
@RequestMapping("s/tms/recommend")
public class StudentRecommendController extends AbstractGridController<StudentEntity, StudentItem>{
	private final StudentService service;
	@Autowired
	public StudentRecommendController(StudentService service) {
		super(service);
		this.service = service;
	}

	@Override
	protected Class<StudentItem> itemClass() {
		return StudentItem.class;
	}

	@Override
	@GridStandardDefinition(updateClass = StudentRecommendUpdater.class, detailClass = StudentDetail.class)
	@QueryExpression("x.status={FIELD cn.bonoon.core.StudentService STATUS_ENROLL}")
	protected StudentService initLayoutGrid(LayoutGridRegister register) throws Exception {
//		register.add("x.status=?", StudentService.STATUS_ENROLL);
		return service;
	}
}
