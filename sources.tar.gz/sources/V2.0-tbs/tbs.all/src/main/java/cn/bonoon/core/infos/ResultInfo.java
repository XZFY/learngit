package cn.bonoon.core.infos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import cn.bonoon.entities.BaseEntity;
import cn.bonoon.entities.TopicEntity;

public class ResultInfo extends AbstractResult{
	private String timeSpent;
	private List<ResultItem> areas = new ArrayList<>();
	private List<ResultItem> groups = new ArrayList<>();
	private List<ResultItem> processes = new ArrayList<>();
	//做错的题目的编码
	private List<String> wrongItems = new ArrayList<>();
	
	public String getTimeSpent() {
		return timeSpent;
	}
	
	public void setTimeSpent(String timeSpent) {
		this.timeSpent = timeSpent;
	}
	
	public List<ResultItem> getAreas() {
		return areas;
	}
	
	public void setAreas(List<ResultItem> areas) {
		this.areas = areas;
	}
	
	public List<ResultItem> getGroups() {
		return groups;
	}
	
	public void setGroups(List<ResultItem> groups) {
		this.groups = groups;
	}
	
	public List<ResultItem> getProcesses() {
		return processes;
	}
	
	public void setProcesses(List<ResultItem> processes) {
		this.processes = processes;
	}
	
	public boolean parse(TopicEntity te, String answer){
		boolean gu;
		boolean rt = false;
		if(!answer.isEmpty()){
			char sch = answer.charAt(0);
			gu = sch == '-' || sch == ' ' || sch == '?';
			String ans = te.getAnswer();
			rt = ans != null && !ans.isEmpty() && sch == Character.toUpperCase(ans.charAt(0));
		}else{
			gu = true;
		}
		if(rt){
			increaseRight();
		}else{
			wrongItems.add(te.getKey());
			if(gu){
				increaseGiveUp();
			}else{
				increaseWrong();
			}
		}
		//添加知识领域
		__parse(areas, te.getArea(), gu, rt);
		__parse(groups, te.getGroup(), gu, rt);
		__parse(processes, te.getProcess(), gu, rt);
		//只返回该题目是否做对。
		return rt;
	}
	private void __parse(List<ResultItem> tpis, BaseEntity ae, boolean gu, boolean rt){
		if(null != ae){
			ResultItem currentTpi = null;
			for(ResultItem tpi : tpis){
				if(tpi.getId().equals(ae.getId())){
					currentTpi = tpi;
					break;
				}
			}
			if(null == currentTpi){
				currentTpi = new ResultItem();
				currentTpi.setId(ae.getId());
				currentTpi.setOrdinal(ae.getOrdinal());
				currentTpi.setName(ae.getName());
				tpis.add(currentTpi);
			}
			if(gu){
				currentTpi.increaseGiveUp();
			}else if(rt){
				currentTpi.increaseRight();
			}else{
				currentTpi.increaseWrong();
			}
		}
	}

	public ResultInfo sort() {
		Collections.sort(areas);
		Collections.sort(groups);
		Collections.sort(processes);
		return this;
	}

	public List<String> getWrongItems() {
		return wrongItems;
	}

	public void setWrongItems(List<String> wrongItems) {
		this.wrongItems = wrongItems;
	}
}
