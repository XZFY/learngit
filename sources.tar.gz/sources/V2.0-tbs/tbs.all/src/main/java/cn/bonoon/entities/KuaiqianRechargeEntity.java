package cn.bonoon.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "T_KUAIQIANRECHARGE")
public class KuaiqianRechargeEntity extends RechargeEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1508636262924185073L;

	public KuaiqianRechargeEntity(){
		typeName = "快钱支付";
	}
	
	@Column(name = "C_INPUTCHARSET")
	private String inputCharset;
	
	@Column(name = "C_VERSION")
	private String version;
	
	@Column(name = "C_LANGUAGE")
	private String language;
	
	@Column(name = "C_SIGNTYPE")
	private String signType;
	
	@Column(name = "C_MERCHANTACCTID")
	private String merchantAcctId;
	
	@Column(name = "C_PAYERNAME")
	private String payerName;
	
	@Column(name = "C_PAYERCONTACTTYPE")
	private String payerContactType;
	
	@Column(name = "C_PAYERCONTACT")
	private String payerContact;
	
	@Column(name = "C_PRODUCTNAME")
	private String productName;
	
	@Column(name = "C_PRODUCTNUM")
	private String productNum;
	
	@Column(name = "C_PRODUCTID")
	private String productId;
	
	@Column(name = "C_PRODUCTDESC")
	private String productDesc;
	
	@Column(name = "C_EXT1")
	private String ext1;
	
	@Column(name = "C_EXT2")
	private String ext2;
	
	@Column(name = "C_BANKID")
	private String bankId;
	
	@Column(name = "C_REDOFLAG")
	private String redoFlag;
	
	@Column(name = "C_PID")
	private String pid;
	
	@Column(name = "C_SIGNMSGSEND")
	private String signMsgSend;
	
	@Column(name = "C_FEE")
	private String fee;
	
	@Column(name = "C_PAYRESULT")
	private String payResult;
	
	@Column(name = "C_ERRCODE")
	private String errCode;
	
	@Column(name = "C_SIGNMSGRETURN")
	private String signMsgReturn;

	@Column(name = "C_REMARK")
	private String remark;
	public String getInputCharset() {
		return inputCharset;
	}

	public void setInputCharset(String inputCharset) {
		this.inputCharset = inputCharset;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getSignType() {
		return signType;
	}

	public void setSignType(String signType) {
		this.signType = signType;
	}

	public String getMerchantAcctId() {
		return merchantAcctId;
	}

	public void setMerchantAcctId(String merchantAcctId) {
		this.merchantAcctId = merchantAcctId;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public String getPayerContactType() {
		return payerContactType;
	}

	public void setPayerContactType(String payerContactType) {
		this.payerContactType = payerContactType;
	}

	public String getPayerContact() {
		return payerContact;
	}

	public void setPayerContact(String payerContact) {
		this.payerContact = payerContact;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductNum() {
		return productNum;
	}

	public void setProductNum(String productNum) {
		this.productNum = productNum;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getExt1() {
		return ext1;
	}

	public void setExt1(String ext1) {
		this.ext1 = ext1;
	}

	public String getExt2() {
		return ext2;
	}

	public void setExt2(String ext2) {
		this.ext2 = ext2;
	}

	public String getBankId() {
		return bankId;
	}

	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	public String getRedoFlag() {
		return redoFlag;
	}

	public void setRedoFlag(String redoFlag) {
		this.redoFlag = redoFlag;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getSignMsgSend() {
		return signMsgSend;
	}

	public void setSignMsgSend(String signMsgSend) {
		this.signMsgSend = signMsgSend;
	}

	public String getFee() {
		return fee;
	}

	public void setFee(String fee) {
		this.fee = fee;
	}

	public String getPayResult() {
		return payResult;
	}

	public void setPayResult(String payResult) {
		this.payResult = payResult;
	}

	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public String getSignMsgReturn() {
		return signMsgReturn;
	}

	public void setSignMsgReturn(String signMsgReturn) {
		this.signMsgReturn = signMsgReturn;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
