package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

@Entity
@Table(name = "T_IMPROVEITEM")
public class ImprovePracticeItem extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7070986985891482834L;

	@ManyToOne
	@JoinColumn(name = "R_IMPROVE_ID")
	private ImprovePracticeEntity improve;

	@ManyToOne
	@JoinColumn(name = "R_KNOWLEDGE_ID")
	private KnowledgePointEntity knowledge;
	
	//优先级，即知识点最薄弱的最优先；
	@Column(name = "C_PROIORITY")
	private int priority;

	//原始分，不会变
	@Column(name = "C_ORIGINALSCORE")
	private int originalScore;
	
	//最后一次提高练习的得分
	@Column(name = "C_SCORE")
	private int score;

	//该知识点进行的提高练习的次数
	@Column(name = "C_TIMES")
	private int times;
	
	//最后一次提高练习的时间
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_PRACTICEAT")
	private Date practiceAt;
	
	//达到这个分值即可不再需要进行练习了
	@Column(name = "C_UPPERLIMIT")
	private int upperLimit;

	//是否完成了该知识点的提高练习
	@Column(name = "C_FINISH")
	private boolean finish;

	@Column(name = "C_TOTAL")
	private int total;
	@Column(name = "C_RIGHT")
	private int right;

	public ImprovePracticeEntity getImprove() {
		return improve;
	}

	public void setImprove(ImprovePracticeEntity improve) {
		this.improve = improve;
	}

	public KnowledgePointEntity getKnowledge() {
		return knowledge;
	}

	public void setKnowledge(KnowledgePointEntity knowledge) {
		this.knowledge = knowledge;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public int getOriginalScore() {
		return originalScore;
	}

	public void setOriginalScore(int originalScore) {
		this.originalScore = originalScore;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getTimes() {
		return times;
	}

	public void setTimes(int times) {
		this.times = times;
	}

	public Date getPracticeAt() {
		return practiceAt;
	}

	public void setPracticeAt(Date practiceAt) {
		this.practiceAt = practiceAt;
	}

	public int getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(int upperLimit) {
		this.upperLimit = upperLimit;
	}

	public boolean isFinish() {
		return finish;
	}

	public void setFinish(boolean finish) {
		this.finish = finish;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getRight() {
		return right;
	}

	public void setRight(int right) {
		this.right = right;
	}
}
