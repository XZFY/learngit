package cn.bonoon.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

@Entity
@Table(name = "T_TOPICPAGER")
public class PagerTopicEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4292182724143147339L;

	/**
	 * 题目的序号
	 */
	@Column(name = "C_ORDINAL")
	private int ordinal;
	/**
	 * 所属的试卷
	 */
	@ManyToOne
	@JoinColumn(name = "R_PAGER_ID")
	private PagerEntity pager;
	/**
	 * 相应的题目
	 */
	@ManyToOne
	@JoinColumn(name = "R_TOPIC_ID")
	private TopicEntity topic;
	public int getOrdinal() {
		return ordinal;
	}
	public void setOrdinal(int ordinal) {
		this.ordinal = ordinal;
	}
	public PagerEntity getPager() {
		return pager;
	}
	public void setPager(PagerEntity pager) {
		this.pager = pager;
	}
	public TopicEntity getTopic() {
		return topic;
	}
	public void setTopic(TopicEntity topic) {
		this.topic = topic;
	}
}
