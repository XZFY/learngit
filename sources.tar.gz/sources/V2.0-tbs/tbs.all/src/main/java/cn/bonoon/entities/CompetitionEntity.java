package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractEntity;

//对练
//状态：草稿、正常、放弃
@Entity
@Table(name = "T_COMPETITION")
public class CompetitionEntity extends AbstractEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 829778029626210815L;

	@ManyToOne
	@JoinColumn(name = "R_INSTITUTION_ID")
	private TrainingInstitutionEntity institution;

	//拿来比赛的试卷
	@ManyToOne
	@JoinColumn(name = "R_PAGER_ID")
	private PagerEntity pager;
	
	//第一名奖分
	@Column(name = "C_AWARDFIRST")
	private int awardFirst;
	
	//第二名奖分
	@Column(name = "C_AWARDSECOND")
	private int awardSecond;
	
	//第三名奖分
	@Column(name = "C_AWARDTHIRD")
	private int awardThird;
	
	//奖励参与者的分数
	@Column(name = "C_AWARDPARTICIPANT")
	private int awardParticipant;
	
	//开始报名时间
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_BEGINREGISTER")
	private Date beginRegister;
	
	//比赛开始时间
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_BEGINCOMPETITION")
	private Date beginCompetition;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_FINISHAT")
	private Date finisthAt;

	public TrainingInstitutionEntity getInstitution() {
		return institution;
	}

	public void setInstitution(TrainingInstitutionEntity institution) {
		this.institution = institution;
	}

	public PagerEntity getPager() {
		return pager;
	}

	public void setPager(PagerEntity pager) {
		this.pager = pager;
	}

	public int getAwardFirst() {
		return awardFirst;
	}

	public void setAwardFirst(int awardFirst) {
		this.awardFirst = awardFirst;
	}

	public int getAwardSecond() {
		return awardSecond;
	}

	public void setAwardSecond(int awardSecond) {
		this.awardSecond = awardSecond;
	}

	public int getAwardThird() {
		return awardThird;
	}

	public void setAwardThird(int awardThird) {
		this.awardThird = awardThird;
	}

	public int getAwardParticipant() {
		return awardParticipant;
	}

	public void setAwardParticipant(int awardParticipant) {
		this.awardParticipant = awardParticipant;
	}

	public Date getBeginRegister() {
		return beginRegister;
	}

	public void setBeginRegister(Date beginRegister) {
		this.beginRegister = beginRegister;
	}

	public Date getBeginCompetition() {
		return beginCompetition;
	}

	public void setBeginCompetition(Date beginCompetition) {
		this.beginCompetition = beginCompetition;
	}

	public Date getFinisthAt() {
		return finisthAt;
	}

	public void setFinisthAt(Date finisthAt) {
		this.finisthAt = finisthAt;
	}
	
}
