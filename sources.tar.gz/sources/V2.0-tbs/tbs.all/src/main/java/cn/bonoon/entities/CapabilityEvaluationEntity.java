package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

//对学员能力的一次评估，评估是需要花费一定的积分的
@Entity
@Table(name = "T_CAPABILITYEVALUATION")
public class CapabilityEvaluationEntity extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1742854283996190483L;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CREATEAT")
	private Date createAt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_BEGINAT")
	private Date beginAt;//开始统计的时间，通过有效期计算出来的

	@ManyToOne
	@JoinColumn(name = "R_MEMBER_ID")
	private MemberEntity member;

	@Column(name = "C_TOTALCOUNT")
	private int totalCount;//总的题目数量

	@Column(name = "C_RIGHTCOUNT")
	private int rightCount;//总的做对的题目数
	
	//过程的统计
	@Column(name = "C_PROCESSSTATISTICS")
	private String processStatistics;
	
	//过程组的统计情况
	@Column(name = "C_GROUPSTATISTICS")
	private String groupStatistics;
	
	//知识领域的统计情况
	@Column(name = "C_AREASTATISTICS")
	private String areaStatistics;

	@Column(name = "C_SECURELINE")
	private int secureLine;//及格线，超过了表示考试正常发挥下该某一知识点通过没问题

	@Column(name = "C_PICKETLINE")
	private int picketLine;//警戒线

	@Column(name = "C_SUGGESTLINE")
	private int suggestLine;

	@Column(name = "C_CAPABILITY")
	private double capability;//本次评估的整体的能力值，如：75分一般保证过考的分数为75以上

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	public Date getBeginAt() {
		return beginAt;
	}

	public void setBeginAt(Date beginAt) {
		this.beginAt = beginAt;
	}

	public MemberEntity getMember() {
		return member;
	}

	public void setMember(MemberEntity member) {
		this.member = member;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getRightCount() {
		return rightCount;
	}

	public void setRightCount(int rightCount) {
		this.rightCount = rightCount;
	}

	public String getProcessStatistics() {
		return processStatistics;
	}

	public void setProcessStatistics(String processStatistics) {
		this.processStatistics = processStatistics;
	}

	public String getGroupStatistics() {
		return groupStatistics;
	}

	public void setGroupStatistics(String groupStatistics) {
		this.groupStatistics = groupStatistics;
	}

	public String getAreaStatistics() {
		return areaStatistics;
	}

	public void setAreaStatistics(String areaStatistics) {
		this.areaStatistics = areaStatistics;
	}

	public int getPicketLine() {
		return picketLine;
	}

	public void setPicketLine(int picketLine) {
		this.picketLine = picketLine;
	}

	public double getCapability() {
		return capability;
	}

	public void setCapability(double capability) {
		this.capability = capability;
	}

	public int getSecureLine() {
		return secureLine;
	}

	public void setSecureLine(int secureLine) {
		this.secureLine = secureLine;
	}

	public int getSuggestLine() {
		return suggestLine;
	}

	public void setSuggestLine(int suggestLine) {
		this.suggestLine = suggestLine;
	}
	
}
