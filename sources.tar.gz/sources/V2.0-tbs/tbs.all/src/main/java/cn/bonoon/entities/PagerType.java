package cn.bonoon.entities;

public enum PagerType {
	/**
	 * 一般的试题
	 */
	EXAMINATION,
	/**
	 * 历年的真题
	 */
	REAL,
	//用于比赛的试卷
	COMPETITION,
	/**
	 * 暂时的试卷，用户一般测试时生成的，到达一定的时间或规则时可以删除，节省存储的空间
	 */
	TEMPORARY
}
