package cn.bonoon.controllers.student;

import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.web.annotations.form.FormDetail;
import cn.bonoon.kernel.web.annotations.form.PropertyDetail;

@FormDetail(2)
public class StudentDetail implements StudentDefine{

	@PropertyDetail(0)
	private String sid;
	
	@PropertyDetail(0)
	@TransformField("member.name")
	private String name;
	
	@PropertyDetail(0)
	private String status;

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
