package cn.bonoon.controllers.pager;

import java.util.Date;

import cn.bonoon.kernel.query.PageCondition;
import cn.bonoon.kernel.web.annotations.condition.ConditionContent;

public class PagerCondition extends PageCondition implements PagerDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = 778505328273066205L;

	@ConditionContent(value = "时间 从", ordinal = 0)
	private Date searchStartAt;
	
	@ConditionContent("到")
	private Date searchEndAt;

	public Date getSearchEndAt() {
		return searchEndAt;
	}

	public void setSearchEndAt(Date searchEndAt) {
		this.searchEndAt = searchEndAt;
	}

	public Date getSearchStartAt() {
		return searchStartAt;
	}

	public void setSearchStartAt(Date searchStartAt) {
		this.searchStartAt = searchStartAt;
	}
}
