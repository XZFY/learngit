package cn.bonoon.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * 题目的知识点
 * @author jackson
 *
 */
@Entity
@Table(name = "T_KNOWLEDGEPOINT")
public class KnowledgePointEntity extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = -937563177499436453L;

//	@Column(name = "C_WEIGHT")
//	private int weight;//该知识点的权值，用于对个人能力计算的；权值表示该知识点是重要点的，还是次要点的

	//上限，表达这个知识点达到这一值就可以了，该值为0到100之间的数字，如果不在这个范围，则表示100
	@Column(name = "C_UPPERLIMIT")
	private int upperLimit;

	//下限，即这个知识点得到的分值小于这个值，则应该进行强化练习，该值为0到100之间的数字，如果不在这个范围则，则表示学员必须全部掌握该知识点
	@Column(name = "C_LOWERLIMIT")
	private int lowerLimit;

//	public int getWeight() {
//		return weight;
//	}
//
//	public void setWeight(int weight) {
//		this.weight = weight;
//	}

	public int getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(int upperLimit) {
		this.upperLimit = upperLimit;
	}

	public int getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(int lowerLimit) {
		this.lowerLimit = lowerLimit;
	}
}
