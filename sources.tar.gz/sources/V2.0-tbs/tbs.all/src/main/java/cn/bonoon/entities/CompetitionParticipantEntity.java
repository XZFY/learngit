package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

//比赛的参与者
@Entity
@Table(name = "T_CPARTICIPANT")
public class CompetitionParticipantEntity extends AbstractPersistable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4939622208206733543L;

	@ManyToOne
	@JoinColumn(name = "R_COMPETITION_ID")
	private CompetitionEntity competition;

	@ManyToOne
	@JoinColumn(name = "R_STUDENT_ID")
	private StudentEntity student;//学员；不会夸机构进行
	
	//名次
	@Column(name = "C_RANKING")
	private int ranking;
	
	//做结的题目数
	@Column(name = "C_RIGHTCOUNT")
	private int rightCount;
	
	//报名时间
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_REGISTERAT")
	private Date registerAt;
	
	//开始比赛的计时时间
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_STARTAT")
	private Date startAt;
	
	//完成比赛时间
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_FINISHAT")
	private Date finishAt;
	
	//奖分
	@Column(name = "C_AWARDPOINTS")
	private int awardPoints;
	
	//正常完成比赛后，可以对该比较发表一下感言
	@Column(name = "C_FEELING", length = 1000)
	private String feeling;

	public CompetitionEntity getCompetition() {
		return competition;
	}

	public void setCompetition(CompetitionEntity competition) {
		this.competition = competition;
	}

	public StudentEntity getStudent() {
		return student;
	}

	public void setStudent(StudentEntity student) {
		this.student = student;
	}

	public int getRanking() {
		return ranking;
	}

	public void setRanking(int ranking) {
		this.ranking = ranking;
	}

	public int getRightCount() {
		return rightCount;
	}

	public void setRightCount(int rightCount) {
		this.rightCount = rightCount;
	}

	public Date getRegisterAt() {
		return registerAt;
	}

	public void setRegisterAt(Date registerAt) {
		this.registerAt = registerAt;
	}

	public Date getStartAt() {
		return startAt;
	}

	public void setStartAt(Date startAt) {
		this.startAt = startAt;
	}

	public Date getFinishAt() {
		return finishAt;
	}

	public void setFinishAt(Date finishAt) {
		this.finishAt = finishAt;
	}

	public int getAwardPoints() {
		return awardPoints;
	}

	public void setAwardPoints(int awardPoints) {
		this.awardPoints = awardPoints;
	}

	public String getFeeling() {
		return feeling;
	}

	public void setFeeling(String feeling) {
		this.feeling = feeling;
	}
	
}
