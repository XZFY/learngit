package cn.bonoon.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.TopicCommentService;
import cn.bonoon.core.TopicService;
import cn.bonoon.core.infos.TopicCommentInfo;
import cn.bonoon.core.infos.TopicContentInfo;
import cn.bonoon.entities.DocContentEntity;
import cn.bonoon.entities.MediaContentEntity;
import cn.bonoon.entities.TopicComment;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.events.OperateEvent;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.support.services.AbstractService;
import cn.bonoon.kernel.util.MD5Util;

@Service
@Transactional(readOnly = true)
public class TopicServiceImpl extends AbstractService<TopicEntity> implements TopicService{

	@Override
	protected TopicEntity __save(OperateEvent event, TopicEntity entity) {
		entity.setKey(MD5Util.randomMD5String());
		return super.__save(event, entity);
	}

	@Override
	public List<TopicCommentInfo> getComments(String key, Long lastId) {
		String ql = "select x from TopicComment x where x.commented.key=? and x.status=? and x.id<? order by x.id desc";
		TypedQuery<TopicComment> qt = entityManager.createQuery(ql, TopicComment.class);
		qt.setParameter(1, key).setParameter(2, TopicCommentService.NORMAL).setParameter(3, lastId);
		int pageSize = 10;
		List<TopicCommentInfo> lis = new ArrayList<TopicCommentInfo>();
		for(TopicComment tc : qt.setMaxResults(pageSize).getResultList()){
			lis.add(new TopicCommentInfo(tc));
		}
		return lis;
	}

	@Override
	@Transactional
	public TopicCommentInfo commentSave(LogonUser user, String key, String content, int score) {
		TopicEntity te = __byKey(key);
		TopicComment tc = new TopicComment();
		tc.setCommented(te);
		tc.setContent(content);
		tc.setCreateAt(new Date());
		tc.setCreatorId(user.getId());
		tc.setCreatorName(user.getUsername());
		tc.setScore(score);
		tc.setStatus(TopicCommentService.NORMAL);
		entityManager.persist(tc);
		return new TopicCommentInfo(tc);
	}

	private TopicEntity __byKey(String key) {
		String ql = "select x from TopicEntity x where x.key=? and x.deleted=false";
		TopicEntity te = __first(TopicEntity.class, ql, key);
		if(null == te){
			throw new RuntimeException("没有找到对象，相亲去吧！");
		}
		return te;
	}
//
//	@Override
//	public TopicContentInfo getStudyMedia(String key, Long pre, Long loadId, Long next) {
//		TopicEntity te = __byKey(key);
//		TopicContentInfo tci = new TopicContentInfo();
//		if(pre != null && pre > 0){
//			__pre(tci, entityManager.find(MediaContentEntity.class, pre));
//		}else{
//			String ql = __ql("select distinct x from MediaContentEntity x where x.deleted=false", te) + " and x.id<? order by x.id asc";
//			TypedQuery<MediaContentEntity> qt = entityManager.createQuery(ql, MediaContentEntity.class);
//			qt.setParameter(1, loadId);
//			qt.setMaxResults(1);
//			List<MediaContentEntity> dces = qt.getResultList();
//			if(!dces.isEmpty()){
//				__pre(tci, dces.get(0));
//			}
//		}
//		
//		if(next != null && next > 0){
//			__next(tci, entityManager.find(MediaContentEntity.class, next));
//		}else{
//			String ql = __ql("select distinct x from MediaContentEntity x where x.deleted=false", te) + " and x.id>? order by x.id desc";
//			TypedQuery<MediaContentEntity> qt = entityManager.createQuery(ql, MediaContentEntity.class);
//			qt.setParameter(1, loadId);
//			qt.setMaxResults(1);
//			List<MediaContentEntity> dces = qt.getResultList();
//			if(!dces.isEmpty()){
//				__next(tci, dces.get(0));
//			}
//		}
//		tci.setInfo(entityManager.find(MediaContentEntity.class, loadId));
//		return tci;
//	}
//
//	@Override
//	public TopicContentInfo getStudyContent(String key, Long pre, Long loadId, Long next) {
//		TopicEntity te = __byKey(key);
//		TopicContentInfo tci = new TopicContentInfo();
//		if(pre != null && pre > 0){
//			__pre(tci, entityManager.find(DocContentEntity.class, pre));
//		}else{
//			String ql = __ql("select distinct x from DocContentEntity x where x.deleted=false", te) + " and x.id<? order by x.id asc";
//			TypedQuery<DocContentEntity> qt = entityManager.createQuery(ql, DocContentEntity.class);
//			qt.setParameter(1, loadId);
//			qt.setMaxResults(1);
//			List<DocContentEntity> dces = qt.getResultList();
//			if(!dces.isEmpty()){
//				__pre(tci, dces.get(0));
//			}
//		}
//		
//		if(next != null && next > 0){
//			__next(tci, entityManager.find(DocContentEntity.class, next));
//		}else{
//			String ql = __ql("select distinct x from DocContentEntity x where x.deleted=false", te) + " and x.id>? order by x.id desc";
//			TypedQuery<DocContentEntity> qt = entityManager.createQuery(ql, DocContentEntity.class);
//			qt.setParameter(1, loadId);
//			qt.setMaxResults(1);
//			List<DocContentEntity> dces = qt.getResultList();
//			if(!dces.isEmpty()){
//				__next(tci, dces.get(0));
//			}
//		}
//		tci.setInfo(entityManager.find(DocContentEntity.class, loadId));
//		return tci;
//	}
	
//	private void __next(TopicContentInfo tci, BaseContentEntity bce){
//		tci.setNextId(bce.getId());
//		tci.setNextTitle(bce.getName());
//	}
	
//	private void __pre(TopicContentInfo tci, BaseContentEntity bce){
//		tci.setPreId(bce.getId());
//		tci.setPreTitle(bce.getName());
//	}
	
	private String __ql(String ql, TopicEntity te){
		if(te.getArea() != null){
			ql += " and x.area.id=" + te.getArea().getId();
		}
		if(te.getGroup() != null){
			ql += " and x.group.id=" + te.getGroup().getId();
		}
		if(te.getKnowledge() != null){
			ql += " and x.knowledge.id=" + te.getKnowledge().getId();
		}
		if(te.getProcess() != null){
			ql += " and x.process.id=" + te.getProcess().getId();
		}
		return ql;
	}

	@Override
	public TopicContentInfo getStudyContent(String key, Long id) {
		TopicEntity te = __byKey(key);
		String ql = __ql("select distinct x from DocContentEntity x where x.deleted=false and x.share=true", te) + " order by x.id desc";
		TypedQuery<DocContentEntity> qt = entityManager.createQuery(ql, DocContentEntity.class);
		qt.setMaxResults(10);
		List<DocContentEntity> dces = qt.getResultList();
		if(dces.isEmpty()){
			return null;
		}
		TopicContentInfo tci = new TopicContentInfo();
		for(DocContentEntity dc : dces){
//			if(dc.getId().equals(id)){
				tci.add(dc);
//			}
//			tci.add(dc.getId(), dc.getName());
		}
//		tci.add(dces.get(0));
		return tci;
	}

	@Override
	public TopicContentInfo getStudyMedia(String key, Long id) {
		TopicEntity te = __byKey(key);
		String ql = __ql("select distinct x from MediaContentEntity x where x.deleted=false and x.share=true", te) + " order by x.id desc";
		TypedQuery<MediaContentEntity> qt = entityManager.createQuery(ql, MediaContentEntity.class);
		qt.setMaxResults(2);
		List<MediaContentEntity> dces = qt.getResultList();
		if(dces.isEmpty()){
			return null;
		}
		TopicContentInfo tci = new TopicContentInfo();
		
		for(MediaContentEntity mc : dces){
//			if(mc.getId().equals(id)){
				tci.add(mc);
//			}
//			tci.add(mc.getId(), mc.getName());
		}
//		tci.add(dces.get(0));
		return tci;
	}
}
