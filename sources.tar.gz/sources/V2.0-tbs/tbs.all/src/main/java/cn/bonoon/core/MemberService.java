package cn.bonoon.core;

import java.util.Date;
import java.util.List;

import cn.bonoon.core.configs.CashExchangeConfig;
import cn.bonoon.entities.ExchangeEntity;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.MemberGradeEntity;
import cn.bonoon.entities.MemberSettingEntity;
import cn.bonoon.entities.RechargeEntity;
import cn.bonoon.entities.plugins.Sex;
import cn.bonoon.kernel.io.FileInfo;
import cn.bonoon.kernel.support.IOperator;
import cn.bonoon.kernel.support.services.GenericService;

public interface MemberService extends GenericService<MemberEntity>{
	void register(String loginName, String userName, String loginPassword, String confirmPassword, String introducekey);

	/**
	 * 我直接介绍的同学
	 * @param my
	 * @return
	 */
	List<MemberEntity> myIntroduces(String my);

	MemberEntity loginSuccess(IOperator user);

	MemberEntity update(Long id, String name, Sex sex, Long place, String introduction, String phone,
			String homeTel, String qq, String email, String homeAddress, String companyName, 
			String companyTel, String companyAddress, String trainingOrg, String remark, FileInfo fi);

	MemberSettingEntity getFunctionMapping(IOperator user);

	void update(MemberSettingEntity fm);

	void update(MemberSettingEntity fm, Date now, int cost, boolean costCash, String remark);

	MemberGradeEntity getGrade(MemberEntity member);

	MemberEntity getMember(IOperator user);
	
	/**
	 * 充值
	 * @param entity
	 */
	void saveRecharge(RechargeEntity entity);
	
	void updateRecharge(RechargeEntity entity, CashExchangeConfig config);
	
	<R extends RechargeEntity> R getRecharge(String oid, Class<R> entityClass);

	void saveExchange(MemberEntity member, ExchangeEntity ee);

	MemberEntity get(String loginName);

	void update(MemberEntity member, String pwd);

	List<String> tips(MemberEntity member);

	MemberGradeEntity next(MemberGradeEntity mge);

	boolean hasMember(String key);
}
