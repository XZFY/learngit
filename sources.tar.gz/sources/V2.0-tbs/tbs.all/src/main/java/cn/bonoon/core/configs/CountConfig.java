package cn.bonoon.core.configs;

import cn.bonoon.kernel.web.annotations.components.AsNumberBox;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

@FormEditor(value = 3, headWidth = 100, width = 200)
public class CountConfig {
	
	@AsNumberBox
	@PropertyEditor(name="练习题目数", value = 0, width = 60)
	@PropertyHelper(value = "题目的数量！", type = HelperType.DIRECT)
	private int praxisCount;
	@AsNumberBox
	@PropertyEditor(name="难度 从", value = 1, width = 60)
	@PropertyHelper(value = "如：level>=start", type = HelperType.DIRECT)
	private int praxisStart;
	@AsNumberBox
	@PropertyEditor(name="到", value = 2, width = 60)
	@PropertyHelper(value = "如：level<end", type = HelperType.DIRECT)
	private int praxisEnd;

	@AsNumberBox
	@PropertyEditor(name="提高题目数", value = 10, width = 60)
	@PropertyHelper(value = "题目的数量", type = HelperType.DIRECT)
	private int improveCount;
	@AsNumberBox
	@PropertyEditor(name="难度 从", value = 11, width = 60)
	@PropertyHelper(value = "如：level>=start", type = HelperType.DIRECT)
	private int improveStart;
	@AsNumberBox
	@PropertyEditor(name="到", value = 12, width = 60)
	@PropertyHelper(value = "如：level<end", type = HelperType.DIRECT)
	private int improveEnd;
	
	@AsNumberBox
	@PropertyEditor(name="快战[免费]数", value = 20, width = 60)
	@PropertyHelper(value = "快战功能的题目数量", type = HelperType.DIRECT)
	private int freeFastCount;
	@AsNumberBox
	@PropertyEditor(name="实战[免费]数", value = 21, width = 60)
	@PropertyHelper(value = "实战功能的题目数量", type = HelperType.DIRECT)
	private int freeCombatCount;
	@AsNumberBox
	@PropertyEditor(name="难度", value = 22, width = 60)
	@PropertyHelper(value = "快战和实战的难度", type = HelperType.DIRECT)
	private int freeLevel;

	@AsNumberBox
	@PropertyEditor(name="简单级别", value = 40, colspan = 2, width = 80)
	@PropertyHelper(value = "用户达到多少的总积分可以开通简单难度级别的题目！", type = HelperType.DIRECT)
	private int levelOne;
	@AsNumberBox
	@PropertyEditor(name="正常级别", value = 41, colspan = 2, width = 80)
	@PropertyHelper(value = "用户达到多少的总积分可以开通正常难度级别的题目！", type = HelperType.DIRECT)
	private int levelTwo;
	@AsNumberBox
	@PropertyEditor(name="困难级别", value = 42, colspan = 2, width = 80)
	@PropertyHelper(value = "用户达到多少的总积分可以开通困难难度级别的题目！", type = HelperType.DIRECT)
	private int levelThree;
	
	public int getImproveCount() {
		return improveCount;
	}

	public void setImproveCount(int improveCount) {
		this.improveCount = improveCount;
	}

	public int getFreeFastCount() {
		return freeFastCount;
	}

	public void setFreeFastCount(int freeFastCount) {
		this.freeFastCount = freeFastCount;
	}

	public int getFreeCombatCount() {
		return freeCombatCount;
	}

	public void setFreeCombatCount(int freeCombatCount) {
		this.freeCombatCount = freeCombatCount;
	}

	public int getPraxisCount() {
		return praxisCount;
	}
	
	public void setPraxisCount(int praxisCount) {
		this.praxisCount = praxisCount;
	}
	
//	public int getFreeCount() {
//		return freeCount;
//	}
//	
//	public void setFreeCount(int freeCount) {
//		this.freeCount = freeCount;
//	}

	public int getLevelOne() {
		return levelOne;
	}

	public void setLevelOne(int levelOne) {
		this.levelOne = levelOne;
	}

	public int getLevelTwo() {
		return levelTwo;
	}

	public void setLevelTwo(int levelTwo) {
		this.levelTwo = levelTwo;
	}

	public int getLevelThree() {
		return levelThree;
	}

	public void setLevelThree(int levelThree) {
		this.levelThree = levelThree;
	}

	public int getPraxisStart() {
		return praxisStart;
	}

	public void setPraxisStart(int praxisStart) {
		this.praxisStart = praxisStart;
	}

	public int getPraxisEnd() {
		return praxisEnd;
	}

	public void setPraxisEnd(int praxisEnd) {
		this.praxisEnd = praxisEnd;
	}

	public int getImproveStart() {
		return improveStart;
	}

	public void setImproveStart(int improveStart) {
		this.improveStart = improveStart;
	}

	public int getImproveEnd() {
		return improveEnd;
	}

	public void setImproveEnd(int improveEnd) {
		this.improveEnd = improveEnd;
	}

	public int getFreeLevel() {
		return freeLevel;
	}

	public void setFreeLevel(int freeLevel) {
		this.freeLevel = freeLevel;
	}
	
}
