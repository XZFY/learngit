package cn.bonoon.controllers.topic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.controllers.comment.CommentDialog;
import cn.bonoon.core.TopicCommentService;
import cn.bonoon.core.TopicService;
import cn.bonoon.entities.TopicEntity;
import cn.bonoon.kernel.web.ButtonEventType;
import cn.bonoon.kernel.web.annotations.grid.GridStandardDefinition;
import cn.bonoon.kernel.web.controllers.AbstractGridController;

@Controller
@RequestMapping("s/pmp/topic")
public class TopicController extends AbstractGridController<TopicEntity, TopicItem> {
	private final TopicService service;
	private final TopicCommentService commentService;
	
	@Autowired
	public TopicController(TopicService service, TopicCommentService commentService) {
		super(service);
		this.service = service;
		this.commentService = commentService;
	}

	@Override
	@GridStandardDefinition(
			insertClass = TopicEditor.class, 
			updateClass = TopicEditor.class, 
			detailClass = TopicDetail.class)
	protected TopicService initLayoutGrid(LayoutGridRegister register) throws Exception {
//		register.setDialogHeight(450);
		//添加按键
//		DialogInsertHandler.toolbar(register, service, TopicEditor.class);
//		OperateIdsHandler.resume(register, service);
//		OperateIdsHandler.forbid(register, service);
//		OperateIdsHandler.delete(register, service);
		//导入
		register.toolbar("导入题目", "import.dlg", ButtonEventType.DIALOG).ordinal(50);
		
//		DialogDetailHandler.button(register, service, TopicDetail.class);
//		DialogUpdateHandler.button(register, service, TopicEditor.class);
//		OperateIdHandler.resume(register, service);
//		OperateIdHandler.forbid(register, service);
//		OperateIdHandler.delete(register, service);
		//对题目的评论、评分
		CommentDialog.button(register, commentService).ordinal(70);
		return service;
	}

	@Override
	protected Class<TopicItem> itemClass() {
		return TopicItem.class;
	}
}
