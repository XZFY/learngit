package cn.bonoon.controllers;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import cn.bonoon.core.AssistantService;
import cn.bonoon.core.configs.OpenedPointsConfig;
import cn.bonoon.entities.MemberSettingEntity;

public abstract class AbstractAssistantController extends AbstractIndexController{

	
	@Autowired
	protected AssistantService assistantService;
	
	@Override
	protected void init() {
		functionName 	= "学习助手";
		functionMenu 	= "menus/menu-assistant.vm";
		channelSelected = "assistant";
		vmTrial 		= "assistant";
		trialTitle 		= "<span style='font-size: 18px; font-family: Arial;padding-left:15px;'>试用</span>";
	}
	
	@Override
	protected boolean hasOpened(MemberSettingEntity fm) {
		return fm.isAssistantOpened();
	}
	
	@Override
	protected int reachPoint(OpenedPointsConfig opc) {
		return opc.getAssistantReach();
	}
	
	@Override
	protected int openCost(OpenedPointsConfig opc) {
		return opc.getAssistantCost();
	}

	@Override
	protected boolean openCoseCash(OpenedPointsConfig opc) {
		return opc.isAssistantCostCash();
	}
	
	@Override
	protected void open(MemberSettingEntity fm, int cost, Date now) {
		fm.setAssistantAt(now);
		fm.setAssistantOpened(true);
		fm.setAssistantPoints(cost);
	}

}
