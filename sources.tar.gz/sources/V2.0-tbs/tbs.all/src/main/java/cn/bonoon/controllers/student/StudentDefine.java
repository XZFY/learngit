package cn.bonoon.controllers.student;

import cn.bonoon.kernel.annotations.OptionArray;
import cn.bonoon.kernel.annotations.ResetProperties;
import cn.bonoon.kernel.annotations.ResetProperty;

@ResetProperties({
	@ResetProperty(value = "name", name = "学生姓名"),
	@ResetProperty(value = "loginName", name = "登录账号"),
	@ResetProperty(value = "registerAt", name = "注册时间"),
	@ResetProperty(value = "member", name = "学生"),
	@ResetProperty(value = "points", name = "学初始积分"),
	@ResetProperty(value = "phone", name = "手机号码"),
	@ResetProperty(value = "sid", name = "学号"),
	@ResetProperty(value = "remark", name = "备注"),
	@ResetProperty(value = "status", name = "状态", options = @OptionArray({"报名", "正在学习", "毕业", "肄业"}))
})
public interface StudentDefine {

}
