package cn.bonoon.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import cn.bonoon.entities.plugins.AccountEntity;
import cn.bonoon.entities.plugins.PlaceEntity;
import cn.bonoon.kernel.support.entities.EntityOwner;

/**
 * 培训机构
 * @author jackson
 *
 */
@Entity
@Table(name = "T_TRAININGINSTITUTION")
public class TrainingInstitutionEntity extends AccountEntity implements EntityOwner{

	/**
	 * 
	 */
	private static final long serialVersionUID = -714308914204880616L;
	
	public TrainingInstitutionEntity(){
		this.typeName = "机构";
	}
	
	@ManyToOne
	@JoinColumn(name = "R_PLACE_ID")
	private PlaceEntity place;

	@Column(name = "C_LEVEL")
	private int level;

	@Column(name = "C_CONTACTS")
	private String contacts;

	@Column(name = "C_CONTACTNUMBER")
	private String contactNumber;

	@Column(name = "C_ZIPCODE")
	private String zipCode;

	@Column(name = "C_ADDRESS")
	private String address;
	
	public String getContacts() {
		return contacts;
	}

	public void setContacts(String contacts) {
		this.contacts = contacts;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public PlaceEntity getPlace() {
		return place;
	}

	public void setPlace(PlaceEntity place) {
		this.place = place;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}
}
