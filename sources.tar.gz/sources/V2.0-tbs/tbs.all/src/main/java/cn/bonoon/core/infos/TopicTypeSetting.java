package cn.bonoon.core.infos;

import cn.bonoon.entities.TopicEntity;

public class TopicTypeSetting {
	private boolean freeCombat;
	private boolean praxis;
	private boolean improve;
	private boolean freeFast;
	
	public void setting(TopicEntity tp){
		tp.setFreeCombat(freeCombat);
		tp.setFreeFast(freeFast);
		tp.setPraxis(praxis);
		tp.setImprove(improve);
	}

	public boolean isFreeCombat() {
		return freeCombat;
	}

	public void setFreeCombat(boolean freeCombat) {
		this.freeCombat = freeCombat;
	}

	public boolean isPraxis() {
		return praxis;
	}

	public void setPraxis(boolean praxis) {
		this.praxis = praxis;
	}

	public boolean isImprove() {
		return improve;
	}

	public void setImprove(boolean improve) {
		this.improve = improve;
	}

	public boolean isFreeFast() {
		return freeFast;
	}

	public void setFreeFast(boolean freeFast) {
		this.freeFast = freeFast;
	}
	
}
