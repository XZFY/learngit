package cn.bonoon.services;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.ResourceService;
import cn.bonoon.core.infos.DocumentInfo;
import cn.bonoon.core.infos.VideoInfo;
import cn.bonoon.entities.DocContentEntity;
import cn.bonoon.entities.MediaContentEntity;
import cn.bonoon.kernel.support.models.Page;
import cn.bonoon.kernel.support.services.ServiceSupport;
import cn.bonoon.kernel.util.StringHelper;

@Service
@Transactional(readOnly = true)
public class ResourceServiceImpl extends ServiceSupport implements ResourceService {

	private void __page(Query query, int page, int size){
		query.setFirstResult(page * size).setMaxResults(size);
	}
	
	private final String v_0 = "select x from MediaContentEntity x where x.share=true and x.deleted=false";
	private final String v_1 = "select count(x) from MediaContentEntity x where x.share=true and x.deleted=false";

	@Override
	public Page shareVideos(int page, int size, String name) {
		if(StringHelper.isNotEmpty(name)){
			name = "%" + name + "%";
			String qls = v_0 + " and x.name like ?  order by x.id desc";
			TypedQuery<MediaContentEntity> query = entityManager.createQuery(qls, MediaContentEntity.class);
			query.setParameter(1, name);
			if(size > 0){
				String qlc = v_1 + " and x.name like ?";
				__page(query, page, size);
				
				TypedQuery<Long> tqco = entityManager.createQuery(qlc, Long.class);
				tqco.setParameter(1, name);
	
				return new Page(tqco.getSingleResult().longValue(), __videos(query));
			}
			return new Page(__videos(query));
		}else{
			TypedQuery<MediaContentEntity> query = entityManager.createQuery(v_0 + " order by x.id desc", MediaContentEntity.class);
			if(size > 0){
				__page(query, page, size);
				
				TypedQuery<Long> tqco = entityManager.createQuery(v_1, Long.class);
	
				return new Page(tqco.getSingleResult().longValue(), __videos(query));
			}
			return new Page(__videos(query));
		}
	}
	
	private final String d_0 = "select x from DocContentEntity x where x.share=true and x.deleted=false";
	private final String d_1 = "select count(x) from DocContentEntity x where x.share=true and x.deleted=false";

	@Override
	public Page shareDocuments(int page, int size, String name) {
		if(StringHelper.isNotEmpty(name)){
			name = "%" + name + "%";
			String qls = d_0 + " and x.name like ? order by x.id desc";
			
			TypedQuery<DocContentEntity> query = entityManager.createQuery(qls, DocContentEntity.class);
			query.setParameter(1, name);
			if(size > 0){
				String qlc = d_1 + " and x.name like ?";
				__page(query, page, size);
				
				TypedQuery<Long> tqco = entityManager.createQuery(qlc, Long.class);
				tqco.setParameter(1, name);
	
				return new Page(tqco.getSingleResult().longValue(), __documents(query));
			}
			return new Page(__documents(query));
		}else{
			TypedQuery<DocContentEntity> query = entityManager.createQuery(d_0 + " order by x.id desc", DocContentEntity.class);
			if(size > 0){
				__page(query, page, size);
				
				TypedQuery<Long> tqco = entityManager.createQuery(d_1, Long.class);
	
				return new Page(tqco.getSingleResult().longValue(), __documents(query));
			}
			return new Page(__documents(query));
		}
	}

	private List<Object> __videos(TypedQuery<MediaContentEntity> query) {
		List<Object> rows = new ArrayList<Object>();
		for(MediaContentEntity wae : query.getResultList()){
			rows.add(new VideoInfo(wae));
		}
		return rows;
	}


	private List<Object> __documents(TypedQuery<DocContentEntity> query) {
		List<Object> rows = new ArrayList<Object>();
		for(DocContentEntity wae : query.getResultList()){
			rows.add(new DocumentInfo(wae));
		}
		return rows;
	}

}
