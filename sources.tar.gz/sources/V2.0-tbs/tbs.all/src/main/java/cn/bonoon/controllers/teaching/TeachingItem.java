package cn.bonoon.controllers.teaching;

import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.support.models.AbstractItem;
import cn.bonoon.kernel.web.annotations.grid.AsColumn;
import cn.bonoon.kernel.web.annotations.grid.AsDataGrid;

@AsDataGrid(condition = TeachingCondition.class)
public class TeachingItem extends AbstractItem implements TeachingDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = -149334874740414516L;

	@AsColumn(width = 120, ordinal = 0)
	@TransformField("teacher.name")
	private String teacher;
	
	@AsColumn(width = 120, ordinal = 10)
	@TransformField("classes.name")
	private String classes;
	
	@AsColumn(width = 120, ordinal = 11)
	private String status;
	
	@AsColumn(width = 100, ordinal = 20)
	private String createAt;
	
	@AsColumn(width = 100, ordinal = 30)
	private String courseName;

	public String getTeacher() {
		return teacher;
	}

	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}

	public String getClasses() {
		return classes;
	}

	public void setClasses(String classes) {
		this.classes = classes;
	}

	public String getCreateAt() {
		return createAt;
	}

	public void setCreateAt(String createAt) {
		this.createAt = createAt;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
