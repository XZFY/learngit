package cn.bonoon.controllers;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.bonoon.Util;
import cn.bonoon.core.ResourceService;
import cn.bonoon.core.configs.OpenedPointsConfig;
import cn.bonoon.core.configs.PageSizeConfig;
import cn.bonoon.entities.MemberEntity;
import cn.bonoon.entities.MemberSettingEntity;
import cn.bonoon.kernel.events.BaseEvent;
import cn.bonoon.kernel.security.LogonUser;
import cn.bonoon.kernel.support.models.Page;
import cn.bonoon.kernel.util.StringHelper;

public abstract class AbstractResourceController extends AbstractIndexController{

	@Autowired
	protected ResourceService resourceService;
	
	@Override
	protected boolean hasOpened(MemberSettingEntity fm) {
		return fm.isResourceOpened();
	}
	
	@Override
	protected int reachPoint(OpenedPointsConfig opc) {
		return opc.getResourceReach();
	}
	
	@Override
	protected int openCost(OpenedPointsConfig opc) {
		return opc.getResourceCost();
	}

	@Override
	protected boolean openCoseCash(OpenedPointsConfig opc) {
		return opc.isResourceCostCash();
	}
	
	@Override
	protected void open(MemberSettingEntity fm, int cost, Date now) {
		fm.setResourceAt(now);
		fm.setResourceOpened(true);
		fm.setResourcePoints(cost);
	}

	protected String vmPaging;
	
	@Override
	protected void init() {
		functionName 	= "资源库";
		functionMenu 	= "menus/menu-resource.vm";
		channelSelected = "resource";
		vmTrial 		= "doc/resource";
		trialTitle 		= "<span style='font-size: 18px; font-family: Arial;padding-left:15px;'>试用</span>";
	}
	
	@Override
	protected String trial(HttpServletRequest request, Model model) {
		// TODO 提供试用的功能
		return super.trial(request, model);
	}

	protected PageSizeConfig __pageSize(){
		PageSizeConfig psc = new PageSizeConfig();
		try{
			configService.read(new BaseEvent(psc));
		}catch(Exception ex){}
		return psc;
	}
	
	@RequestMapping(value = "{pageIndex}!index.do", method = RequestMethod.GET)
	public String index(HttpServletRequest request, Model model, @PathVariable("pageIndex") int pageIndex, String name){
		__paging(request, model, pageIndex, name);
		model.addAttribute("layout", "layout-empty.vm");
		return vmPaging;
	}

	@Override
	protected String render(HttpServletRequest request, Model model, MemberEntity member, LogonUser user) {
		__paging(request, model, 0, null);
		return super.render(request, model, member, user);
	}
	
	protected void __paging(HttpServletRequest request, Model model, int pageIndex, String name) {
		int size = __size();
		Page page = readResource(pageIndex, size, name);
		String params = "";
		if(StringHelper.isNotEmpty(name)){
			params = "?name=" + name;
		}
		Util.paging(model, page, pageIndex, size, params);
		model.addAttribute("page", page);
	}
	
	protected abstract Page readResource(int pageIndex, int pageSize, String name);
	
	protected abstract int __size();
}
