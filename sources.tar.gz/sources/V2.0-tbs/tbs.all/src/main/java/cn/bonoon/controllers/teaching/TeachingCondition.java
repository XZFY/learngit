package cn.bonoon.controllers.teaching;

import cn.bonoon.kernel.annotations.condition.ConditionField;
import cn.bonoon.kernel.query.PageCondition;
import cn.bonoon.kernel.web.annotations.condition.ConditionContent;

public class TeachingCondition extends PageCondition implements TeachingDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4212214225471874457L;

	@ConditionContent("教师名称")
	@ConditionField("teacher.name")
	private String searchTeacher;

	@ConditionContent("班级")
	@ConditionField("classes.name")
	private String searchClasses;

	@ConditionContent
	private String searchCourseName;

	public String getSearchTeacher() {
		return searchTeacher;
	}

	public void setSearchTeacher(String searchTeacher) {
		this.searchTeacher = searchTeacher;
	}

	public String getSearchClasses() {
		return searchClasses;
	}

	public void setSearchClasses(String searchClasses) {
		this.searchClasses = searchClasses;
	}

	public String getSearchCourseName() {
		return searchCourseName;
	}

	public void setSearchCourseName(String searchCourseName) {
		this.searchCourseName = searchCourseName;
	}
}
