package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractEntity;

//班级
@Entity
@Table(name = "T_CLASSES")
public class ClassesEntity extends AbstractEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7558419583258112950L;
//
//	@ManyToOne
//	@JoinColumn(name = "R_INSTITUTION_ID")
//	private TrainingInstitutionEntity institution;

	//主教，班主任
	@ManyToOne
	@JoinColumn(name = "R_TEACHER_ID")
	private TeacherEntity teacher;

	@ManyToOne
	@JoinColumn(name = "R_MONITOR_ID")
	private StudentEntity monitor;
	
	//学生数
	@Column(name = "C_STUDENTCOUNT")
	private int studentCount;

	@Temporal(TemporalType.DATE)
	@Column(name = "C_BEGINAT")
	private Date beginAt;

	@Temporal(TemporalType.DATE)
	@Column(name = "C_FINISHAT")
	private Date finishAt;

	@Column(name = "C_STATUS")
	private int status;

//	public TrainingInstitutionEntity getInstitution() {
//		return institution;
//	}
//
//	public void setInstitution(TrainingInstitutionEntity institution) {
//		this.institution = institution;
//	}

	public TeacherEntity getTeacher() {
		return teacher;
	}

	public void setTeacher(TeacherEntity teacher) {
		this.teacher = teacher;
	}

	public int getStudentCount() {
		return studentCount;
	}

	public void setStudentCount(int studentCount) {
		this.studentCount = studentCount;
	}

	public StudentEntity getMonitor() {
		return monitor;
	}

	public void setMonitor(StudentEntity monitor) {
		this.monitor = monitor;
	}

	public Date getBeginAt() {
		return beginAt;
	}

	public void setBeginAt(Date beginAt) {
		this.beginAt = beginAt;
	}

	public Date getFinishAt() {
		return finishAt;
	}

	public void setFinishAt(Date finishAt) {
		this.finishAt = finishAt;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
}
