package cn.bonoon.controllers.student;

import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.support.models.AbstractItem;
import cn.bonoon.kernel.web.annotations.grid.AsColumn;
import cn.bonoon.kernel.web.annotations.grid.AsDataGrid;

@AsDataGrid(condition = StudentCondition.class)
public class StudentItem extends AbstractItem implements StudentDefine{

	/**
	 * 
	 */
	private static final long serialVersionUID = 522474720155850360L;
	
	@AsColumn(width = 120, ordinal = 0)
	private String sid;
	
	@AsColumn(width = 120, ordinal = 0)
	@TransformField("member.name")
	private String name;
	
	@AsColumn(width = 120, ordinal = 0)
	private String status;

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
