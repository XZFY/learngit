package cn.bonoon.services;

import java.util.ArrayList;
import java.util.List;

public class RandomHelper {

	public static List<String> random(List<String> keys, int topCount) {
		int size = keys.size();
		if(size > topCount * 2){
			String[] strs = new String[size];
			strs = keys.toArray(strs);
			List<String> rst = new ArrayList<String>(topCount);
			int count = 0;
			while(count < topCount){
				int rdm = (int)(Math.random() * 1000) % size;
				if(null != strs[rdm]){
					rst.add(strs[rdm]);
					strs[rdm] = null;
					count++;
				}
			}
			keys = rst;
		} else {
			while(size > topCount){
				//随机删除
				int rdm = (int)(Math.random() * 1000) % size;
				keys.remove(rdm);
				size = keys.size();
			}
		}
		return keys;
	}
}
