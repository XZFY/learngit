package cn.bonoon.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

@Entity
@Table(name = "T_ANSWERITEM")
public class AnswerStatisticsItem extends AbstractPersistable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8154893143435982336L;

	@ManyToOne
	@JoinColumn(name = "R_ANSWER_ID")
	private AnswerEntity answer;
	
	@Enumerated
	@Column(name = "C_TYPE")
	private AnswerStatisticsType type;

	@Column(name = "C_TID")
	private Long tid;
	
	@Column(name = "C_NAME")
	private String name;
	
	@Column(name = "C_TOTAL")
	private int total;
	
	@Column(name = "C_RIGHT")
	private int right;
	
	@Column(name = "C_CREATORID")
	private Long creatorId;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "C_CREATEAT")
	private Date createAt;

	@Column(name = "C_ORDINAL")
	private int ordinal;

	//得分
	@Column(name = "C_SCORE")
	private double score;

	public AnswerEntity getAnswer() {
		return answer;
	}

	public void setAnswer(AnswerEntity answer) {
		this.answer = answer;
	}

	public AnswerStatisticsType getType() {
		return type;
	}

	public void setType(AnswerStatisticsType type) {
		this.type = type;
	}

	public Long getTid() {
		return tid;
	}

	public void setTid(Long tid) {
		this.tid = tid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getRight() {
		return right;
	}

	public void setRight(int right) {
		this.right = right;
	}

	public Long getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(Long creatorId) {
		this.creatorId = creatorId;
	}

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	public int getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(int ordinal) {
		this.ordinal = ordinal;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}
	
}
