package cn.bonoon.controllers.member;

import cn.bonoon.kernel.annotations.OptionArray;
import cn.bonoon.kernel.annotations.ResetProperties;
import cn.bonoon.kernel.annotations.ResetProperty;

@ResetProperties({
	@ResetProperty(value = "name", name = "会员名称"),
	@ResetProperty(value = "loginName", name = "登录名"),
	@ResetProperty(value = "homeTel", name = "家庭电话"),
	@ResetProperty(value = "phone", name = "手机"),
	@ResetProperty(value = "email", name = "邮箱"),
	@ResetProperty(value = "sex", name = "性别"),
	@ResetProperty(value = "qq", name = "QQ号码"),
	@ResetProperty(value = "companyName", name = "单位名称"),
	@ResetProperty(value = "companyTel", name = "办公电话"),
	@ResetProperty(value = "trainingOrg", name = "培训机构"),
	@ResetProperty(value = "place", name = "所在地区"),
	@ResetProperty(value = "homeAddress", name = "家庭住址"),
	@ResetProperty(value = "companyAddress", name = "单位地址"),
	@ResetProperty(value = "totalPoints", name = "总积分"),
	@ResetProperty(value = "availablePoints", name = "可用积分"),
	@ResetProperty(value = "availableCash", name = "可用钻石"),
	@ResetProperty(value = "status", name = "状态", 
		options = @OptionArray({"未审", "正常", "禁止"})),
	@ResetProperty(value = "remark", name = "备注")
})
public interface MemberDefine {

}
