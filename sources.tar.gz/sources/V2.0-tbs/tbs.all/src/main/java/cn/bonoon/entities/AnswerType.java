package cn.bonoon.entities;

public enum AnswerType {
	PRAXIS("练习"),
	//以下4个都归于提高的范围
	AREA("领域"), POINT("知识点"), PROCESS("过程"), GROUP("过程组"),
	PAGER("试卷"),
	REAL("真题"),
	OTHER("其它");
	private final String display;
	
	private AnswerType(String display){
		this.display = display;
	}
	
	public String getDisplay() {
		return display;
	}
	
	@Override
	public String toString() {
		return display;
	}
}
