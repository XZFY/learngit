package cn.bonoon.controllers.member;

import cn.bonoon.kernel.annotations.Transform;
import cn.bonoon.kernel.annotations.TransformField;
import cn.bonoon.kernel.web.annotations.form.FormDetail;
import cn.bonoon.kernel.web.annotations.form.PropertyDetail;

@FormDetail(2)
@Transform
public class MemberDetail implements MemberDefine{

	@PropertyDetail(1)
	private String name;
	@PropertyDetail(0)
	private String loginName;
	
	@PropertyDetail(11)
	private String status;
	@PropertyDetail(name = "唯一编码")
	private String key;
	
	@PropertyDetail(10)
	private String phone;
	@PropertyDetail(11)
	private String email;
	
	@PropertyDetail(13)
	private String homeTel;
	@PropertyDetail(12)
	private String qq;
	
	@PropertyDetail(14)
	private String companyTel;
	@PropertyDetail(15)
	@TransformField("sex.description")
	private String sex;
	@PropertyDetail(value = 16, colspan = 1)
	@TransformField("place.fullName")
	private String place;
	
	@PropertyDetail(20)
	private long totalPoints;
	@PropertyDetail(21)
	private long availablePoints;
	
	@PropertyDetail(value = 31, colspan = 1)
	private String companyName;
	@PropertyDetail(value = 33, colspan = 1)
	private String trainingOrg;
	@PropertyDetail(value = 30, colspan = 1)
	private String homeAddress;
	@PropertyDetail(value = 32, colspan = 1)
	private String companyAddress;

	@PropertyDetail(value = 100, colspan = 1)
	private String remark;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getHomeTel() {
		return homeTel;
	}
	public void setHomeTel(String homeTel) {
		this.homeTel = homeTel;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getQq() {
		return qq;
	}
	public void setQq(String qq) {
		this.qq = qq;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyTel() {
		return companyTel;
	}
	public void setCompanyTel(String companyTel) {
		this.companyTel = companyTel;
	}
	public String getTrainingOrg() {
		return trainingOrg;
	}
	public void setTrainingOrg(String trainingOrg) {
		this.trainingOrg = trainingOrg;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}
	public String getCompanyAddress() {
		return companyAddress;
	}
	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}
	public long getTotalPoints() {
		return totalPoints;
	}
	public void setTotalPoints(long totalPoints) {
		this.totalPoints = totalPoints;
	}
	public long getAvailablePoints() {
		return availablePoints;
	}
	public void setAvailablePoints(long availablePoints) {
		this.availablePoints = availablePoints;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	
}
