package cn.bonoon.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bonoon.core.AnswerService;
import cn.bonoon.entities.AnswerEntity;
import cn.bonoon.kernel.support.services.AbstractSearchService;

@Service
@Transactional(readOnly = true)
public class AnswerServiceImpl extends AbstractSearchService<AnswerEntity> implements AnswerService{

}
