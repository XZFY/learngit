package cn.bonoon.core.infos;

import cn.bonoon.entities.MemberEntity;
import cn.bonoon.kernel.support.models.Page;

public class RedeemInfo {
	
	private Page page;
	
	private MemberEntity member;
	
//	public List<RealInfo> getItems() {
//		return items;
//	}
//	public void setItems(List<RealInfo> items) {
//		this.items = items;
//	}
	public MemberEntity getMember() {
		return member;
	}
	public void setMember(MemberEntity member) {
		this.member = member;
	}
	public Page getPage() {
		return page;
	}
	public void setPage(Page page) {
		this.page = page;
	}
}
