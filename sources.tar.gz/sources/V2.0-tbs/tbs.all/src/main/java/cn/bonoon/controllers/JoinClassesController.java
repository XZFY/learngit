//package cn.bonoon.controllers;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//@Controller
//@RequestMapping("pmp/join/classes")
//public class JoinClassesController extends AbstractClassesController{
//
//	@Override
//	protected void init() {
//		functionTitle 	= "班级-加入";
//		vmName 			= "classes/improve";
//		menuSelected 	= "join";
//	}
//}
