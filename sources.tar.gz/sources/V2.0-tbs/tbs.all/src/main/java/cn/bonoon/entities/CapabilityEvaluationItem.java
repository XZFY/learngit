package cn.bonoon.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import cn.bonoon.kernel.support.entities.AbstractPersistable;

@Entity
@Table(name = "T_CEITEM")
public class CapabilityEvaluationItem extends AbstractPersistable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8502486628359543298L;

	@ManyToOne
	@JoinColumn(name = "R_EVALUATION_ID")
	private CapabilityEvaluationEntity evaluation;

	@Column(name = "C_KNOWLEDGE")
	private Long knowledge;

	@Column(name = "C_TOTALCOUNT")
	private int totalCount;//总的次数

	@Column(name = "C_RIGHTCOUNT")
	private int rightCount;//对的次数

	@Column(name = "C_WEIGHT")
	private double weight;//评估时该知识点所使用的加权值
	
	@Column(name = "C_CAPABILITY")
	private double capability;
	
	public CapabilityEvaluationEntity getEvaluation() {
		return evaluation;
	}

	public void setEvaluation(CapabilityEvaluationEntity evaluation) {
		this.evaluation = evaluation;
	}

	public Long getKnowledge() {
		return knowledge;
	}

	public void setKnowledge(Long knowledge) {
		this.knowledge = knowledge;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getRightCount() {
		return rightCount;
	}

	public void setRightCount(int rightCount) {
		this.rightCount = rightCount;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getCapability() {
		return capability;
	}

	public void setCapability(double capability) {
		this.capability = capability;
	}
}
