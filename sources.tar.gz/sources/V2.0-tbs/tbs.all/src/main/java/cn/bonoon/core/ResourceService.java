package cn.bonoon.core;

import cn.bonoon.kernel.support.models.Page;

public interface ResourceService {

	Page shareVideos(int page, int size, String name);

	Page shareDocuments(int page, int size, String name);
}
