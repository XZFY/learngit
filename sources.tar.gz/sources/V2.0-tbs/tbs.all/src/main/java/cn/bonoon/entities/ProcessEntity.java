package cn.bonoon.entities;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "T_PROCESS")
public class ProcessEntity extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 275713413828312252L;

}
