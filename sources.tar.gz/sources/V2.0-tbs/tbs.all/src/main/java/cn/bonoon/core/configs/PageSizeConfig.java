package cn.bonoon.core.configs;

import cn.bonoon.kernel.web.annotations.components.AsNumberBox;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

@FormEditor(headWidth = 140, width = 600)
public class PageSizeConfig {
	
	@AsNumberBox
	@PropertyEditor(name = "错题页数", value = 10, width = 40)
	@PropertyHelper(value = "我的错题集第页的数量，0-表示不分页全部显示", type = HelperType.DIRECT)
	private int wrongSize;
	
	@AsNumberBox
	@PropertyEditor(name = "进度页数", value = 11, width = 40)
	@PropertyHelper(value = "我的进度每页数量，0-表示不分页全部显示", type = HelperType.DIRECT)
	private int progressSize;

	@AsNumberBox
	@PropertyEditor(name = "视频页数", value = 20, width = 40)
	@PropertyHelper(value = "我的视频每页数量，0-表示不分页全部显示", type = HelperType.DIRECT)
	private int videoSize;

	@AsNumberBox
	@PropertyEditor(name = "文档页数", value = 21, width = 40)
	@PropertyHelper(value = "我的文档每页数量，0-表示不分页全部显示", type = HelperType.DIRECT)
	private int documentSize;

	@AsNumberBox
	@PropertyEditor(name = "共享视频页数", value = 22, width = 40)
	@PropertyHelper(value = "共享视频每页数量，0-表示不分页全部显示", type = HelperType.DIRECT)
	private int shareVideoSize;

	@AsNumberBox
	@PropertyEditor(name = "共享文档页数", value = 23, width = 40)
	@PropertyHelper(value = "共享文档每页数量，0-表示不分页全部显示", type = HelperType.DIRECT)
	private int shareDocumentSize;

	@AsNumberBox
	@PropertyEditor(name = "消费记录页数", value = 12, width = 40)
	@PropertyHelper(value = "我的消费记录每页数量，0-表示不分页全部显示", type = HelperType.DIRECT)
	private int consumerSize;

	@AsNumberBox
	@PropertyEditor(name = "试卷记录页数", value = 30, width = 40)
	@PropertyHelper(value = "试卷记录每页数量，0-表示不分页全部显示", type = HelperType.DIRECT)
	private int pagerSize;

	@AsNumberBox
	@PropertyEditor(name = "真题记录页数", value = 31, width = 40)
	@PropertyHelper(value = "真题记录每页数量，0-表示不分页全部显示", type = HelperType.DIRECT)
	private int realSize;
	
	public int getWrongSize() {
		return wrongSize;
	}
	public void setWrongSize(int wrongSize) {
		this.wrongSize = wrongSize;
	}
	public int getProgressSize() {
		return progressSize;
	}
	public void setProgressSize(int progressSize) {
		this.progressSize = progressSize;
	}
	public int getDocumentSize() {
		return documentSize;
	}
	public void setDocumentSize(int documentSize) {
		this.documentSize = documentSize;
	}
	public int getVideoSize() {
		return videoSize;
	}
	public void setVideoSize(int videoSize) {
		this.videoSize = videoSize;
	}
	public int getConsumerSize() {
		return consumerSize;
	}
	public void setConsumerSize(int consumerSize) {
		this.consumerSize = consumerSize;
	}
	public int getRealSize() {
		return realSize;
	}
	public void setRealSize(int realSize) {
		this.realSize = realSize;
	}
	public int getPagerSize() {
		return pagerSize;
	}
	public void setPagerSize(int pagerSize) {
		this.pagerSize = pagerSize;
	}
	public int getShareVideoSize() {
		return shareVideoSize;
	}
	public void setShareVideoSize(int shareVideoSize) {
		this.shareVideoSize = shareVideoSize;
	}
	public int getShareDocumentSize() {
		return shareDocumentSize;
	}
	public void setShareDocumentSize(int shareDocumentSize) {
		this.shareDocumentSize = shareDocumentSize;
	}
	
}
