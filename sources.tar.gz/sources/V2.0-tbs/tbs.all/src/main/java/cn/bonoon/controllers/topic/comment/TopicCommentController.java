package cn.bonoon.controllers.topic.comment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.bonoon.core.TopicCommentService;
import cn.bonoon.entities.TopicComment;
import cn.bonoon.kernel.web.annotations.grid.GridStandardDefinition;
import cn.bonoon.kernel.web.controllers.AbstractGridController;

@Controller
@RequestMapping("s/pmp/topic/comment")
public class TopicCommentController extends AbstractGridController<TopicComment, TopicCommentItem>{
	private final TopicCommentService service;
	
	@Autowired
	public TopicCommentController(TopicCommentService service) {
		super(service);
		this.service = service;
	}

	@Override
	@GridStandardDefinition(detailClass = TopicCommentDetail.class)
	protected TopicCommentService initLayoutGrid(LayoutGridRegister register) throws Exception {
		return service;
	}
}
