package cn.bonoon.core.configs;

import cn.bonoon.kernel.util.StringHelper;
import cn.bonoon.kernel.web.annotations.components.AsNumberBox;
import cn.bonoon.kernel.web.annotations.form.FormEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyEditor;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper;
import cn.bonoon.kernel.web.annotations.form.PropertyHelper.HelperType;

@FormEditor(value = 2, headWidth = 120, width = 300)
public class CashExchangeConfig {
	
	@AsNumberBox
	@PropertyEditor(name = "充值", value = 1, width = 80)
	@PropertyHelper(value = "即1元为多少钻石(默认为:1)", type = HelperType.DIRECT)
	private int cashRate = 1;

	@AsNumberBox
	@PropertyEditor(name = "成长分", value = 2, width = 80)
	@PropertyHelper(value = "即1元为多少分，非可用积分", type = HelperType.DIRECT)
	private int cashPoints = 300;

	@AsNumberBox
	@PropertyEditor(name = "积分", value = 3, width = 80)
	@PropertyHelper(value = "即1元奖多少可用的积分", type = HelperType.DIRECT)
	private int availablePoints;

	@PropertyEditor(name = "充值奖励", value = 4, colspan = 1)
	@PropertyHelper(value = "表达式：'-p 5'加5%；'10+2,20+4,40+10'表示充10元+2元等", type = HelperType.WRAP)
	private String cashBonus;

	@AsNumberBox
	@PropertyEditor(name = "转换", value = 0, width = 80)
	@PropertyHelper(value = "即1个钻可转为多少可用积分", type = HelperType.DIRECT)
	private int exchangeRate = 300;//兑换的汇率，即：1元人民币=多少积分
	
	public IBonus bonus(){
		if(StringHelper.isNotEmpty(cashBonus)){
			if(cashBonus.startsWith("-p")){
				return new PercentageBonusInfo(cashBonus);
			}
			String[] cbs = cashBonus.split(",");
			if(cbs.length > 0){
				CashBonusInfo cur, pre = null, fir = null;
				for(String cb : cbs){
					cur = new CashBonusInfo(cb, pre);
					pre = cur;
					if(null == fir){
						fir = cur;
					}
				}
				return fir;
			}
		}
		return IBonus.empty;
	}
	
	public static interface IBonus{
		int parseBonus(double amount);
		
		void exp(StringBuilder exp);
		
		IBonus empty = new IBonus(){

			@Override
			public int parseBonus(double amount) {
				return 0;
			}

			@Override
			public void exp(StringBuilder exp) {
				
			}};
	}
	
	private class PercentageBonusInfo implements IBonus{
		private int percent;
		private PercentageBonusInfo(String str){
			percent = StringHelper.toint(str.substring(3));
		}
		
		public int parseBonus(double amount){
			return (int)((amount / 100) * percent);
		}
		
		public void exp(StringBuilder exp){
			exp.append("<li>充值送").append(percent).append("%</li>");
		}
	}
	
	private class CashBonusInfo implements IBonus{
		
		private int start, end = Integer.MAX_VALUE;
		
		private int bonus;
		
//		private String exp;
		
		private CashBonusInfo next;
		
		private CashBonusInfo(String str, CashBonusInfo pre){
//			exp = str;
			int p = str.indexOf('+');
			if(p > 0){
				start = StringHelper.toint(str.substring(0, p));
				bonus = StringHelper.toint(str.substring(p + 1));
			}else{
				start = StringHelper.toint(str);
			}
			if(null != pre){
				pre.end = start;
				pre.next = this;
			}
		}
		
		public int parseBonus(double amount){
			if(amount >= start && amount < end){
				return bonus;
			}
			if(null != next){
				return next.parseBonus(amount);
			}
			return 0;
		}
		
		public void exp(StringBuilder exp){
			exp.append("<li>充值 ").append(start);
			if(end < Integer.MAX_VALUE){
				exp.append(" - ").append(end).append(" 元");
			}else{
				exp.append("元以上");
			}
			exp.append(" -> 送").append(bonus).append("</li>");
			if(null != next){
				next.exp(exp);
			}
		}
	}
	
	public int getCashRate() {
		return cashRate;
	}

	public void setCashRate(int cashRate) {
		this.cashRate = cashRate;
	}

	public int getCashPoints() {
		return cashPoints;
	}

	public void setCashPoints(int cashPoints) {
		this.cashPoints = cashPoints;
	}

	public String getCashBonus() {
		return cashBonus;
	}

	public void setCashBonus(String cashBonus) {
		this.cashBonus = cashBonus;
	}

	public int getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(int exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public int getAvailablePoints() {
		return availablePoints;
	}

	public void setAvailablePoints(int availablePoints) {
		this.availablePoints = availablePoints;
	}

}
