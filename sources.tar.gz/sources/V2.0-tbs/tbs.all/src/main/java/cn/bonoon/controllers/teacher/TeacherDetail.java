package cn.bonoon.controllers.teacher;

import cn.bonoon.kernel.web.annotations.form.FormDetail;
import cn.bonoon.kernel.web.annotations.form.PropertyDetail;

@FormDetail(2)
public class TeacherDetail implements TeacherDefine{

	@PropertyDetail(1)
	private String name;

	@PropertyDetail(2)
	private String status;

	@PropertyDetail(0)
	private String loginName;
//
//	@PropertyDetail(2)
//	private String institution;

	@PropertyDetail(colspan = 1, value = 10)
	private String courseNames;

	@PropertyDetail(colspan = 1, value = 11)
	private String introduction;

	@PropertyDetail(3)
	private String entryAt;

	@PropertyDetail(4)
	private String tel;

	@PropertyDetail(5)
	private String phone;

	@PropertyDetail(colspan = 1, value = 50)
	private String remark;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

//	public String getInstitution() {
//		return institution;
//	}
//
//	public void setInstitution(String institution) {
//		this.institution = institution;
//	}

	public String getCourseNames() {
		return courseNames;
	}

	public void setCourseNames(String courseNames) {
		this.courseNames = courseNames;
	}

	public String getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

	public String getEntryAt() {
		return entryAt;
	}

	public void setEntryAt(String entryAt) {
		this.entryAt = entryAt;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
