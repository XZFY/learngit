jQuery('#tabs-sys-settings-management')
		.tabs(
				'add',
				{
					content : '<iframe scrolling="auto" frameborder="0" src="/s/user/info/!022C33FBB89E6F88FE5A1881AFB12177/index.do" style="width:100%;height:100%;"></iframe>',
					title : '个人信息'
				});
jQuery('#tree-sys-menus').__menu(
		function(menuButton) {
			var menuTitle = menuButton.attr('title');
			if (jQuery('#tabs-sys-settings-management').tabs('exists',
					menuTitle)) {
				jQuery('#tabs-sys-settings-management').tabs('select',
						menuTitle);
			} else {
				var content = '<iframe scrolling="auto" frameborder="0" src="'
						+ menuButton.attr('href')
						+ '" style="width:100%;height:100%;"></iframe>';
				jQuery('#tabs-sys-settings-management').tabs('add', {
					content : content,
					title : menuTitle,
					closable : true
				});
			}
		});
