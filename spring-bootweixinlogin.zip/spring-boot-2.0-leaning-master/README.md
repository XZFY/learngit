# spring-boot-2.0-leaning
Spring-boot 2.0 各种项目脚手架学习

 - demo [使用idea快速创建spring-boot项目](http://javakhbd.com/article/details/498678)
 - spring-boot-email [SpringBoot邮件发送](http://javakhbd.com/article/details/4246490)
 - spring-boot-scan-login [SpringBoot实战之网站扫码登录](http://javakhbd.com/article/details/4246490)