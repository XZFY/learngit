package com.lzp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootScanLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootScanLoginApplication.class, args);
	}
}
